# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack1l1l1l1_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11111ll_opy_ (bstack11111l1_opy_):
    global bstack1lll11_opy_
    bstack1l1ll_opy_ = ord (bstack11111l1_opy_ [-1])
    bstack1ll1l1_opy_ = bstack11111l1_opy_ [:-1]
    bstack1lll11l_opy_ = bstack1l1ll_opy_ % len (bstack1ll1l1_opy_)
    bstack1lllll1_opy_ = bstack1ll1l1_opy_ [:bstack1lll11l_opy_] + bstack1ll1l1_opy_ [bstack1lll11l_opy_:]
    if bstack1l1llll_opy_:
        bstack1l111_opy_ = unicode () .join ([unichr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1l111_opy_ = str () .join ([chr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1l111_opy_)
import atexit
import os
import signal
import sys
import yaml
import requests
import logging
import threading
import socket
import datetime
import string
import random
import json
import collections.abc
import re
import multiprocessing
import traceback
import copy
from packaging import version
from browserstack.local import Local
from urllib.parse import urlparse
from bstack_utils.constants import *
def bstack11ll111ll_opy_():
  global CONFIG
  headers = {
        bstack11111ll_opy_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡸࡾࡶࡥࠨ࢟"): bstack11111ll_opy_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰࡬ࡶࡳࡳ࠭ࢠ"),
      }
  proxies = bstack1l11l1ll1_opy_(CONFIG, bstack1lll1lll1_opy_)
  try:
    response = requests.get(bstack1lll1lll1_opy_, headers=headers, proxies=proxies, timeout=5)
    if response.json():
      bstack11l1llll_opy_ = response.json()[bstack11111ll_opy_ (u"ࠫ࡭ࡻࡢࡴࠩࢡ")]
      logger.debug(bstack1l1l111ll_opy_.format(response.json()))
      return bstack11l1llll_opy_
    else:
      logger.debug(bstack111ll11l_opy_.format(bstack11111ll_opy_ (u"ࠧࡘࡥࡴࡲࡲࡲࡸ࡫ࠠࡋࡕࡒࡒࠥࡶࡡࡳࡵࡨࠤࡪࡸࡲࡰࡴࠣࠦࢢ")))
  except Exception as e:
    logger.debug(bstack111ll11l_opy_.format(e))
def bstack1ll1l1l11_opy_(hub_url):
  global CONFIG
  url = bstack11111ll_opy_ (u"ࠨࡨࡵࡶࡳࡷ࠿࠵࠯ࠣࢣ")+  hub_url + bstack11111ll_opy_ (u"ࠢ࠰ࡥ࡫ࡩࡨࡱࠢࢤ")
  headers = {
        bstack11111ll_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡷࡽࡵ࡫ࠧࢥ"): bstack11111ll_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬࢦ"),
      }
  proxies = bstack1l11l1ll1_opy_(CONFIG, url)
  try:
    start_time = time.perf_counter()
    requests.get(url, headers=headers, proxies=proxies, timeout=5)
    latency = time.perf_counter() - start_time
    logger.debug(bstack1lll1ll1ll_opy_.format(hub_url, latency))
    return dict(hub_url=hub_url, latency=latency)
  except Exception as e:
    logger.debug(bstack111l1l1l1_opy_.format(hub_url, e))
def bstack1ll11l1ll_opy_():
  try:
    global bstack1l1l1l1ll_opy_
    bstack11l1llll_opy_ = bstack11ll111ll_opy_()
    bstack111111111_opy_ = []
    results = []
    for bstack11ll111l_opy_ in bstack11l1llll_opy_:
      bstack111111111_opy_.append(bstack1l1ll111_opy_(target=bstack1ll1l1l11_opy_,args=(bstack11ll111l_opy_,)))
    for t in bstack111111111_opy_:
      t.start()
    for t in bstack111111111_opy_:
      results.append(t.join())
    bstack111lll11_opy_ = {}
    for item in results:
      hub_url = item[bstack11111ll_opy_ (u"ࠪ࡬ࡺࡨ࡟ࡶࡴ࡯ࠫࢧ")]
      latency = item[bstack11111ll_opy_ (u"ࠫࡱࡧࡴࡦࡰࡦࡽࠬࢨ")]
      bstack111lll11_opy_[hub_url] = latency
    bstack1l1l111l_opy_ = min(bstack111lll11_opy_, key= lambda x: bstack111lll11_opy_[x])
    bstack1l1l1l1ll_opy_ = bstack1l1l111l_opy_
    logger.debug(bstack1l1l11ll1_opy_.format(bstack1l1l111l_opy_))
  except Exception as e:
    logger.debug(bstack1lllll1l1_opy_.format(e))
from bstack_utils.messages import *
from bstack_utils.config import Config
from bstack_utils.helper import bstack11ll1lll_opy_, bstack1lll1l1ll1_opy_, bstack111ll1l11_opy_
from bstack_utils.bstack1ll1l11l1l_opy_ import bstack1lll11l1l1_opy_
from bstack_utils.proxy import bstack1llllll11l_opy_, bstack1l11l1ll1_opy_, bstack11l1l1lll_opy_, bstack11lll1ll_opy_
from browserstack_sdk.bstack1ll1l1l1_opy_ import *
from browserstack_sdk.bstack1llll11l_opy_ import *
bstack111l1ll11_opy_ = bstack11111ll_opy_ (u"ࠬࠦࠠ࠰ࠬࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࠫ࠱࡟ࡲࠥࠦࡩࡧࠪࡳࡥ࡬࡫ࠠ࠾࠿ࡀࠤࡻࡵࡩࡥࠢ࠳࠭ࠥࢁ࡜࡯ࠢࠣࠤࡹࡸࡹࡼ࡞ࡱࠤࡨࡵ࡮ࡴࡶࠣࡪࡸࠦ࠽ࠡࡴࡨࡵࡺ࡯ࡲࡦࠪ࡟ࠫ࡫ࡹ࡜ࠨࠫ࠾ࡠࡳࠦࠠࠡࠢࠣࡪࡸ࠴ࡡࡱࡲࡨࡲࡩࡌࡩ࡭ࡧࡖࡽࡳࡩࠨࡣࡵࡷࡥࡨࡱ࡟ࡱࡣࡷ࡬࠱ࠦࡊࡔࡑࡑ࠲ࡸࡺࡲࡪࡰࡪ࡭࡫ࡿࠨࡱࡡ࡬ࡲࡩ࡫ࡸࠪࠢ࠮ࠤࠧࡀࠢࠡ࠭ࠣࡎࡘࡕࡎ࠯ࡵࡷࡶ࡮ࡴࡧࡪࡨࡼࠬࡏ࡙ࡏࡏ࠰ࡳࡥࡷࡹࡥࠩࠪࡤࡻࡦ࡯ࡴࠡࡰࡨࡻࡕࡧࡧࡦ࠴࠱ࡩࡻࡧ࡬ࡶࡣࡷࡩ࠭ࠨࠨࠪࠢࡀࡂࠥࢁࡽࠣ࠮ࠣࡠࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧ࡭ࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡆࡨࡸࡦ࡯࡬ࡴࠤࢀࡠࠬ࠯ࠩࠪ࡝ࠥ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩࠨ࡝ࠪࠢ࠮ࠤࠧ࠲࡜࡝ࡰࠥ࠭ࡡࡴࠠࠡࠢࠣࢁࡨࡧࡴࡤࡪࠫࡩࡽ࠯ࡻ࡝ࡰࠣࠤࠥࠦࡽ࡝ࡰࠣࠤࢂࡢ࡮ࠡࠢ࠲࠮ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠢ࠭࠳ࠬࢩ")
bstack1ll1l11ll1_opy_ = bstack11111ll_opy_ (u"࠭࡜࡯࠱࠭ࠤࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࠬ࠲ࡠࡳࡩ࡯࡯ࡵࡷࠤࡧࡹࡴࡢࡥ࡮ࡣࡵࡧࡴࡩࠢࡀࠤࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࡞ࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷ࠰࡯ࡩࡳ࡭ࡴࡩࠢ࠰ࠤ࠸ࡣ࡜࡯ࡥࡲࡲࡸࡺࠠࡣࡵࡷࡥࡨࡱ࡟ࡤࡣࡳࡷࠥࡃࠠࡱࡴࡲࡧࡪࡹࡳ࠯ࡣࡵ࡫ࡻࡡࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺ࠳ࡲࡥ࡯ࡩࡷ࡬ࠥ࠳ࠠ࠲࡟࡟ࡲࡨࡵ࡮ࡴࡶࠣࡴࡤ࡯࡮ࡥࡧࡻࠤࡂࠦࡰࡳࡱࡦࡩࡸࡹ࠮ࡢࡴࡪࡺࡠࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡱ࡫࡮ࡨࡶ࡫ࠤ࠲ࠦ࠲࡞࡞ࡱࡴࡷࡵࡣࡦࡵࡶ࠲ࡦࡸࡧࡷࠢࡀࠤࡵࡸ࡯ࡤࡧࡶࡷ࠳ࡧࡲࡨࡸ࠱ࡷࡱ࡯ࡣࡦࠪ࠳࠰ࠥࡶࡲࡰࡥࡨࡷࡸ࠴ࡡࡳࡩࡹ࠲ࡱ࡫࡮ࡨࡶ࡫ࠤ࠲ࠦ࠳ࠪ࡞ࡱࡧࡴࡴࡳࡵࠢ࡬ࡱࡵࡵࡲࡵࡡࡳࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠺࡟ࡣࡵࡷࡥࡨࡱࠠ࠾ࠢࡵࡩࡶࡻࡩࡳࡧࠫࠦࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠣࠫ࠾ࡠࡳ࡯࡭ࡱࡱࡵࡸࡤࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵ࠶ࡢࡦࡸࡺࡡࡤ࡭࠱ࡧ࡭ࡸ࡯࡮࡫ࡸࡱ࠳ࡲࡡࡶࡰࡦ࡬ࠥࡃࠠࡢࡵࡼࡲࡨࠦࠨ࡭ࡣࡸࡲࡨ࡮ࡏࡱࡶ࡬ࡳࡳࡹࠩࠡ࠿ࡁࠤࢀࡢ࡮࡭ࡧࡷࠤࡨࡧࡰࡴ࠽࡟ࡲࡹࡸࡹࠡࡽ࡟ࡲࡨࡧࡰࡴࠢࡀࠤࡏ࡙ࡏࡏ࠰ࡳࡥࡷࡹࡥࠩࡤࡶࡸࡦࡩ࡫ࡠࡥࡤࡴࡸ࠯࡜࡯ࠢࠣࢁࠥࡩࡡࡵࡥ࡫ࠬࡪࡾࠩࠡࡽ࡟ࡲࠥࠦࠠࠡࡿ࡟ࡲࠥࠦࡲࡦࡶࡸࡶࡳࠦࡡࡸࡣ࡬ࡸࠥ࡯࡭ࡱࡱࡵࡸࡤࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵ࠶ࡢࡦࡸࡺࡡࡤ࡭࠱ࡧ࡭ࡸ࡯࡮࡫ࡸࡱ࠳ࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡻ࡝ࡰࠣࠤࠥࠦࡷࡴࡇࡱࡨࡵࡵࡩ࡯ࡶ࠽ࠤࡥࡽࡳࡴ࠼࠲࠳ࡨࡪࡰ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡤࡱࡰ࠳ࡵࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࡀࡥࡤࡴࡸࡃࠤࡼࡧࡱࡧࡴࡪࡥࡖࡔࡌࡇࡴࡳࡰࡰࡰࡨࡲࡹ࠮ࡊࡔࡑࡑ࠲ࡸࡺࡲࡪࡰࡪ࡭࡫ࡿࠨࡤࡣࡳࡷ࠮࠯ࡽࡡ࠮࡟ࡲࠥࠦࠠࠡ࠰࠱࠲ࡱࡧࡵ࡯ࡥ࡫ࡓࡵࡺࡩࡰࡰࡶࡠࡳࠦࠠࡾࠫ࡟ࡲࢂࡢ࡮࠰ࠬࠣࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃࠠࠫ࠱࡟ࡲࠬࢪ")
from ._version import __version__
bstack1ll11lll1_opy_ = None
CONFIG = {}
bstack1l11l1l1_opy_ = {}
bstack11111l1ll_opy_ = {}
bstack11111lll_opy_ = None
bstack1l1l1l1l1_opy_ = None
bstack1ll11llll1_opy_ = None
bstack1llll1ll11_opy_ = -1
bstack1llll1lll_opy_ = bstack11l1l111_opy_
bstack1ll1l1llll_opy_ = 1
bstack1111ll11_opy_ = False
bstack11l1lll1_opy_ = False
bstack111lll1l_opy_ = bstack11111ll_opy_ (u"ࠧࠨࢫ")
bstack1llll1l1l1_opy_ = bstack11111ll_opy_ (u"ࠨࠩࢬ")
bstack1llll11l11_opy_ = False
bstack11llll1l_opy_ = True
bstack1llll1lll1_opy_ = bstack11111ll_opy_ (u"ࠩࠪࢭ")
bstack111lll1ll_opy_ = []
bstack1l1l1l1ll_opy_ = bstack11111ll_opy_ (u"ࠪࠫࢮ")
bstack1ll1llll1l_opy_ = False
bstack1lll111lll_opy_ = None
bstack1ll11ll11_opy_ = None
bstack11111l11_opy_ = -1
bstack1111llll_opy_ = os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"ࠫࢃ࠭ࢯ")), bstack11111ll_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬࢰ"), bstack11111ll_opy_ (u"࠭࠮ࡳࡱࡥࡳࡹ࠳ࡲࡦࡲࡲࡶࡹ࠳ࡨࡦ࡮ࡳࡩࡷ࠴ࡪࡴࡱࡱࠫࢱ"))
bstack1ll1l1111_opy_ = []
bstack1lllll111l_opy_ = False
bstack1lll11111l_opy_ = False
bstack111ll1ll1_opy_ = None
bstack11l1111l_opy_ = None
bstack111l1l11l_opy_ = None
bstack1l111ll1l_opy_ = None
bstack111llll11_opy_ = None
bstack1ll11l1l1_opy_ = None
bstack1lll1ll11_opy_ = None
bstack1l1l1lll1_opy_ = None
bstack1lll1lllll_opy_ = None
bstack1llll11ll_opy_ = None
bstack11l11l11l_opy_ = None
bstack1l1llllll_opy_ = None
bstack1l1l1llll_opy_ = None
bstack11l11l111_opy_ = None
bstack11l111l11_opy_ = None
bstack11l111lll_opy_ = None
bstack111l1l1ll_opy_ = None
bstack11l11lll_opy_ = None
bstack1l11llll1_opy_ = bstack11111ll_opy_ (u"ࠢࠣࢲ")
logger = logging.getLogger(__name__)
logging.basicConfig(level=bstack1llll1lll_opy_,
                    format=bstack11111ll_opy_ (u"ࠨ࡞ࡱࠩ࠭ࡧࡳࡤࡶ࡬ࡱࡪ࠯ࡳࠡ࡝ࠨࠬࡳࡧ࡭ࡦࠫࡶࡡࡠࠫࠨ࡭ࡧࡹࡩࡱࡴࡡ࡮ࡧࠬࡷࡢࠦ࠭ࠡࠧࠫࡱࡪࡹࡳࡢࡩࡨ࠭ࡸ࠭ࢳ"),
                    datefmt=bstack11111ll_opy_ (u"ࠩࠨࡌ࠿ࠫࡍ࠻ࠧࡖࠫࢴ"),
                    stream=sys.stdout)
bstack1llllll1l1_opy_ = Config.get_instance()
def bstack11l11ll1l_opy_():
  global CONFIG
  global bstack1llll1lll_opy_
  if bstack11111ll_opy_ (u"ࠪࡰࡴ࡭ࡌࡦࡸࡨࡰࠬࢵ") in CONFIG:
    bstack1llll1lll_opy_ = bstack1111l1l1l_opy_[CONFIG[bstack11111ll_opy_ (u"ࠫࡱࡵࡧࡍࡧࡹࡩࡱ࠭ࢶ")]]
    logging.getLogger().setLevel(bstack1llll1lll_opy_)
def bstack1l1ll1lll_opy_():
  global CONFIG
  global bstack1lllll111l_opy_
  bstack11111111_opy_ = bstack1ll1l1ll11_opy_(CONFIG)
  if (bstack11111ll_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧࢷ") in bstack11111111_opy_ and str(bstack11111111_opy_[bstack11111ll_opy_ (u"࠭ࡳ࡬࡫ࡳࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨࢸ")]).lower() == bstack11111ll_opy_ (u"ࠧࡵࡴࡸࡩࠬࢹ")):
    bstack1lllll111l_opy_ = True
def bstack1l1111l11_opy_():
  from appium.version import version as appium_version
  return version.parse(appium_version)
def bstack1ll1l1l11l_opy_():
  from selenium import webdriver
  return version.parse(webdriver.__version__)
def bstack1l1111ll_opy_():
  args = sys.argv
  for i in range(len(args)):
    if bstack11111ll_opy_ (u"ࠣ࠯࠰ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡥࡲࡲ࡫࡯ࡧࡧ࡫࡯ࡩࠧࢺ") == args[i].lower() or bstack11111ll_opy_ (u"ࠤ࠰࠱ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡴࡦࡪࡩࠥࢻ") == args[i].lower():
      path = args[i + 1]
      sys.argv.remove(args[i])
      sys.argv.remove(path)
      global bstack1llll1lll1_opy_
      bstack1llll1lll1_opy_ += bstack11111ll_opy_ (u"ࠪ࠱࠲ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡇࡴࡴࡦࡪࡩࡉ࡭ࡱ࡫ࠠࠨࢼ") + path
      return path
  return None
bstack11ll1l1l_opy_ = re.compile(bstack11111ll_opy_ (u"ࡶࠧ࠴ࠪࡀ࡞ࠧࡿ࠭࠴ࠪࡀࠫࢀ࠲࠯ࡅࠢࢽ"))
def bstack1111l1lll_opy_(loader, node):
  value = loader.construct_scalar(node)
  for group in bstack11ll1l1l_opy_.findall(value):
    if group is not None and os.environ.get(group) is not None:
      value = value.replace(bstack11111ll_opy_ (u"ࠧࠪࡻࠣࢾ") + group + bstack11111ll_opy_ (u"ࠨࡽࠣࢿ"), os.environ.get(group))
  return value
def bstack1l1lll111_opy_():
  bstack1111111l_opy_ = bstack1l1111ll_opy_()
  if bstack1111111l_opy_ and os.path.exists(os.path.abspath(bstack1111111l_opy_)):
    fileName = bstack1111111l_opy_
  if bstack11111ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡃࡐࡐࡉࡍࡌࡥࡆࡊࡎࡈࠫࣀ") in os.environ and os.path.exists(
          os.path.abspath(os.environ[bstack11111ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡄࡑࡑࡊࡎࡍ࡟ࡇࡋࡏࡉࠬࣁ")])) and not bstack11111ll_opy_ (u"ࠩࡩ࡭ࡱ࡫ࡎࡢ࡯ࡨࠫࣂ") in locals():
    fileName = os.environ[bstack11111ll_opy_ (u"ࠪࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡆࡓࡓࡌࡉࡈࡡࡉࡍࡑࡋࠧࣃ")]
  if bstack11111ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡐࡤࡱࡪ࠭ࣄ") in locals():
    bstack1111l1_opy_ = os.path.abspath(fileName)
  else:
    bstack1111l1_opy_ = bstack11111ll_opy_ (u"ࠬ࠭ࣅ")
  bstack11ll1l11l_opy_ = os.getcwd()
  bstack1l1lllll1_opy_ = bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡿ࡭࡭ࠩࣆ")
  bstack11lll1l1l_opy_ = bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡹࡢ࡯࡯ࠫࣇ")
  while (not os.path.exists(bstack1111l1_opy_)) and bstack11ll1l11l_opy_ != bstack11111ll_opy_ (u"ࠣࠤࣈ"):
    bstack1111l1_opy_ = os.path.join(bstack11ll1l11l_opy_, bstack1l1lllll1_opy_)
    if not os.path.exists(bstack1111l1_opy_):
      bstack1111l1_opy_ = os.path.join(bstack11ll1l11l_opy_, bstack11lll1l1l_opy_)
    if bstack11ll1l11l_opy_ != os.path.dirname(bstack11ll1l11l_opy_):
      bstack11ll1l11l_opy_ = os.path.dirname(bstack11ll1l11l_opy_)
    else:
      bstack11ll1l11l_opy_ = bstack11111ll_opy_ (u"ࠤࠥࣉ")
  if not os.path.exists(bstack1111l1_opy_):
    bstack11l1ll11_opy_(
      bstack1ll1ll111l_opy_.format(os.getcwd()))
  try:
    with open(bstack1111l1_opy_, bstack11111ll_opy_ (u"ࠪࡶࠬ࣊")) as stream:
      yaml.add_implicit_resolver(bstack11111ll_opy_ (u"ࠦࠦࡶࡡࡵࡪࡨࡼࠧ࣋"), bstack11ll1l1l_opy_)
      yaml.add_constructor(bstack11111ll_opy_ (u"ࠧࠧࡰࡢࡶ࡫ࡩࡽࠨ࣌"), bstack1111l1lll_opy_)
      config = yaml.load(stream, yaml.FullLoader)
      return config
  except:
    with open(bstack1111l1_opy_, bstack11111ll_opy_ (u"࠭ࡲࠨ࣍")) as stream:
      try:
        config = yaml.safe_load(stream)
        return config
      except yaml.YAMLError as exc:
        bstack11l1ll11_opy_(bstack1l11111l_opy_.format(str(exc)))
def bstack1l1ll11ll_opy_(config):
  bstack111ll111_opy_ = bstack1l1l1111_opy_(config)
  for option in list(bstack111ll111_opy_):
    if option.lower() in bstack1lll1ll1l1_opy_ and option != bstack1lll1ll1l1_opy_[option.lower()]:
      bstack111ll111_opy_[bstack1lll1ll1l1_opy_[option.lower()]] = bstack111ll111_opy_[option]
      del bstack111ll111_opy_[option]
  return config
def bstack1ll111lll_opy_():
  global bstack11111l1ll_opy_
  for key, bstack1ll111111_opy_ in bstack1lll1l1l1l_opy_.items():
    if isinstance(bstack1ll111111_opy_, list):
      for var in bstack1ll111111_opy_:
        if var in os.environ and os.environ[var] and str(os.environ[var]).strip():
          bstack11111l1ll_opy_[key] = os.environ[var]
          break
    elif bstack1ll111111_opy_ in os.environ and os.environ[bstack1ll111111_opy_] and str(os.environ[bstack1ll111111_opy_]).strip():
      bstack11111l1ll_opy_[key] = os.environ[bstack1ll111111_opy_]
  if bstack11111ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡌࡐࡅࡄࡐࡤࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓࠩ࣎") in os.environ:
    bstack11111l1ll_opy_[bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷ࣏ࠬ")] = {}
    bstack11111l1ll_opy_[bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࣐࠭")][bstack11111ll_opy_ (u"ࠪࡰࡴࡩࡡ࡭ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶ࣑ࠬ")] = os.environ[bstack11111ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡐࡔࡉࡁࡍࡡࡌࡈࡊࡔࡔࡊࡈࡌࡉࡗ࣒࠭")]
def bstack1llll1l111_opy_():
  global bstack1l11l1l1_opy_
  global bstack1llll1lll1_opy_
  for idx, val in enumerate(sys.argv):
    if idx < len(sys.argv) and bstack11111ll_opy_ (u"ࠬ࠳࠭ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴࡬ࡰࡥࡤࡰࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨ࣓").lower() == val.lower():
      bstack1l11l1l1_opy_[bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪࣔ")] = {}
      bstack1l11l1l1_opy_[bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫࣕ")][bstack11111ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪࣖ")] = sys.argv[idx + 1]
      del sys.argv[idx:idx + 2]
      break
  for key, bstack1l1111l1_opy_ in bstack1ll1l11l11_opy_.items():
    if isinstance(bstack1l1111l1_opy_, list):
      for idx, val in enumerate(sys.argv):
        for var in bstack1l1111l1_opy_:
          if idx < len(sys.argv) and bstack11111ll_opy_ (u"ࠩ࠰࠱ࠬࣗ") + var.lower() == val.lower() and not key in bstack1l11l1l1_opy_:
            bstack1l11l1l1_opy_[key] = sys.argv[idx + 1]
            bstack1llll1lll1_opy_ += bstack11111ll_opy_ (u"ࠪࠤ࠲࠳ࠧࣘ") + var + bstack11111ll_opy_ (u"ࠫࠥ࠭ࣙ") + sys.argv[idx + 1]
            del sys.argv[idx:idx + 2]
            break
    else:
      for idx, val in enumerate(sys.argv):
        if idx < len(sys.argv) and bstack11111ll_opy_ (u"ࠬ࠳࠭ࠨࣚ") + bstack1l1111l1_opy_.lower() == val.lower() and not key in bstack1l11l1l1_opy_:
          bstack1l11l1l1_opy_[key] = sys.argv[idx + 1]
          bstack1llll1lll1_opy_ += bstack11111ll_opy_ (u"࠭ࠠ࠮࠯ࠪࣛ") + bstack1l1111l1_opy_ + bstack11111ll_opy_ (u"ࠧࠡࠩࣜ") + sys.argv[idx + 1]
          del sys.argv[idx:idx + 2]
def bstack1lll11l1ll_opy_(config):
  bstack1111ll1l1_opy_ = config.keys()
  for bstack111ll1l1_opy_, bstack1l11111ll_opy_ in bstack1llll1l1ll_opy_.items():
    if bstack1l11111ll_opy_ in bstack1111ll1l1_opy_:
      config[bstack111ll1l1_opy_] = config[bstack1l11111ll_opy_]
      del config[bstack1l11111ll_opy_]
  for bstack111ll1l1_opy_, bstack1l11111ll_opy_ in bstack1ll1lll1l1_opy_.items():
    if isinstance(bstack1l11111ll_opy_, list):
      for bstack1lll1111l1_opy_ in bstack1l11111ll_opy_:
        if bstack1lll1111l1_opy_ in bstack1111ll1l1_opy_:
          config[bstack111ll1l1_opy_] = config[bstack1lll1111l1_opy_]
          del config[bstack1lll1111l1_opy_]
          break
    elif bstack1l11111ll_opy_ in bstack1111ll1l1_opy_:
      config[bstack111ll1l1_opy_] = config[bstack1l11111ll_opy_]
      del config[bstack1l11111ll_opy_]
  for bstack1lll1111l1_opy_ in list(config):
    for bstack1l111lll1_opy_ in bstack1l11l1lll_opy_:
      if bstack1lll1111l1_opy_.lower() == bstack1l111lll1_opy_.lower() and bstack1lll1111l1_opy_ != bstack1l111lll1_opy_:
        config[bstack1l111lll1_opy_] = config[bstack1lll1111l1_opy_]
        del config[bstack1lll1111l1_opy_]
  bstack1l1l11l1_opy_ = []
  if bstack11111ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫࣝ") in config:
    bstack1l1l11l1_opy_ = config[bstack11111ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬࣞ")]
  for platform in bstack1l1l11l1_opy_:
    for bstack1lll1111l1_opy_ in list(platform):
      for bstack1l111lll1_opy_ in bstack1l11l1lll_opy_:
        if bstack1lll1111l1_opy_.lower() == bstack1l111lll1_opy_.lower() and bstack1lll1111l1_opy_ != bstack1l111lll1_opy_:
          platform[bstack1l111lll1_opy_] = platform[bstack1lll1111l1_opy_]
          del platform[bstack1lll1111l1_opy_]
  for bstack111ll1l1_opy_, bstack1l11111ll_opy_ in bstack1ll1lll1l1_opy_.items():
    for platform in bstack1l1l11l1_opy_:
      if isinstance(bstack1l11111ll_opy_, list):
        for bstack1lll1111l1_opy_ in bstack1l11111ll_opy_:
          if bstack1lll1111l1_opy_ in platform:
            platform[bstack111ll1l1_opy_] = platform[bstack1lll1111l1_opy_]
            del platform[bstack1lll1111l1_opy_]
            break
      elif bstack1l11111ll_opy_ in platform:
        platform[bstack111ll1l1_opy_] = platform[bstack1l11111ll_opy_]
        del platform[bstack1l11111ll_opy_]
  for bstack1llll11l1_opy_ in bstack11111llll_opy_:
    if bstack1llll11l1_opy_ in config:
      if not bstack11111llll_opy_[bstack1llll11l1_opy_] in config:
        config[bstack11111llll_opy_[bstack1llll11l1_opy_]] = {}
      config[bstack11111llll_opy_[bstack1llll11l1_opy_]].update(config[bstack1llll11l1_opy_])
      del config[bstack1llll11l1_opy_]
  for platform in bstack1l1l11l1_opy_:
    for bstack1llll11l1_opy_ in bstack11111llll_opy_:
      if bstack1llll11l1_opy_ in list(platform):
        if not bstack11111llll_opy_[bstack1llll11l1_opy_] in platform:
          platform[bstack11111llll_opy_[bstack1llll11l1_opy_]] = {}
        platform[bstack11111llll_opy_[bstack1llll11l1_opy_]].update(platform[bstack1llll11l1_opy_])
        del platform[bstack1llll11l1_opy_]
  config = bstack1l1ll11ll_opy_(config)
  return config
def bstack1l11l111l_opy_(config):
  global bstack1llll1l1l1_opy_
  if bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧࣟ") in config and str(config[bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨ࣠")]).lower() != bstack11111ll_opy_ (u"ࠬ࡬ࡡ࡭ࡵࡨࠫ࣡"):
    if not bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࠪ࣢") in config:
      config[bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࣣࠫ")] = {}
    if not bstack11111ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪࣤ") in config[bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࡍࡱࡦࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ࣥ")]:
      bstack11111l1l_opy_ = datetime.datetime.now()
      bstack1ll1lll111_opy_ = bstack11111l1l_opy_.strftime(bstack11111ll_opy_ (u"ࠪࠩࡩࡥࠥࡣࡡࠨࡌࠪࡓࣦࠧ"))
      hostname = socket.gethostname()
      bstack1l11lll11_opy_ = bstack11111ll_opy_ (u"ࠫࠬࣧ").join(random.choices(string.ascii_lowercase + string.digits, k=4))
      identifier = bstack11111ll_opy_ (u"ࠬࢁࡽࡠࡽࢀࡣࢀࢃࠧࣨ").format(bstack1ll1lll111_opy_, hostname, bstack1l11lll11_opy_)
      config[bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡓࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࡒࡴࡹ࡯࡯࡯ࡵࣩࠪ")][bstack11111ll_opy_ (u"ࠧ࡭ࡱࡦࡥࡱࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩ࣪")] = identifier
    bstack1llll1l1l1_opy_ = config[bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬ࣫")][bstack11111ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ࣬")]
  return config
def bstack1llll1l11_opy_():
  if (
          isinstance(os.getenv(bstack11111ll_opy_ (u"ࠪࡎࡊࡔࡋࡊࡐࡖࡣ࡚ࡘࡌࠨ࣭")), str) and len(os.getenv(bstack11111ll_opy_ (u"ࠫࡏࡋࡎࡌࡋࡑࡗࡤ࡛ࡒࡍ࣮ࠩ"))) > 0
  ) or (
          isinstance(os.getenv(bstack11111ll_opy_ (u"ࠬࡐࡅࡏࡍࡌࡒࡘࡥࡈࡐࡏࡈ࣯ࠫ")), str) and len(os.getenv(bstack11111ll_opy_ (u"࠭ࡊࡆࡐࡎࡍࡓ࡙࡟ࡉࡑࡐࡉࣰࠬ"))) > 0
  ):
    return os.getenv(bstack11111ll_opy_ (u"ࠧࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࣱ࠭"), 0)
  if str(os.getenv(bstack11111ll_opy_ (u"ࠨࡅࡌࣲࠫ"))).lower() == bstack11111ll_opy_ (u"ࠩࡷࡶࡺ࡫ࠧࣳ") and str(os.getenv(bstack11111ll_opy_ (u"ࠪࡇࡎࡘࡃࡍࡇࡆࡍࠬࣴ"))).lower() == bstack11111ll_opy_ (u"ࠫࡹࡸࡵࡦࠩࣵ"):
    return os.getenv(bstack11111ll_opy_ (u"ࠬࡉࡉࡓࡅࡏࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࠨࣶ"), 0)
  if str(os.getenv(bstack11111ll_opy_ (u"࠭ࡃࡊࠩࣷ"))).lower() == bstack11111ll_opy_ (u"ࠧࡵࡴࡸࡩࠬࣸ") and str(os.getenv(bstack11111ll_opy_ (u"ࠨࡖࡕࡅ࡛ࡏࡓࠨࣹ"))).lower() == bstack11111ll_opy_ (u"ࠩࡷࡶࡺ࡫ࣺࠧ"):
    return os.getenv(bstack11111ll_opy_ (u"ࠪࡘࡗࡇࡖࡊࡕࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࡈࡅࡓࠩࣻ"), 0)
  if str(os.getenv(bstack11111ll_opy_ (u"ࠫࡈࡏࠧࣼ"))).lower() == bstack11111ll_opy_ (u"ࠬࡺࡲࡶࡧࠪࣽ") and str(os.getenv(bstack11111ll_opy_ (u"࠭ࡃࡊࡡࡑࡅࡒࡋࠧࣾ"))).lower() == bstack11111ll_opy_ (u"ࠧࡤࡱࡧࡩࡸ࡮ࡩࡱࠩࣿ"):
    return 0
  if os.getenv(bstack11111ll_opy_ (u"ࠨࡄࡌࡘࡇ࡛ࡃࡌࡇࡗࡣࡇࡘࡁࡏࡅࡋࠫऀ")) and os.getenv(bstack11111ll_opy_ (u"ࠩࡅࡍ࡙ࡈࡕࡄࡍࡈࡘࡤࡉࡏࡎࡏࡌࡘࠬँ")):
    return os.getenv(bstack11111ll_opy_ (u"ࠪࡆࡎ࡚ࡂࡖࡅࡎࡉ࡙ࡥࡂࡖࡋࡏࡈࡤࡔࡕࡎࡄࡈࡖࠬं"), 0)
  if str(os.getenv(bstack11111ll_opy_ (u"ࠫࡈࡏࠧः"))).lower() == bstack11111ll_opy_ (u"ࠬࡺࡲࡶࡧࠪऄ") and str(os.getenv(bstack11111ll_opy_ (u"࠭ࡄࡓࡑࡑࡉࠬअ"))).lower() == bstack11111ll_opy_ (u"ࠧࡵࡴࡸࡩࠬआ"):
    return os.getenv(bstack11111ll_opy_ (u"ࠨࡆࡕࡓࡓࡋ࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗ࠭इ"), 0)
  if str(os.getenv(bstack11111ll_opy_ (u"ࠩࡆࡍࠬई"))).lower() == bstack11111ll_opy_ (u"ࠪࡸࡷࡻࡥࠨउ") and str(os.getenv(bstack11111ll_opy_ (u"ࠫࡘࡋࡍࡂࡒࡋࡓࡗࡋࠧऊ"))).lower() == bstack11111ll_opy_ (u"ࠬࡺࡲࡶࡧࠪऋ"):
    return os.getenv(bstack11111ll_opy_ (u"࠭ࡓࡆࡏࡄࡔࡍࡕࡒࡆࡡࡍࡓࡇࡥࡉࡅࠩऌ"), 0)
  if str(os.getenv(bstack11111ll_opy_ (u"ࠧࡄࡋࠪऍ"))).lower() == bstack11111ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭ऎ") and str(os.getenv(bstack11111ll_opy_ (u"ࠩࡊࡍ࡙ࡒࡁࡃࡡࡆࡍࠬए"))).lower() == bstack11111ll_opy_ (u"ࠪࡸࡷࡻࡥࠨऐ"):
    return os.getenv(bstack11111ll_opy_ (u"ࠫࡈࡏ࡟ࡋࡑࡅࡣࡎࡊࠧऑ"), 0)
  if str(os.getenv(bstack11111ll_opy_ (u"ࠬࡉࡉࠨऒ"))).lower() == bstack11111ll_opy_ (u"࠭ࡴࡳࡷࡨࠫओ") and str(os.getenv(bstack11111ll_opy_ (u"ࠧࡃࡗࡌࡐࡉࡑࡉࡕࡇࠪऔ"))).lower() == bstack11111ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭क"):
    return os.getenv(bstack11111ll_opy_ (u"ࠩࡅ࡙ࡎࡒࡄࡌࡋࡗࡉࡤࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠫख"), 0)
  if str(os.getenv(bstack11111ll_opy_ (u"ࠪࡘࡋࡥࡂࡖࡋࡏࡈࠬग"))).lower() == bstack11111ll_opy_ (u"ࠫࡹࡸࡵࡦࠩघ"):
    return os.getenv(bstack11111ll_opy_ (u"ࠬࡈࡕࡊࡎࡇࡣࡇ࡛ࡉࡍࡆࡌࡈࠬङ"), 0)
  return -1
def bstack11lllllll_opy_(bstack1ll1l111l1_opy_):
  global CONFIG
  if not bstack11111ll_opy_ (u"࠭ࠤࡼࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࡽࠨच") in CONFIG[bstack11111ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩछ")]:
    return
  CONFIG[bstack11111ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪज")] = CONFIG[bstack11111ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫझ")].replace(
    bstack11111ll_opy_ (u"ࠪࠨࢀࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࢁࠬञ"),
    str(bstack1ll1l111l1_opy_)
  )
def bstack111lllll_opy_():
  global CONFIG
  if not bstack11111ll_opy_ (u"ࠫࠩࢁࡄࡂࡖࡈࡣ࡙ࡏࡍࡆࡿࠪट") in CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧठ")]:
    return
  bstack11111l1l_opy_ = datetime.datetime.now()
  bstack1ll1lll111_opy_ = bstack11111l1l_opy_.strftime(bstack11111ll_opy_ (u"࠭ࠥࡥ࠯ࠨࡦ࠲ࠫࡈ࠻ࠧࡐࠫड"))
  CONFIG[bstack11111ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩढ")] = CONFIG[bstack11111ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪण")].replace(
    bstack11111ll_opy_ (u"ࠩࠧࡿࡉࡇࡔࡆࡡࡗࡍࡒࡋࡽࠨत"),
    bstack1ll1lll111_opy_
  )
def bstack1lll11lll_opy_():
  global CONFIG
  if bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬथ") in CONFIG and not bool(CONFIG[bstack11111ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭द")]):
    del CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧध")]
    return
  if not bstack11111ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨन") in CONFIG:
    CONFIG[bstack11111ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩऩ")] = bstack11111ll_opy_ (u"ࠨࠥࠧࡿࡇ࡛ࡉࡍࡆࡢࡒ࡚ࡓࡂࡆࡔࢀࠫप")
  if bstack11111ll_opy_ (u"ࠩࠧࡿࡉࡇࡔࡆࡡࡗࡍࡒࡋࡽࠨफ") in CONFIG[bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬब")]:
    bstack111lllll_opy_()
    os.environ[bstack11111ll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡣࡈࡕࡍࡃࡋࡑࡉࡉࡥࡂࡖࡋࡏࡈࡤࡏࡄࠨभ")] = CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧम")]
  if not bstack11111ll_opy_ (u"࠭ࠤࡼࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࡽࠨय") in CONFIG[bstack11111ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩर")]:
    return
  bstack1ll1l111l1_opy_ = bstack11111ll_opy_ (u"ࠨࠩऱ")
  bstack1lll11l1l_opy_ = bstack1llll1l11_opy_()
  if bstack1lll11l1l_opy_ != -1:
    bstack1ll1l111l1_opy_ = bstack11111ll_opy_ (u"ࠩࡆࡍࠥ࠭ल") + str(bstack1lll11l1l_opy_)
  if bstack1ll1l111l1_opy_ == bstack11111ll_opy_ (u"ࠪࠫळ"):
    bstack1ll11llll_opy_ = bstack11111l111_opy_(CONFIG[bstack11111ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧऴ")])
    if bstack1ll11llll_opy_ != -1:
      bstack1ll1l111l1_opy_ = str(bstack1ll11llll_opy_)
  if bstack1ll1l111l1_opy_:
    bstack11lllllll_opy_(bstack1ll1l111l1_opy_)
    os.environ[bstack11111ll_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡤࡉࡏࡎࡄࡌࡒࡊࡊ࡟ࡃࡗࡌࡐࡉࡥࡉࡅࠩव")] = CONFIG[bstack11111ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨश")]
def bstack111llll1_opy_(bstack1111111ll_opy_, bstack111ll11l1_opy_, path):
  bstack1l1ll11l1_opy_ = {
    bstack11111ll_opy_ (u"ࠧࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫष"): bstack111ll11l1_opy_
  }
  if os.path.exists(path):
    bstack1l111l1l_opy_ = json.load(open(path, bstack11111ll_opy_ (u"ࠨࡴࡥࠫस")))
  else:
    bstack1l111l1l_opy_ = {}
  bstack1l111l1l_opy_[bstack1111111ll_opy_] = bstack1l1ll11l1_opy_
  with open(path, bstack11111ll_opy_ (u"ࠤࡺ࠯ࠧह")) as outfile:
    json.dump(bstack1l111l1l_opy_, outfile)
def bstack11111l111_opy_(bstack1111111ll_opy_):
  bstack1111111ll_opy_ = str(bstack1111111ll_opy_)
  bstack11lll1lll_opy_ = os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"ࠪࢂࠬऺ")), bstack11111ll_opy_ (u"ࠫ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠫऻ"))
  try:
    if not os.path.exists(bstack11lll1lll_opy_):
      os.makedirs(bstack11lll1lll_opy_)
    file_path = os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"ࠬࢄ़ࠧ")), bstack11111ll_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ऽ"), bstack11111ll_opy_ (u"ࠧ࠯ࡤࡸ࡭ࡱࡪ࠭࡯ࡣࡰࡩ࠲ࡩࡡࡤࡪࡨ࠲࡯ࡹ࡯࡯ࠩा"))
    if not os.path.isfile(file_path):
      with open(file_path, bstack11111ll_opy_ (u"ࠨࡹࠪि")):
        pass
      with open(file_path, bstack11111ll_opy_ (u"ࠤࡺ࠯ࠧी")) as outfile:
        json.dump({}, outfile)
    with open(file_path, bstack11111ll_opy_ (u"ࠪࡶࠬु")) as bstack1l11l1111_opy_:
      bstack11ll11l1_opy_ = json.load(bstack1l11l1111_opy_)
    if bstack1111111ll_opy_ in bstack11ll11l1_opy_:
      bstack111l1l11_opy_ = bstack11ll11l1_opy_[bstack1111111ll_opy_][bstack11111ll_opy_ (u"ࠫ࡮ࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨू")]
      bstack1l1l11ll_opy_ = int(bstack111l1l11_opy_) + 1
      bstack111llll1_opy_(bstack1111111ll_opy_, bstack1l1l11ll_opy_, file_path)
      return bstack1l1l11ll_opy_
    else:
      bstack111llll1_opy_(bstack1111111ll_opy_, 1, file_path)
      return 1
  except Exception as e:
    logger.warn(bstack111l111l_opy_.format(str(e)))
    return -1
def bstack111lll111_opy_(config):
  if not config[bstack11111ll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧृ")] or not config[bstack11111ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩॄ")]:
    return True
  else:
    return False
def bstack11l11l1l_opy_(config):
  if bstack11111ll_opy_ (u"ࠧࡪࡵࡓࡰࡦࡿࡷࡳ࡫ࡪ࡬ࡹ࠭ॅ") in config:
    del (config[bstack11111ll_opy_ (u"ࠨ࡫ࡶࡔࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠧॆ")])
    return False
  if bstack1ll1l1l11l_opy_() < version.parse(bstack11111ll_opy_ (u"ࠩ࠶࠲࠹࠴࠰ࠨे")):
    return False
  if bstack1ll1l1l11l_opy_() >= version.parse(bstack11111ll_opy_ (u"ࠪ࠸࠳࠷࠮࠶ࠩै")):
    return True
  if bstack11111ll_opy_ (u"ࠫࡺࡹࡥࡘ࠵ࡆࠫॉ") in config and config[bstack11111ll_opy_ (u"ࠬࡻࡳࡦ࡙࠶ࡇࠬॊ")] == False:
    return False
  else:
    return True
def bstack111111lll_opy_(config, index=0):
  global bstack1llll11l11_opy_
  bstack11l1l11l1_opy_ = {}
  caps = bstack111l111ll_opy_ + bstack1llll11l1l_opy_
  if bstack1llll11l11_opy_:
    caps += bstack1l11ll1ll_opy_
  for key in config:
    if key in caps + [bstack11111ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩो")]:
      continue
    bstack11l1l11l1_opy_[key] = config[key]
  if bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪौ") in config:
    for bstack1ll1l1111l_opy_ in config[bstack11111ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶ्ࠫ")][index]:
      if bstack1ll1l1111l_opy_ in caps + [bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧॎ"), bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵ࡚ࡪࡸࡳࡪࡱࡱࠫॏ")]:
        continue
      bstack11l1l11l1_opy_[bstack1ll1l1111l_opy_] = config[bstack11111ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧॐ")][index][bstack1ll1l1111l_opy_]
  bstack11l1l11l1_opy_[bstack11111ll_opy_ (u"ࠬ࡮࡯ࡴࡶࡑࡥࡲ࡫ࠧ॑")] = socket.gethostname()
  if bstack11111ll_opy_ (u"࠭ࡶࡦࡴࡶ࡭ࡴࡴ॒ࠧ") in bstack11l1l11l1_opy_:
    del (bstack11l1l11l1_opy_[bstack11111ll_opy_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࠨ॓")])
  return bstack11l1l11l1_opy_
def bstack1lll11ll11_opy_(config):
  global bstack1llll11l11_opy_
  bstack1lll111l1_opy_ = {}
  caps = bstack1llll11l1l_opy_
  if bstack1llll11l11_opy_:
    caps += bstack1l11ll1ll_opy_
  for key in caps:
    if key in config:
      bstack1lll111l1_opy_[key] = config[key]
  return bstack1lll111l1_opy_
def bstack1ll1111l1_opy_(bstack11l1l11l1_opy_, bstack1lll111l1_opy_):
  bstack1llll11ll1_opy_ = {}
  for key in bstack11l1l11l1_opy_.keys():
    if key in bstack1llll1l1ll_opy_:
      bstack1llll11ll1_opy_[bstack1llll1l1ll_opy_[key]] = bstack11l1l11l1_opy_[key]
    else:
      bstack1llll11ll1_opy_[key] = bstack11l1l11l1_opy_[key]
  for key in bstack1lll111l1_opy_:
    if key in bstack1llll1l1ll_opy_:
      bstack1llll11ll1_opy_[bstack1llll1l1ll_opy_[key]] = bstack1lll111l1_opy_[key]
    else:
      bstack1llll11ll1_opy_[key] = bstack1lll111l1_opy_[key]
  return bstack1llll11ll1_opy_
def bstack11l111l1_opy_(config, index=0):
  global bstack1llll11l11_opy_
  config = copy.deepcopy(config)
  caps = {}
  bstack1lll111l1_opy_ = bstack1lll11ll11_opy_(config)
  bstack1111ll1ll_opy_ = bstack1llll11l1l_opy_
  bstack1111ll1ll_opy_ += bstack1l1111111_opy_
  if bstack1llll11l11_opy_:
    bstack1111ll1ll_opy_ += bstack1l11ll1ll_opy_
  if bstack11111ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ॔") in config:
    if bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧॕ") in config[bstack11111ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ॖ")][index]:
      caps[bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩॗ")] = config[bstack11111ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨक़")][index][bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫख़")]
    if bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡗࡧࡵࡷ࡮ࡵ࡮ࠨग़") in config[bstack11111ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫज़")][index]:
      caps[bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪड़")] = str(config[bstack11111ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ढ़")][index][bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬफ़")])
    bstack1l1lll1ll_opy_ = {}
    for bstack111l111l1_opy_ in bstack1111ll1ll_opy_:
      if bstack111l111l1_opy_ in config[bstack11111ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨय़")][index]:
        if bstack111l111l1_opy_ == bstack11111ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨॠ"):
          try:
            bstack1l1lll1ll_opy_[bstack111l111l1_opy_] = str(config[bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪॡ")][index][bstack111l111l1_opy_] * 1.0)
          except:
            bstack1l1lll1ll_opy_[bstack111l111l1_opy_] = str(config[bstack11111ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫॢ")][index][bstack111l111l1_opy_])
        else:
          bstack1l1lll1ll_opy_[bstack111l111l1_opy_] = config[bstack11111ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬॣ")][index][bstack111l111l1_opy_]
        del (config[bstack11111ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭।")][index][bstack111l111l1_opy_])
    bstack1lll111l1_opy_ = update(bstack1lll111l1_opy_, bstack1l1lll1ll_opy_)
  bstack11l1l11l1_opy_ = bstack111111lll_opy_(config, index)
  for bstack1lll1111l1_opy_ in bstack1llll11l1l_opy_ + [bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩ॥"), bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭०")]:
    if bstack1lll1111l1_opy_ in bstack11l1l11l1_opy_:
      bstack1lll111l1_opy_[bstack1lll1111l1_opy_] = bstack11l1l11l1_opy_[bstack1lll1111l1_opy_]
      del (bstack11l1l11l1_opy_[bstack1lll1111l1_opy_])
  if bstack11l11l1l_opy_(config):
    bstack11l1l11l1_opy_[bstack11111ll_opy_ (u"࠭ࡵࡴࡧ࡚࠷ࡈ࠭१")] = True
    caps.update(bstack1lll111l1_opy_)
    caps[bstack11111ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨ२")] = bstack11l1l11l1_opy_
  else:
    bstack11l1l11l1_opy_[bstack11111ll_opy_ (u"ࠨࡷࡶࡩ࡜࠹ࡃࠨ३")] = False
    caps.update(bstack1ll1111l1_opy_(bstack11l1l11l1_opy_, bstack1lll111l1_opy_))
    if bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧ४") in caps:
      caps[bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࠫ५")] = caps[bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩ६")]
      del (caps[bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪ७")])
    if bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧ८") in caps:
      caps[bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ९")] = caps[bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩ॰")]
      del (caps[bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴ࡙ࡩࡷࡹࡩࡰࡰࠪॱ")])
  return caps
def bstack11lll111l_opy_():
  global bstack1l1l1l1ll_opy_
  if bstack1ll1l1l11l_opy_() <= version.parse(bstack11111ll_opy_ (u"ࠪ࠷࠳࠷࠳࠯࠲ࠪॲ")):
    if bstack1l1l1l1ll_opy_ != bstack11111ll_opy_ (u"ࠫࠬॳ"):
      return bstack11111ll_opy_ (u"ࠧ࡮ࡴࡵࡲ࠽࠳࠴ࠨॴ") + bstack1l1l1l1ll_opy_ + bstack11111ll_opy_ (u"ࠨ࠺࠹࠲࠲ࡻࡩ࠵ࡨࡶࡤࠥॵ")
    return bstack1l11l111_opy_
  if bstack1l1l1l1ll_opy_ != bstack11111ll_opy_ (u"ࠧࠨॶ"):
    return bstack11111ll_opy_ (u"ࠣࡪࡷࡸࡵࡹ࠺࠰࠱ࠥॷ") + bstack1l1l1l1ll_opy_ + bstack11111ll_opy_ (u"ࠤ࠲ࡻࡩ࠵ࡨࡶࡤࠥॸ")
  return bstack111l1ll1_opy_
def bstack1l11l1l1l_opy_(options):
  return hasattr(options, bstack11111ll_opy_ (u"ࠪࡷࡪࡺ࡟ࡤࡣࡳࡥࡧ࡯࡬ࡪࡶࡼࠫॹ"))
def update(d, u):
  for k, v in u.items():
    if isinstance(v, collections.abc.Mapping):
      d[k] = update(d.get(k, {}), v)
    else:
      if isinstance(v, list):
        d[k] = d.get(k, []) + v
      else:
        d[k] = v
  return d
def bstack11lllll1_opy_(options, bstack1l1l11111_opy_):
  for bstack11l1l1111_opy_ in bstack1l1l11111_opy_:
    if bstack11l1l1111_opy_ in [bstack11111ll_opy_ (u"ࠫࡦࡸࡧࡴࠩॺ"), bstack11111ll_opy_ (u"ࠬ࡫ࡸࡵࡧࡱࡷ࡮ࡵ࡮ࡴࠩॻ")]:
      next
    if bstack11l1l1111_opy_ in options._experimental_options:
      options._experimental_options[bstack11l1l1111_opy_] = update(options._experimental_options[bstack11l1l1111_opy_],
                                                         bstack1l1l11111_opy_[bstack11l1l1111_opy_])
    else:
      options.add_experimental_option(bstack11l1l1111_opy_, bstack1l1l11111_opy_[bstack11l1l1111_opy_])
  if bstack11111ll_opy_ (u"࠭ࡡࡳࡩࡶࠫॼ") in bstack1l1l11111_opy_:
    for arg in bstack1l1l11111_opy_[bstack11111ll_opy_ (u"ࠧࡢࡴࡪࡷࠬॽ")]:
      options.add_argument(arg)
    del (bstack1l1l11111_opy_[bstack11111ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ॾ")])
  if bstack11111ll_opy_ (u"ࠩࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࡸ࠭ॿ") in bstack1l1l11111_opy_:
    for ext in bstack1l1l11111_opy_[bstack11111ll_opy_ (u"ࠪࡩࡽࡺࡥ࡯ࡵ࡬ࡳࡳࡹࠧঀ")]:
      options.add_extension(ext)
    del (bstack1l1l11111_opy_[bstack11111ll_opy_ (u"ࠫࡪࡾࡴࡦࡰࡶ࡭ࡴࡴࡳࠨঁ")])
def bstack11111ll11_opy_(options, bstack1lll1l1ll_opy_):
  if bstack11111ll_opy_ (u"ࠬࡶࡲࡦࡨࡶࠫং") in bstack1lll1l1ll_opy_:
    for bstack111lllll1_opy_ in bstack1lll1l1ll_opy_[bstack11111ll_opy_ (u"࠭ࡰࡳࡧࡩࡷࠬঃ")]:
      if bstack111lllll1_opy_ in options._preferences:
        options._preferences[bstack111lllll1_opy_] = update(options._preferences[bstack111lllll1_opy_], bstack1lll1l1ll_opy_[bstack11111ll_opy_ (u"ࠧࡱࡴࡨࡪࡸ࠭঄")][bstack111lllll1_opy_])
      else:
        options.set_preference(bstack111lllll1_opy_, bstack1lll1l1ll_opy_[bstack11111ll_opy_ (u"ࠨࡲࡵࡩ࡫ࡹࠧঅ")][bstack111lllll1_opy_])
  if bstack11111ll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧআ") in bstack1lll1l1ll_opy_:
    for arg in bstack1lll1l1ll_opy_[bstack11111ll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨই")]:
      options.add_argument(arg)
def bstack11l1lllll_opy_(options, bstack11l1l11ll_opy_):
  if bstack11111ll_opy_ (u"ࠫࡼ࡫ࡢࡷ࡫ࡨࡻࠬঈ") in bstack11l1l11ll_opy_:
    options.use_webview(bool(bstack11l1l11ll_opy_[bstack11111ll_opy_ (u"ࠬࡽࡥࡣࡸ࡬ࡩࡼ࠭উ")]))
  bstack11lllll1_opy_(options, bstack11l1l11ll_opy_)
def bstack1lllll111_opy_(options, bstack111l1l1l_opy_):
  for bstack11l111111_opy_ in bstack111l1l1l_opy_:
    if bstack11l111111_opy_ in [bstack11111ll_opy_ (u"࠭ࡴࡦࡥ࡫ࡲࡴࡲ࡯ࡨࡻࡓࡶࡪࡼࡩࡦࡹࠪঊ"), bstack11111ll_opy_ (u"ࠧࡢࡴࡪࡷࠬঋ")]:
      next
    options.set_capability(bstack11l111111_opy_, bstack111l1l1l_opy_[bstack11l111111_opy_])
  if bstack11111ll_opy_ (u"ࠨࡣࡵ࡫ࡸ࠭ঌ") in bstack111l1l1l_opy_:
    for arg in bstack111l1l1l_opy_[bstack11111ll_opy_ (u"ࠩࡤࡶ࡬ࡹࠧ঍")]:
      options.add_argument(arg)
  if bstack11111ll_opy_ (u"ࠪࡸࡪࡩࡨ࡯ࡱ࡯ࡳ࡬ࡿࡐࡳࡧࡹ࡭ࡪࡽࠧ঎") in bstack111l1l1l_opy_:
    options.bstack11l1lll1l_opy_(bool(bstack111l1l1l_opy_[bstack11111ll_opy_ (u"ࠫࡹ࡫ࡣࡩࡰࡲࡰࡴ࡭ࡹࡑࡴࡨࡺ࡮࡫ࡷࠨএ")]))
def bstack1l1lll1l1_opy_(options, bstack1llll111l1_opy_):
  for bstack1ll1lll1l_opy_ in bstack1llll111l1_opy_:
    if bstack1ll1lll1l_opy_ in [bstack11111ll_opy_ (u"ࠬࡧࡤࡥ࡫ࡷ࡭ࡴࡴࡡ࡭ࡑࡳࡸ࡮ࡵ࡮ࡴࠩঐ"), bstack11111ll_opy_ (u"࠭ࡡࡳࡩࡶࠫ঑")]:
      next
    options._options[bstack1ll1lll1l_opy_] = bstack1llll111l1_opy_[bstack1ll1lll1l_opy_]
  if bstack11111ll_opy_ (u"ࠧࡢࡦࡧ࡭ࡹ࡯࡯࡯ࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ঒") in bstack1llll111l1_opy_:
    for bstack1111lll11_opy_ in bstack1llll111l1_opy_[bstack11111ll_opy_ (u"ࠨࡣࡧࡨ࡮ࡺࡩࡰࡰࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬও")]:
      options.bstack1111l1l11_opy_(
        bstack1111lll11_opy_, bstack1llll111l1_opy_[bstack11111ll_opy_ (u"ࠩࡤࡨࡩ࡯ࡴࡪࡱࡱࡥࡱࡕࡰࡵ࡫ࡲࡲࡸ࠭ঔ")][bstack1111lll11_opy_])
  if bstack11111ll_opy_ (u"ࠪࡥࡷ࡭ࡳࠨক") in bstack1llll111l1_opy_:
    for arg in bstack1llll111l1_opy_[bstack11111ll_opy_ (u"ࠫࡦࡸࡧࡴࠩখ")]:
      options.add_argument(arg)
def bstack1l1l1l11l_opy_(options, caps):
  if not hasattr(options, bstack11111ll_opy_ (u"ࠬࡑࡅ࡚ࠩগ")):
    return
  if options.KEY == bstack11111ll_opy_ (u"࠭ࡧࡰࡱࡪ࠾ࡨ࡮ࡲࡰ࡯ࡨࡓࡵࡺࡩࡰࡰࡶࠫঘ") and options.KEY in caps:
    bstack11lllll1_opy_(options, caps[bstack11111ll_opy_ (u"ࠧࡨࡱࡲ࡫࠿ࡩࡨࡳࡱࡰࡩࡔࡶࡴࡪࡱࡱࡷࠬঙ")])
  elif options.KEY == bstack11111ll_opy_ (u"ࠨ࡯ࡲࡾ࠿࡬ࡩࡳࡧࡩࡳࡽࡕࡰࡵ࡫ࡲࡲࡸ࠭চ") and options.KEY in caps:
    bstack11111ll11_opy_(options, caps[bstack11111ll_opy_ (u"ࠩࡰࡳࡿࡀࡦࡪࡴࡨࡪࡴࡾࡏࡱࡶ࡬ࡳࡳࡹࠧছ")])
  elif options.KEY == bstack11111ll_opy_ (u"ࠪࡷࡦ࡬ࡡࡳ࡫࠱ࡳࡵࡺࡩࡰࡰࡶࠫজ") and options.KEY in caps:
    bstack1lllll111_opy_(options, caps[bstack11111ll_opy_ (u"ࠫࡸࡧࡦࡢࡴ࡬࠲ࡴࡶࡴࡪࡱࡱࡷࠬঝ")])
  elif options.KEY == bstack11111ll_opy_ (u"ࠬࡳࡳ࠻ࡧࡧ࡫ࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ঞ") and options.KEY in caps:
    bstack11l1lllll_opy_(options, caps[bstack11111ll_opy_ (u"࠭࡭ࡴ࠼ࡨࡨ࡬࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧট")])
  elif options.KEY == bstack11111ll_opy_ (u"ࠧࡴࡧ࠽࡭ࡪࡕࡰࡵ࡫ࡲࡲࡸ࠭ঠ") and options.KEY in caps:
    bstack1l1lll1l1_opy_(options, caps[bstack11111ll_opy_ (u"ࠨࡵࡨ࠾࡮࡫ࡏࡱࡶ࡬ࡳࡳࡹࠧড")])
def bstack1l1ll1l11_opy_(caps):
  global bstack1llll11l11_opy_
  if bstack1llll11l11_opy_:
    if bstack1l1111l11_opy_() < version.parse(bstack11111ll_opy_ (u"ࠩ࠵࠲࠸࠴࠰ࠨঢ")):
      return None
    else:
      from appium.options.common.base import AppiumOptions
      options = AppiumOptions().load_capabilities(caps)
      return options
  else:
    browser = bstack11111ll_opy_ (u"ࠪࡧ࡭ࡸ࡯࡮ࡧࠪণ")
    if bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡓࡧ࡭ࡦࠩত") in caps:
      browser = caps[bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪথ")]
    elif bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࠧদ") in caps:
      browser = caps[bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨধ")]
    browser = str(browser).lower()
    if browser == bstack11111ll_opy_ (u"ࠨ࡫ࡳ࡬ࡴࡴࡥࠨন") or browser == bstack11111ll_opy_ (u"ࠩ࡬ࡴࡦࡪࠧ঩"):
      browser = bstack11111ll_opy_ (u"ࠪࡷࡦ࡬ࡡࡳ࡫ࠪপ")
    if browser == bstack11111ll_opy_ (u"ࠫࡸࡧ࡭ࡴࡷࡱ࡫ࠬফ"):
      browser = bstack11111ll_opy_ (u"ࠬࡩࡨࡳࡱࡰࡩࠬব")
    if browser not in [bstack11111ll_opy_ (u"࠭ࡣࡩࡴࡲࡱࡪ࠭ভ"), bstack11111ll_opy_ (u"ࠧࡦࡦࡪࡩࠬম"), bstack11111ll_opy_ (u"ࠨ࡫ࡨࠫয"), bstack11111ll_opy_ (u"ࠩࡶࡥ࡫ࡧࡲࡪࠩর"), bstack11111ll_opy_ (u"ࠪࡪ࡮ࡸࡥࡧࡱࡻࠫ঱")]:
      return None
    try:
      package = bstack11111ll_opy_ (u"ࠫࡸ࡫࡬ࡦࡰ࡬ࡹࡲ࠴ࡷࡦࡤࡧࡶ࡮ࡼࡥࡳ࠰ࡾࢁ࠳ࡵࡰࡵ࡫ࡲࡲࡸ࠭ল").format(browser)
      name = bstack11111ll_opy_ (u"ࠬࡕࡰࡵ࡫ࡲࡲࡸ࠭঳")
      browser_options = getattr(__import__(package, fromlist=[name]), name)
      options = browser_options()
      if not bstack1l11l1l1l_opy_(options):
        return None
      for bstack1lll1111l1_opy_ in caps.keys():
        options.set_capability(bstack1lll1111l1_opy_, caps[bstack1lll1111l1_opy_])
      bstack1l1l1l11l_opy_(options, caps)
      return options
    except Exception as e:
      logger.debug(str(e))
      return None
def bstack1l111llll_opy_(options, bstack1l11l11l_opy_):
  if not bstack1l11l1l1l_opy_(options):
    return
  for bstack1lll1111l1_opy_ in bstack1l11l11l_opy_.keys():
    if bstack1lll1111l1_opy_ in bstack1l1111111_opy_:
      next
    if bstack1lll1111l1_opy_ in options._caps and type(options._caps[bstack1lll1111l1_opy_]) in [dict, list]:
      options._caps[bstack1lll1111l1_opy_] = update(options._caps[bstack1lll1111l1_opy_], bstack1l11l11l_opy_[bstack1lll1111l1_opy_])
    else:
      options.set_capability(bstack1lll1111l1_opy_, bstack1l11l11l_opy_[bstack1lll1111l1_opy_])
  bstack1l1l1l11l_opy_(options, bstack1l11l11l_opy_)
  if bstack11111ll_opy_ (u"࠭࡭ࡰࡼ࠽ࡨࡪࡨࡵࡨࡩࡨࡶࡆࡪࡤࡳࡧࡶࡷࠬ঴") in options._caps:
    if options._caps[bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡏࡣࡰࡩࠬ঵")] and options._caps[bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭শ")].lower() != bstack11111ll_opy_ (u"ࠩࡩ࡭ࡷ࡫ࡦࡰࡺࠪষ"):
      del options._caps[bstack11111ll_opy_ (u"ࠪࡱࡴࢀ࠺ࡥࡧࡥࡹ࡬࡭ࡥࡳࡃࡧࡨࡷ࡫ࡳࡴࠩস")]
def bstack1l111111_opy_(proxy_config):
  if bstack11111ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨহ") in proxy_config:
    proxy_config[bstack11111ll_opy_ (u"ࠬࡹࡳ࡭ࡒࡵࡳࡽࡿࠧ঺")] = proxy_config[bstack11111ll_opy_ (u"࠭ࡨࡵࡶࡳࡷࡕࡸ࡯ࡹࡻࠪ঻")]
    del (proxy_config[bstack11111ll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡖࡲࡰࡺࡼ়ࠫ")])
  if bstack11111ll_opy_ (u"ࠨࡲࡵࡳࡽࡿࡔࡺࡲࡨࠫঽ") in proxy_config and proxy_config[bstack11111ll_opy_ (u"ࠩࡳࡶࡴࡾࡹࡕࡻࡳࡩࠬা")].lower() != bstack11111ll_opy_ (u"ࠪࡨ࡮ࡸࡥࡤࡶࠪি"):
    proxy_config[bstack11111ll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࡗࡽࡵ࡫ࠧী")] = bstack11111ll_opy_ (u"ࠬࡳࡡ࡯ࡷࡤࡰࠬু")
  if bstack11111ll_opy_ (u"࠭ࡰࡳࡱࡻࡽࡆࡻࡴࡰࡥࡲࡲ࡫࡯ࡧࡖࡴ࡯ࠫূ") in proxy_config:
    proxy_config[bstack11111ll_opy_ (u"ࠧࡱࡴࡲࡼࡾ࡚ࡹࡱࡧࠪৃ")] = bstack11111ll_opy_ (u"ࠨࡲࡤࡧࠬৄ")
  return proxy_config
def bstack11lll1111_opy_(config, proxy):
  from selenium.webdriver.common.proxy import Proxy
  if not bstack11111ll_opy_ (u"ࠩࡳࡶࡴࡾࡹࠨ৅") in config:
    return proxy
  config[bstack11111ll_opy_ (u"ࠪࡴࡷࡵࡸࡺࠩ৆")] = bstack1l111111_opy_(config[bstack11111ll_opy_ (u"ࠫࡵࡸ࡯ࡹࡻࠪে")])
  if proxy == None:
    proxy = Proxy(config[bstack11111ll_opy_ (u"ࠬࡶࡲࡰࡺࡼࠫৈ")])
  return proxy
def bstack1111lll1_opy_(self):
  global CONFIG
  global bstack11l11l11l_opy_
  try:
    proxy = bstack11l1l1lll_opy_(CONFIG)
    if proxy:
      if proxy.endswith(bstack11111ll_opy_ (u"࠭࠮ࡱࡣࡦࠫ৉")):
        proxies = bstack1llllll11l_opy_(proxy, bstack11lll111l_opy_())
        if len(proxies) > 0:
          protocol, bstack11ll11ll1_opy_ = proxies.popitem()
          if bstack11111ll_opy_ (u"ࠢ࠻࠱࠲ࠦ৊") in bstack11ll11ll1_opy_:
            return bstack11ll11ll1_opy_
          else:
            return bstack11111ll_opy_ (u"ࠣࡪࡷࡸࡵࡀ࠯࠰ࠤো") + bstack11ll11ll1_opy_
      else:
        return proxy
  except Exception as e:
    logger.error(bstack11111ll_opy_ (u"ࠤࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࠥࡶࡲࡰࡺࡼࠤࡺࡸ࡬ࠡ࠼ࠣࡿࢂࠨৌ").format(str(e)))
  return bstack11l11l11l_opy_(self)
def bstack11ll111l1_opy_():
  global CONFIG
  return bstack11lll1ll_opy_(CONFIG) and bstack1ll1l1l11l_opy_() >= version.parse(bstack1l111l1l1_opy_)
def bstack1l1l1111_opy_(config):
  bstack111ll111_opy_ = {}
  if bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹ্ࠧ") in config:
    bstack111ll111_opy_ = config[bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࡐࡲࡷ࡭ࡴࡴࡳࠨৎ")]
  if bstack11111ll_opy_ (u"ࠬࡲ࡯ࡤࡣ࡯ࡓࡵࡺࡩࡰࡰࡶࠫ৏") in config:
    bstack111ll111_opy_ = config[bstack11111ll_opy_ (u"࠭࡬ࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬ৐")]
  proxy = bstack11l1l1lll_opy_(config)
  if proxy:
    if proxy.endswith(bstack11111ll_opy_ (u"ࠧ࠯ࡲࡤࡧࠬ৑")) and os.path.isfile(proxy):
      bstack111ll111_opy_[bstack11111ll_opy_ (u"ࠨ࠯ࡳࡥࡨ࠳ࡦࡪ࡮ࡨࠫ৒")] = proxy
    else:
      parsed_url = None
      if proxy.endswith(bstack11111ll_opy_ (u"ࠩ࠱ࡴࡦࡩࠧ৓")):
        proxies = bstack1l11l1ll1_opy_(config, bstack11lll111l_opy_())
        if len(proxies) > 0:
          protocol, bstack11ll11ll1_opy_ = proxies.popitem()
          if bstack11111ll_opy_ (u"ࠥ࠾࠴࠵ࠢ৔") in bstack11ll11ll1_opy_:
            parsed_url = urlparse(bstack11ll11ll1_opy_)
          else:
            parsed_url = urlparse(protocol + bstack11111ll_opy_ (u"ࠦ࠿࠵࠯ࠣ৕") + bstack11ll11ll1_opy_)
      else:
        parsed_url = urlparse(proxy)
      if parsed_url and parsed_url.hostname: bstack111ll111_opy_[bstack11111ll_opy_ (u"ࠬࡶࡲࡰࡺࡼࡌࡴࡹࡴࠨ৖")] = str(parsed_url.hostname)
      if parsed_url and parsed_url.port: bstack111ll111_opy_[bstack11111ll_opy_ (u"࠭ࡰࡳࡱࡻࡽࡕࡵࡲࡵࠩৗ")] = str(parsed_url.port)
      if parsed_url and parsed_url.username: bstack111ll111_opy_[bstack11111ll_opy_ (u"ࠧࡱࡴࡲࡼࡾ࡛ࡳࡦࡴࠪ৘")] = str(parsed_url.username)
      if parsed_url and parsed_url.password: bstack111ll111_opy_[bstack11111ll_opy_ (u"ࠨࡲࡵࡳࡽࡿࡐࡢࡵࡶࠫ৙")] = str(parsed_url.password)
  return bstack111ll111_opy_
def bstack1ll1l1ll11_opy_(config):
  if bstack11111ll_opy_ (u"ࠩࡷࡩࡸࡺࡃࡰࡰࡷࡩࡽࡺࡏࡱࡶ࡬ࡳࡳࡹࠧ৚") in config:
    return config[bstack11111ll_opy_ (u"ࠪࡸࡪࡹࡴࡄࡱࡱࡸࡪࡾࡴࡐࡲࡷ࡭ࡴࡴࡳࠨ৛")]
  return {}
def bstack11l1l1l1_opy_(caps):
  global bstack1llll1l1l1_opy_
  if bstack11111ll_opy_ (u"ࠫࡧࡹࡴࡢࡥ࡮࠾ࡴࡶࡴࡪࡱࡱࡷࠬড়") in caps:
    caps[bstack11111ll_opy_ (u"ࠬࡨࡳࡵࡣࡦ࡯࠿ࡵࡰࡵ࡫ࡲࡲࡸ࠭ঢ়")][bstack11111ll_opy_ (u"࠭࡬ࡰࡥࡤࡰࠬ৞")] = True
    if bstack1llll1l1l1_opy_:
      caps[bstack11111ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࠺ࡰࡲࡷ࡭ࡴࡴࡳࠨয়")][bstack11111ll_opy_ (u"ࠨ࡮ࡲࡧࡦࡲࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪৠ")] = bstack1llll1l1l1_opy_
  else:
    caps[bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯࡮ࡲࡧࡦࡲࠧৡ")] = True
    if bstack1llll1l1l1_opy_:
      caps[bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬࠰࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫৢ")] = bstack1llll1l1l1_opy_
def bstack1ll1ll1111_opy_():
  global CONFIG
  if bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨৣ") in CONFIG and CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩ৤")]:
    bstack111ll111_opy_ = bstack1l1l1111_opy_(CONFIG)
    bstack1lll1llll1_opy_(CONFIG[bstack11111ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩ৥")], bstack111ll111_opy_)
def bstack1lll1llll1_opy_(key, bstack111ll111_opy_):
  global bstack1ll11lll1_opy_
  logger.info(bstack1ll1ll1l1l_opy_)
  try:
    bstack1ll11lll1_opy_ = Local()
    bstack1111lllll_opy_ = {bstack11111ll_opy_ (u"ࠧ࡬ࡧࡼࠫ০"): key}
    bstack1111lllll_opy_.update(bstack111ll111_opy_)
    logger.debug(bstack11ll1lll1_opy_.format(str(bstack1111lllll_opy_)))
    bstack1ll11lll1_opy_.start(**bstack1111lllll_opy_)
    if bstack1ll11lll1_opy_.isRunning():
      logger.info(bstack1lllllll1_opy_)
  except Exception as e:
    bstack11l1ll11_opy_(bstack11l1ll11l_opy_.format(str(e)))
def bstack11l11l11_opy_():
  global bstack1ll11lll1_opy_
  if bstack1ll11lll1_opy_.isRunning():
    logger.info(bstack111ll1111_opy_)
    bstack1ll11lll1_opy_.stop()
  bstack1ll11lll1_opy_ = None
def bstack1lll1ll111_opy_(bstack11111l11l_opy_=[]):
  global CONFIG
  bstack1ll1l1l1ll_opy_ = []
  bstack11lll11ll_opy_ = [bstack11111ll_opy_ (u"ࠨࡱࡶࠫ১"), bstack11111ll_opy_ (u"ࠩࡲࡷ࡛࡫ࡲࡴ࡫ࡲࡲࠬ২"), bstack11111ll_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࡑࡥࡲ࡫ࠧ৩"), bstack11111ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲ࡜ࡥࡳࡵ࡬ࡳࡳ࠭৪"), bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡔࡡ࡮ࡧࠪ৫"), bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡖࡦࡴࡶ࡭ࡴࡴࠧ৬")]
  try:
    for err in bstack11111l11l_opy_:
      bstack1ll1l11111_opy_ = {}
      for k in bstack11lll11ll_opy_:
        val = CONFIG[bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ৭")][int(err[bstack11111ll_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ৮")])].get(k)
        if val:
          bstack1ll1l11111_opy_[k] = val
      bstack1ll1l11111_opy_[bstack11111ll_opy_ (u"ࠩࡷࡩࡸࡺࡳࠨ৯")] = {
        err[bstack11111ll_opy_ (u"ࠪࡲࡦࡳࡥࠨৰ")]: err[bstack11111ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪৱ")]
      }
      bstack1ll1l1l1ll_opy_.append(bstack1ll1l11111_opy_)
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡧࡱࡵࡱࡦࡺࡴࡪࡰࡪࠤࡩࡧࡴࡢࠢࡩࡳࡷࠦࡥࡷࡧࡱࡸ࠿ࠦࠧ৲") + str(e))
  finally:
    return bstack1ll1l1l1ll_opy_
def bstack11ll11l1l_opy_():
  global bstack1l11llll1_opy_
  global bstack111lll1ll_opy_
  global bstack1ll1l1111_opy_
  if bstack1l11llll1_opy_:
    logger.warning(bstack1l1ll1l1l_opy_.format(str(bstack1l11llll1_opy_)))
  logger.info(bstack111111ll1_opy_)
  global bstack1ll11lll1_opy_
  if bstack1ll11lll1_opy_:
    bstack11l11l11_opy_()
  try:
    for driver in bstack111lll1ll_opy_:
      driver.quit()
  except Exception as e:
    pass
  logger.info(bstack1l1ll1ll1_opy_)
  bstack11lll1l1_opy_()
  if len(bstack1ll1l1111_opy_) > 0:
    message = bstack1lll1ll111_opy_(bstack1ll1l1111_opy_)
    bstack11lll1l1_opy_(message)
  else:
    bstack11lll1l1_opy_()
def bstack11l1l1ll1_opy_(self, *args):
  logger.error(bstack1lll1l1l1_opy_)
  bstack11ll11l1l_opy_()
  sys.exit(1)
def bstack11l1ll11_opy_(err):
  logger.critical(bstack11llllll_opy_.format(str(err)))
  bstack11lll1l1_opy_(bstack11llllll_opy_.format(str(err)))
  atexit.unregister(bstack11ll11l1l_opy_)
  sys.exit(1)
def bstack1111ll11l_opy_(error, message):
  logger.critical(str(error))
  logger.critical(message)
  bstack11lll1l1_opy_(message)
  atexit.unregister(bstack11ll11l1l_opy_)
  sys.exit(1)
def bstack1ll1l1l111_opy_():
  global CONFIG
  global bstack1l11l1l1_opy_
  global bstack11111l1ll_opy_
  global bstack11llll1l_opy_
  CONFIG = bstack1l1lll111_opy_()
  bstack1ll111lll_opy_()
  bstack1llll1l111_opy_()
  CONFIG = bstack1lll11l1ll_opy_(CONFIG)
  update(CONFIG, bstack11111l1ll_opy_)
  update(CONFIG, bstack1l11l1l1_opy_)
  CONFIG = bstack1l11l111l_opy_(CONFIG)
  bstack11llll1l_opy_ = bstack111ll1l11_opy_(CONFIG)
  bstack1llllll1l1_opy_.set_property(bstack11111ll_opy_ (u"࠭ࡢࡴࡶࡤࡧࡰࡥࡳࡦࡵࡶ࡭ࡴࡴࠧ৳"), bstack11llll1l_opy_)
  if (bstack11111ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪ৴") in CONFIG and bstack11111ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫ৵") in bstack1l11l1l1_opy_) or (
          bstack11111ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ৶") in CONFIG and bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭৷") not in bstack11111l1ll_opy_):
    if os.getenv(bstack11111ll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡣࡈࡕࡍࡃࡋࡑࡉࡉࡥࡂࡖࡋࡏࡈࡤࡏࡄࠨ৸")):
      CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸࠧ৹")] = os.getenv(bstack11111ll_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡥࡃࡐࡏࡅࡍࡓࡋࡄࡠࡄࡘࡍࡑࡊ࡟ࡊࡆࠪ৺"))
    else:
      bstack1lll11lll_opy_()
  elif (bstack11111ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪ৻") not in CONFIG and bstack11111ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪৼ") in CONFIG) or (
          bstack11111ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡏࡣࡰࡩࠬ৽") in bstack11111l1ll_opy_ and bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡐࡤࡱࡪ࠭৾") not in bstack1l11l1l1_opy_):
    del (CONFIG[bstack11111ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭৿")])
  if bstack111lll111_opy_(CONFIG):
    bstack11l1ll11_opy_(bstack111111ll_opy_)
  bstack11l11l1ll_opy_()
  bstack11ll1l111_opy_()
  if bstack1llll11l11_opy_:
    CONFIG[bstack11111ll_opy_ (u"ࠬࡧࡰࡱࠩ਀")] = bstack1lll111ll1_opy_(CONFIG)
    logger.info(bstack1llll1111_opy_.format(CONFIG[bstack11111ll_opy_ (u"࠭ࡡࡱࡲࠪਁ")]))
def bstack11ll1l111_opy_():
  global CONFIG
  global bstack1llll11l11_opy_
  if bstack11111ll_opy_ (u"ࠧࡢࡲࡳࠫਂ") in CONFIG:
    try:
      from appium import version
    except Exception as e:
      bstack1111ll11l_opy_(e, bstack11llllll1_opy_)
    bstack1llll11l11_opy_ = True
    bstack1llllll1l1_opy_.set_property(bstack11111ll_opy_ (u"ࠨࡣࡳࡴࡤࡧࡵࡵࡱࡰࡥࡹ࡫ࠧਃ"), True)
def bstack1lll111ll1_opy_(config):
  bstack11l111ll_opy_ = bstack11111ll_opy_ (u"ࠩࠪ਄")
  app = config[bstack11111ll_opy_ (u"ࠪࡥࡵࡶࠧਅ")]
  if isinstance(app, str):
    if os.path.splitext(app)[1] in bstack11llll1l1_opy_:
      if os.path.exists(app):
        bstack11l111ll_opy_ = bstack1llllllll_opy_(config, app)
      elif bstack1l111l1ll_opy_(app):
        bstack11l111ll_opy_ = app
      else:
        bstack11l1ll11_opy_(bstack1111ll111_opy_.format(app))
    else:
      if bstack1l111l1ll_opy_(app):
        bstack11l111ll_opy_ = app
      elif os.path.exists(app):
        bstack11l111ll_opy_ = bstack1llllllll_opy_(app)
      else:
        bstack11l1ll11_opy_(bstack1llllllll1_opy_)
  else:
    if len(app) > 2:
      bstack11l1ll11_opy_(bstack1ll11lll1l_opy_)
    elif len(app) == 2:
      if bstack11111ll_opy_ (u"ࠫࡵࡧࡴࡩࠩਆ") in app and bstack11111ll_opy_ (u"ࠬࡩࡵࡴࡶࡲࡱࡤ࡯ࡤࠨਇ") in app:
        if os.path.exists(app[bstack11111ll_opy_ (u"࠭ࡰࡢࡶ࡫ࠫਈ")]):
          bstack11l111ll_opy_ = bstack1llllllll_opy_(config, app[bstack11111ll_opy_ (u"ࠧࡱࡣࡷ࡬ࠬਉ")], app[bstack11111ll_opy_ (u"ࠨࡥࡸࡷࡹࡵ࡭ࡠ࡫ࡧࠫਊ")])
        else:
          bstack11l1ll11_opy_(bstack1111ll111_opy_.format(app))
      else:
        bstack11l1ll11_opy_(bstack1ll11lll1l_opy_)
    else:
      for key in app:
        if key in bstack1ll1l111ll_opy_:
          if key == bstack11111ll_opy_ (u"ࠩࡳࡥࡹ࡮ࠧ਋"):
            if os.path.exists(app[key]):
              bstack11l111ll_opy_ = bstack1llllllll_opy_(config, app[key])
            else:
              bstack11l1ll11_opy_(bstack1111ll111_opy_.format(app))
          else:
            bstack11l111ll_opy_ = app[key]
        else:
          bstack11l1ll11_opy_(bstack1lll1ll1l_opy_)
  return bstack11l111ll_opy_
def bstack1l111l1ll_opy_(bstack11l111ll_opy_):
  import re
  bstack111l11l1l_opy_ = re.compile(bstack11111ll_opy_ (u"ࡵࠦࡣࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺࡞ࡢ࠲ࡡ࠳࡝ࠫࠦࠥ਌"))
  bstack111111l11_opy_ = re.compile(bstack11111ll_opy_ (u"ࡶࠧࡤ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻࡟ࡣ࠳ࡢ࠭࡞ࠬ࠲࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡜ࡠ࠰࡟࠱ࡢ࠰ࠤࠣ਍"))
  if bstack11111ll_opy_ (u"ࠬࡨࡳ࠻࠱࠲ࠫ਎") in bstack11l111ll_opy_ or re.fullmatch(bstack111l11l1l_opy_, bstack11l111ll_opy_) or re.fullmatch(bstack111111l11_opy_, bstack11l111ll_opy_):
    return True
  else:
    return False
def bstack1llllllll_opy_(config, path, bstack11l1lll11_opy_=None):
  import requests
  from requests_toolbelt.multipart.encoder import MultipartEncoder
  import hashlib
  md5_hash = hashlib.md5(open(os.path.abspath(path), bstack11111ll_opy_ (u"࠭ࡲࡣࠩਏ")).read()).hexdigest()
  bstack111l11111_opy_ = bstack1ll1l1ll1_opy_(md5_hash)
  bstack11l111ll_opy_ = None
  if bstack111l11111_opy_:
    logger.info(bstack1llll1l11l_opy_.format(bstack111l11111_opy_, md5_hash))
    return bstack111l11111_opy_
  bstack1ll11ll1l_opy_ = MultipartEncoder(
    fields={
      bstack11111ll_opy_ (u"ࠧࡧ࡫࡯ࡩࠬਐ"): (os.path.basename(path), open(os.path.abspath(path), bstack11111ll_opy_ (u"ࠨࡴࡥࠫ਑")), bstack11111ll_opy_ (u"ࠩࡷࡩࡽࡺ࠯ࡱ࡮ࡤ࡭ࡳ࠭਒")),
      bstack11111ll_opy_ (u"ࠪࡧࡺࡹࡴࡰ࡯ࡢ࡭ࡩ࠭ਓ"): bstack11l1lll11_opy_
    }
  )
  response = requests.post(bstack1l111l11l_opy_, data=bstack1ll11ll1l_opy_,
                           headers={bstack11111ll_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪਔ"): bstack1ll11ll1l_opy_.content_type},
                           auth=(config[bstack11111ll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧਕ")], config[bstack11111ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩਖ")]))
  try:
    res = json.loads(response.text)
    bstack11l111ll_opy_ = res[bstack11111ll_opy_ (u"ࠧࡢࡲࡳࡣࡺࡸ࡬ࠨਗ")]
    logger.info(bstack1111lll1l_opy_.format(bstack11l111ll_opy_))
    bstack1l11ll1l_opy_(md5_hash, bstack11l111ll_opy_)
  except ValueError as err:
    bstack11l1ll11_opy_(bstack1lll11l11_opy_.format(str(err)))
  return bstack11l111ll_opy_
def bstack11l11l1ll_opy_():
  global CONFIG
  global bstack1ll1l1llll_opy_
  bstack1111l11ll_opy_ = 0
  bstack11ll1111_opy_ = 1
  if bstack11111ll_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨਘ") in CONFIG:
    bstack11ll1111_opy_ = CONFIG[bstack11111ll_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩਙ")]
  if bstack11111ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭ਚ") in CONFIG:
    bstack1111l11ll_opy_ = len(CONFIG[bstack11111ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧਛ")])
  bstack1ll1l1llll_opy_ = int(bstack11ll1111_opy_) * int(bstack1111l11ll_opy_)
def bstack1ll1l1ll1_opy_(md5_hash):
  bstack1llllll1l_opy_ = os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"ࠬࢄࠧਜ")), bstack11111ll_opy_ (u"࠭࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠭ਝ"), bstack11111ll_opy_ (u"ࠧࡢࡲࡳ࡙ࡵࡲ࡯ࡢࡦࡐࡈ࠺ࡎࡡࡴࡪ࠱࡮ࡸࡵ࡮ࠨਞ"))
  if os.path.exists(bstack1llllll1l_opy_):
    bstack1111111l1_opy_ = json.load(open(bstack1llllll1l_opy_, bstack11111ll_opy_ (u"ࠨࡴࡥࠫਟ")))
    if md5_hash in bstack1111111l1_opy_:
      bstack1ll1111ll_opy_ = bstack1111111l1_opy_[md5_hash]
      bstack1l1ll1111_opy_ = datetime.datetime.now()
      bstack11111111l_opy_ = datetime.datetime.strptime(bstack1ll1111ll_opy_[bstack11111ll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬਠ")], bstack11111ll_opy_ (u"ࠪࠩࡩ࠵ࠥ࡮࠱ࠨ࡝ࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧਡ"))
      if (bstack1l1ll1111_opy_ - bstack11111111l_opy_).days > 60:
        return None
      elif version.parse(str(__version__)) > version.parse(bstack1ll1111ll_opy_[bstack11111ll_opy_ (u"ࠫࡸࡪ࡫ࡠࡸࡨࡶࡸ࡯࡯࡯ࠩਢ")]):
        return None
      return bstack1ll1111ll_opy_[bstack11111ll_opy_ (u"ࠬ࡯ࡤࠨਣ")]
  else:
    return None
def bstack1l11ll1l_opy_(md5_hash, bstack11l111ll_opy_):
  bstack11lll1lll_opy_ = os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"࠭ࡾࠨਤ")), bstack11111ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧਥ"))
  if not os.path.exists(bstack11lll1lll_opy_):
    os.makedirs(bstack11lll1lll_opy_)
  bstack1llllll1l_opy_ = os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"ࠨࢀࠪਦ")), bstack11111ll_opy_ (u"ࠩ࠱ࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࠩਧ"), bstack11111ll_opy_ (u"ࠪࡥࡵࡶࡕࡱ࡮ࡲࡥࡩࡓࡄ࠶ࡊࡤࡷ࡭࠴ࡪࡴࡱࡱࠫਨ"))
  bstack1lllllll11_opy_ = {
    bstack11111ll_opy_ (u"ࠫ࡮ࡪࠧ਩"): bstack11l111ll_opy_,
    bstack11111ll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨਪ"): datetime.datetime.strftime(datetime.datetime.now(), bstack11111ll_opy_ (u"࠭ࠥࡥ࠱ࠨࡱ࠴࡙ࠫࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪਫ")),
    bstack11111ll_opy_ (u"ࠧࡴࡦ࡮ࡣࡻ࡫ࡲࡴ࡫ࡲࡲࠬਬ"): str(__version__)
  }
  if os.path.exists(bstack1llllll1l_opy_):
    bstack1111111l1_opy_ = json.load(open(bstack1llllll1l_opy_, bstack11111ll_opy_ (u"ࠨࡴࡥࠫਭ")))
  else:
    bstack1111111l1_opy_ = {}
  bstack1111111l1_opy_[md5_hash] = bstack1lllllll11_opy_
  with open(bstack1llllll1l_opy_, bstack11111ll_opy_ (u"ࠤࡺ࠯ࠧਮ")) as outfile:
    json.dump(bstack1111111l1_opy_, outfile)
def bstack111l1lll_opy_(self):
  return
def bstack111l11ll_opy_(self):
  return
def bstack11lll11l_opy_(self):
  from selenium.webdriver.remote.webdriver import WebDriver
  WebDriver.quit(self)
def bstack1l1111lll_opy_(self):
  global bstack111lll1l_opy_
  global bstack11111lll_opy_
  global bstack11l1111l_opy_
  try:
    if bstack11111ll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࠪਯ") in bstack111lll1l_opy_ and self.session_id != None:
      bstack11ll1111l_opy_ = bstack11111ll_opy_ (u"ࠫࡵࡧࡳࡴࡧࡧࠫਰ") if len(threading.current_thread().bstackTestErrorMessages) == 0 else bstack11111ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ਱")
      bstack1llll111l_opy_ = bstack1l11ll11_opy_(bstack11111ll_opy_ (u"࠭ࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠩਲ"), bstack11111ll_opy_ (u"ࠧࠨਲ਼"), bstack11ll1111l_opy_, bstack11111ll_opy_ (u"ࠨ࠮ࠣࠫ਴").join(
        threading.current_thread().bstackTestErrorMessages), bstack11111ll_opy_ (u"ࠩࠪਵ"), bstack11111ll_opy_ (u"ࠪࠫਸ਼"))
      if self != None:
        self.execute_script(bstack1llll111l_opy_)
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠦࡊࡸࡲࡰࡴࠣࡻ࡭࡯࡬ࡦࠢࡰࡥࡷࡱࡩ࡯ࡩࠣࡷࡹࡧࡴࡶࡵ࠽ࠤࠧ਷") + str(e))
  bstack11l1111l_opy_(self)
  self.session_id = None
def bstack11ll1ll1_opy_(self, *args, **kwargs):
  bstack1lll1111l_opy_ = bstack111ll1ll1_opy_(self, *args, **kwargs)
  bstack1lll11l1l1_opy_.bstack111l11ll1_opy_(self)
  return bstack1lll1111l_opy_
def bstack1l11l1ll_opy_(self, command_executor,
             desired_capabilities=None, browser_profile=None, proxy=None,
             keep_alive=True, file_detector=None, options=None):
  global CONFIG
  global bstack11111lll_opy_
  global bstack1llll1ll11_opy_
  global bstack1ll11llll1_opy_
  global bstack1111ll11_opy_
  global bstack11l1lll1_opy_
  global bstack111lll1l_opy_
  global bstack111ll1ll1_opy_
  global bstack111lll1ll_opy_
  global bstack11111l11_opy_
  CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡗࡉࡑࠧਸ")] = str(bstack111lll1l_opy_) + str(__version__)
  command_executor = bstack11lll111l_opy_()
  logger.debug(bstack11lllll11_opy_.format(command_executor))
  proxy = bstack11lll1111_opy_(CONFIG, proxy)
  bstack11l1ll1ll_opy_ = 0 if bstack1llll1ll11_opy_ < 0 else bstack1llll1ll11_opy_
  try:
    if bstack1111ll11_opy_ is True:
      bstack11l1ll1ll_opy_ = int(multiprocessing.current_process().name)
    elif bstack11l1lll1_opy_ is True:
      bstack11l1ll1ll_opy_ = int(threading.current_thread().name)
  except:
    bstack11l1ll1ll_opy_ = 0
  bstack1l11l11l_opy_ = bstack11l111l1_opy_(CONFIG, bstack11l1ll1ll_opy_)
  logger.debug(bstack1lllll1ll_opy_.format(str(bstack1l11l11l_opy_)))
  if bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡑࡵࡣࡢ࡮ࠪਹ") in CONFIG and CONFIG[bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡒ࡯ࡤࡣ࡯ࠫ਺")]:
    bstack11l1l1l1_opy_(bstack1l11l11l_opy_)
  if desired_capabilities:
    bstack1llll111ll_opy_ = bstack1lll11l1ll_opy_(desired_capabilities)
    bstack1llll111ll_opy_[bstack11111ll_opy_ (u"ࠨࡷࡶࡩ࡜࠹ࡃࠨ਻")] = bstack11l11l1l_opy_(CONFIG)
    bstack11l1l1l11_opy_ = bstack11l111l1_opy_(bstack1llll111ll_opy_)
    if bstack11l1l1l11_opy_:
      bstack1l11l11l_opy_ = update(bstack11l1l1l11_opy_, bstack1l11l11l_opy_)
    desired_capabilities = None
  if options:
    bstack1l111llll_opy_(options, bstack1l11l11l_opy_)
  if not options:
    options = bstack1l1ll1l11_opy_(bstack1l11l11l_opy_)
  if proxy and bstack1ll1l1l11l_opy_() >= version.parse(bstack11111ll_opy_ (u"ࠩ࠷࠲࠶࠶࠮࠱਼ࠩ")):
    options.proxy(proxy)
  if options and bstack1ll1l1l11l_opy_() >= version.parse(bstack11111ll_opy_ (u"ࠪ࠷࠳࠾࠮࠱ࠩ਽")):
    desired_capabilities = None
  if (
          not options and not desired_capabilities
  ) or (
          bstack1ll1l1l11l_opy_() < version.parse(bstack11111ll_opy_ (u"ࠫ࠸࠴࠸࠯࠲ࠪਾ")) and not desired_capabilities
  ):
    desired_capabilities = {}
    desired_capabilities.update(bstack1l11l11l_opy_)
  logger.info(bstack11ll1l1ll_opy_)
  if bstack1ll1l1l11l_opy_() >= version.parse(bstack11111ll_opy_ (u"ࠬ࠺࠮࠲࠲࠱࠴ࠬਿ")):
    bstack111ll1ll1_opy_(self, command_executor=command_executor,
              options=options, keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll1l1l11l_opy_() >= version.parse(bstack11111ll_opy_ (u"࠭࠳࠯࠺࠱࠴ࠬੀ")):
    bstack111ll1ll1_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities, options=options,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  elif bstack1ll1l1l11l_opy_() >= version.parse(bstack11111ll_opy_ (u"ࠧ࠳࠰࠸࠷࠳࠶ࠧੁ")):
    bstack111ll1ll1_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive, file_detector=file_detector)
  else:
    bstack111ll1ll1_opy_(self, command_executor=command_executor,
              desired_capabilities=desired_capabilities,
              browser_profile=browser_profile, proxy=proxy,
              keep_alive=keep_alive)
  try:
    bstack111l1lll1_opy_ = bstack11111ll_opy_ (u"ࠨࠩੂ")
    if bstack1ll1l1l11l_opy_() >= version.parse(bstack11111ll_opy_ (u"ࠩ࠷࠲࠵࠴࠰ࡣ࠳ࠪ੃")):
      bstack111l1lll1_opy_ = self.caps.get(bstack11111ll_opy_ (u"ࠥࡳࡵࡺࡩ࡮ࡣ࡯ࡌࡺࡨࡕࡳ࡮ࠥ੄"))
    else:
      bstack111l1lll1_opy_ = self.capabilities.get(bstack11111ll_opy_ (u"ࠦࡴࡶࡴࡪ࡯ࡤࡰࡍࡻࡢࡖࡴ࡯ࠦ੅"))
    if bstack111l1lll1_opy_:
      if bstack1ll1l1l11l_opy_() <= version.parse(bstack11111ll_opy_ (u"ࠬ࠹࠮࠲࠵࠱࠴ࠬ੆")):
        self.command_executor._url = bstack11111ll_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢੇ") + bstack1l1l1l1ll_opy_ + bstack11111ll_opy_ (u"ࠢ࠻࠺࠳࠳ࡼࡪ࠯ࡩࡷࡥࠦੈ")
      else:
        self.command_executor._url = bstack11111ll_opy_ (u"ࠣࡪࡷࡸࡵࡹ࠺࠰࠱ࠥ੉") + bstack111l1lll1_opy_ + bstack11111ll_opy_ (u"ࠤ࠲ࡻࡩ࠵ࡨࡶࡤࠥ੊")
      logger.debug(bstack111ll11ll_opy_.format(bstack111l1lll1_opy_))
    else:
      logger.debug(bstack1111l1111_opy_.format(bstack11111ll_opy_ (u"ࠥࡓࡵࡺࡩ࡮ࡣ࡯ࠤࡍࡻࡢࠡࡰࡲࡸࠥ࡬࡯ࡶࡰࡧࠦੋ")))
  except Exception as e:
    logger.debug(bstack1111l1111_opy_.format(e))
  if bstack11111ll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪੌ") in bstack111lll1l_opy_:
    bstack1lll1lll1l_opy_(bstack1llll1ll11_opy_, bstack11111l11_opy_)
  bstack11111lll_opy_ = self.session_id
  if bstack11111ll_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸ੍ࠬ") in bstack111lll1l_opy_ or bstack11111ll_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭੎") in bstack111lll1l_opy_:
    threading.current_thread().bstack1l1111ll1_opy_ = self.session_id
    threading.current_thread().bstackSessionDriver = self
    threading.current_thread().bstackTestErrorMessages = []
    bstack1lll11l1l1_opy_.bstack111l11ll1_opy_(self)
  bstack111lll1ll_opy_.append(self)
  if bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ੏") in CONFIG and bstack11111ll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭੐") in CONFIG[bstack11111ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬੑ")][bstack11l1ll1ll_opy_]:
    bstack1ll11llll1_opy_ = CONFIG[bstack11111ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡸ࠭੒")][bstack11l1ll1ll_opy_][bstack11111ll_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩ੓")]
  logger.debug(bstack1l11l11ll_opy_.format(bstack11111lll_opy_))
try:
  try:
    import Browser
    from subprocess import Popen
    def bstack111lll11l_opy_(self, args, bufsize=-1, executable=None,
              stdin=None, stdout=None, stderr=None,
              preexec_fn=None, close_fds=True,
              shell=False, cwd=None, env=None, universal_newlines=None,
              startupinfo=None, creationflags=0,
              restore_signals=True, start_new_session=False,
              pass_fds=(), *, user=None, group=None, extra_groups=None,
              encoding=None, errors=None, text=None, umask=-1, pipesize=-1):
      global CONFIG
      global bstack1ll1llll1l_opy_
      if(bstack11111ll_opy_ (u"ࠧ࡯࡮ࡥࡧࡻ࠲࡯ࡹࠢ੔") in args[1]):
        with open(os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"࠭ࡾࠨ੕")), bstack11111ll_opy_ (u"ࠧ࠯ࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧ੖"), bstack11111ll_opy_ (u"ࠨ࠰ࡶࡩࡸࡹࡩࡰࡰ࡬ࡨࡸ࠴ࡴࡹࡶࠪ੗")), bstack11111ll_opy_ (u"ࠩࡺࠫ੘")) as fp:
          fp.write(bstack11111ll_opy_ (u"ࠥࠦਖ਼"))
        if(not os.path.exists(os.path.join(os.path.dirname(args[1]), bstack11111ll_opy_ (u"ࠦ࡮ࡴࡤࡦࡺࡢࡦࡸࡺࡡࡤ࡭࠱࡮ࡸࠨਗ਼")))):
          with open(args[1], bstack11111ll_opy_ (u"ࠬࡸࠧਜ਼")) as f:
            lines = f.readlines()
            index = next((i for i, line in enumerate(lines) if bstack11111ll_opy_ (u"࠭ࡡࡴࡻࡱࡧࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠࡠࡰࡨࡻࡕࡧࡧࡦࠪࡦࡳࡳࡺࡥࡹࡶ࠯ࠤࡵࡧࡧࡦࠢࡀࠤࡻࡵࡩࡥࠢ࠳࠭ࠬੜ") in line), None)
            if index is not None:
                lines.insert(index+2, bstack111l1ll11_opy_)
            lines.insert(1, bstack1ll1l11ll1_opy_)
            f.seek(0)
            with open(os.path.join(os.path.dirname(args[1]), bstack11111ll_opy_ (u"ࠢࡪࡰࡧࡩࡽࡥࡢࡴࡶࡤࡧࡰ࠴ࡪࡴࠤ੝")), bstack11111ll_opy_ (u"ࠨࡹࠪਫ਼")) as bstack1ll1l1lll1_opy_:
              bstack1ll1l1lll1_opy_.writelines(lines)
        CONFIG[bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡔࡆࡎࠫ੟")] = str(bstack111lll1l_opy_) + str(__version__)
        bstack11l1ll1ll_opy_ = 0 if bstack1llll1ll11_opy_ < 0 else bstack1llll1ll11_opy_
        try:
          if bstack1111ll11_opy_ is True:
            bstack11l1ll1ll_opy_ = int(multiprocessing.current_process().name)
          elif bstack11l1lll1_opy_ is True:
            bstack11l1ll1ll_opy_ = int(threading.current_thread().name)
        except:
          bstack11l1ll1ll_opy_ = 0
        CONFIG[bstack11111ll_opy_ (u"ࠥࡹࡸ࡫ࡗ࠴ࡅࠥ੠")] = False
        CONFIG[bstack11111ll_opy_ (u"ࠦ࡮ࡹࡐ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠥ੡")] = True
        bstack1l11l11l_opy_ = bstack11l111l1_opy_(CONFIG, bstack11l1ll1ll_opy_)
        logger.debug(bstack1lllll1ll_opy_.format(str(bstack1l11l11l_opy_)))
        if CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩ੢")]:
          bstack11l1l1l1_opy_(bstack1l11l11l_opy_)
        if bstack11111ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩ੣") in CONFIG and bstack11111ll_opy_ (u"ࠧࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠬ੤") in CONFIG[bstack11111ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ੥")][bstack11l1ll1ll_opy_]:
          bstack1ll11llll1_opy_ = CONFIG[bstack11111ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ੦")][bstack11l1ll1ll_opy_][bstack11111ll_opy_ (u"ࠪࡷࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠨ੧")]
        args.append(os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"ࠫࢃ࠭੨")), bstack11111ll_opy_ (u"ࠬ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠬ੩"), bstack11111ll_opy_ (u"࠭࠮ࡴࡧࡶࡷ࡮ࡵ࡮ࡪࡦࡶ࠲ࡹࡾࡴࠨ੪")))
        args.append(str(threading.get_ident()))
        args.append(json.dumps(bstack1l11l11l_opy_))
        args[1] = os.path.join(os.path.dirname(args[1]), bstack11111ll_opy_ (u"ࠢࡪࡰࡧࡩࡽࡥࡢࡴࡶࡤࡧࡰ࠴ࡪࡴࠤ੫"))
      bstack1ll1llll1l_opy_ = True
      return bstack11l11l111_opy_(self, args, bufsize=bufsize, executable=executable,
                    stdin=stdin, stdout=stdout, stderr=stderr,
                    preexec_fn=preexec_fn, close_fds=close_fds,
                    shell=shell, cwd=cwd, env=env, universal_newlines=universal_newlines,
                    startupinfo=startupinfo, creationflags=creationflags,
                    restore_signals=restore_signals, start_new_session=start_new_session,
                    pass_fds=pass_fds, user=user, group=group, extra_groups=extra_groups,
                    encoding=encoding, errors=errors, text=text, umask=umask, pipesize=pipesize)
  except Exception as e:
    pass
  import playwright._impl._api_structures
  import playwright._impl._helper
  def bstack11ll1llll_opy_(self,
        executablePath = None,
        channel = None,
        args = None,
        ignoreDefaultArgs = None,
        handleSIGINT = None,
        handleSIGTERM = None,
        handleSIGHUP = None,
        timeout = None,
        env = None,
        headless = None,
        devtools = None,
        proxy = None,
        downloadsPath = None,
        slowMo = None,
        tracesDir = None,
        chromiumSandbox = None,
        firefoxUserPrefs = None
        ):
    global CONFIG
    global bstack11111lll_opy_
    global bstack1llll1ll11_opy_
    global bstack1ll11llll1_opy_
    global bstack1111ll11_opy_
    global bstack11l1lll1_opy_
    global bstack111lll1l_opy_
    global bstack111ll1ll1_opy_
    CONFIG[bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࡓࡅࡍࠪ੬")] = str(bstack111lll1l_opy_) + str(__version__)
    bstack11l1ll1ll_opy_ = 0 if bstack1llll1ll11_opy_ < 0 else bstack1llll1ll11_opy_
    try:
      if bstack1111ll11_opy_ is True:
        bstack11l1ll1ll_opy_ = int(multiprocessing.current_process().name)
      elif bstack11l1lll1_opy_ is True:
        bstack11l1ll1ll_opy_ = int(threading.current_thread().name)
    except:
      bstack11l1ll1ll_opy_ = 0
    CONFIG[bstack11111ll_opy_ (u"ࠤ࡬ࡷࡕࡲࡡࡺࡹࡵ࡭࡬࡮ࡴࠣ੭")] = True
    bstack1l11l11l_opy_ = bstack11l111l1_opy_(CONFIG, bstack11l1ll1ll_opy_)
    logger.debug(bstack1lllll1ll_opy_.format(str(bstack1l11l11l_opy_)))
    if CONFIG[bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࠧ੮")]:
      bstack11l1l1l1_opy_(bstack1l11l11l_opy_)
    if bstack11111ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧ੯") in CONFIG and bstack11111ll_opy_ (u"ࠬࡹࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪੰ") in CONFIG[bstack11111ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡴࠩੱ")][bstack11l1ll1ll_opy_]:
      bstack1ll11llll1_opy_ = CONFIG[bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪੲ")][bstack11l1ll1ll_opy_][bstack11111ll_opy_ (u"ࠨࡵࡨࡷࡸ࡯࡯࡯ࡐࡤࡱࡪ࠭ੳ")]
    import urllib
    import json
    bstack1ll1lllll1_opy_ = bstack11111ll_opy_ (u"ࠩࡺࡷࡸࡀ࠯࠰ࡥࡧࡴ࠳ࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠲ࡨࡵ࡭࠰ࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࡄࡩࡡࡱࡵࡀࠫੴ") + urllib.parse.quote(json.dumps(bstack1l11l11l_opy_))
    browser = self.connect(bstack1ll1lllll1_opy_)
    return browser
except Exception as e:
    pass
def bstack111lll1l1_opy_():
    global bstack1ll1llll1l_opy_
    try:
        from playwright._impl._browser_type import BrowserType
        BrowserType.launch = bstack11ll1llll_opy_
        bstack1ll1llll1l_opy_ = True
    except Exception as e:
        pass
    try:
      import Browser
      from subprocess import Popen
      Popen.__init__ = bstack111lll11l_opy_
      bstack1ll1llll1l_opy_ = True
    except Exception as e:
      pass
def bstack1lll1lll11_opy_(context, bstack1lll111111_opy_):
  try:
    context.page.evaluate(bstack11111ll_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦੵ"), bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡰࡤࡱࡪࠨ࠺ࠨ੶")+ json.dumps(bstack1lll111111_opy_) + bstack11111ll_opy_ (u"ࠧࢃࡽࠣ੷"))
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠨࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࠢ࡬ࡲࠥࡶ࡬ࡢࡻࡺࡶ࡮࡭ࡨࡵࠢࡶࡩࡸࡹࡩࡰࡰࠣࡲࡦࡳࡥࠡࡽࢀࠦ੸"), e)
def bstack11l1l11l_opy_(context, message, level):
  try:
    context.page.evaluate(bstack11111ll_opy_ (u"ࠢࡠࠢࡀࡂࠥࢁࡽࠣ੹"), bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡣࡱࡲࡴࡺࡡࡵࡧࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡤࡢࡶࡤࠦ࠿࠭੺") + json.dumps(message) + bstack11111ll_opy_ (u"ࠩ࠯ࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠬ੻") + json.dumps(level) + bstack11111ll_opy_ (u"ࠪࢁࢂ࠭੼"))
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠦࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠠࡢࡰࡱࡳࡹࡧࡴࡪࡱࡱࠤࢀࢃࠢ੽"), e)
def bstack1l1l1l111_opy_(context, status, message = bstack11111ll_opy_ (u"ࠧࠨ੾")):
  try:
    if(status == bstack11111ll_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨ੿")):
      context.page.evaluate(bstack11111ll_opy_ (u"ࠢࡠࠢࡀࡂࠥࢁࡽࠣ઀"), bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡳࡧࡤࡷࡴࡴࠢ࠻ࠩઁ") + json.dumps(bstack11111ll_opy_ (u"ࠤࡖࡧࡪࡴࡡࡳ࡫ࡲࠤ࡫ࡧࡩ࡭ࡧࡧࠤࡼ࡯ࡴࡩ࠼ࠣࠦં") + str(message)) + bstack11111ll_opy_ (u"ࠪ࠰ࠧࡹࡴࡢࡶࡸࡷࠧࡀࠧઃ") + json.dumps(status) + bstack11111ll_opy_ (u"ࠦࢂࢃࠢ઄"))
    else:
      context.page.evaluate(bstack11111ll_opy_ (u"ࠧࡥࠠ࠾ࡀࠣࡿࢂࠨઅ"), bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡹࡴࡢࡶࡸࡷࠧࡀࠧઆ") + json.dumps(status) + bstack11111ll_opy_ (u"ࠢࡾࡿࠥઇ"))
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠣࡧࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱ࡮ࡤࡽࡼࡸࡩࡨࡪࡷࠤࡸ࡫ࡴࠡࡵࡨࡷࡸ࡯࡯࡯ࠢࡶࡸࡦࡺࡵࡴࠢࡾࢁࠧઈ"), e)
def bstack1l1lll11l_opy_(self, url):
  global bstack1l1l1llll_opy_
  try:
    bstack111llllll_opy_(url)
  except Exception as err:
    logger.debug(bstack11l1l1ll_opy_.format(str(err)))
  try:
    bstack1l1l1llll_opy_(self, url)
  except Exception as e:
    try:
      bstack1ll1llllll_opy_ = str(e)
      if any(err_msg in bstack1ll1llllll_opy_ for err_msg in bstack1l1l1ll1l_opy_):
        bstack111llllll_opy_(url, True)
    except Exception as err:
      logger.debug(bstack11l1l1ll_opy_.format(str(err)))
    raise e
def bstack1l111ll11_opy_(self):
  global bstack1ll11ll11_opy_
  bstack1ll11ll11_opy_ = self
  return
def bstack1lll11111_opy_(self):
  global bstack1lll111lll_opy_
  bstack1lll111lll_opy_ = self
  return
def bstack111ll111l_opy_(self, test):
  global CONFIG
  global bstack1lll111lll_opy_
  global bstack1ll11ll11_opy_
  global bstack11111lll_opy_
  global bstack1l1l1l1l1_opy_
  global bstack1ll11llll1_opy_
  global bstack111l1l11l_opy_
  global bstack1l111ll1l_opy_
  global bstack111llll11_opy_
  global bstack111lll1ll_opy_
  try:
    if not bstack11111lll_opy_:
      with open(os.path.join(os.path.expanduser(bstack11111ll_opy_ (u"ࠩࢁࠫઉ")), bstack11111ll_opy_ (u"ࠪ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪઊ"), bstack11111ll_opy_ (u"ࠫ࠳ࡹࡥࡴࡵ࡬ࡳࡳ࡯ࡤࡴ࠰ࡷࡼࡹ࠭ઋ"))) as f:
        bstack1ll1ll1ll_opy_ = json.loads(bstack11111ll_opy_ (u"ࠧࢁࠢઌ") + f.read().strip() + bstack11111ll_opy_ (u"࠭ࠢࡹࠤ࠽ࠤࠧࡿࠢࠨઍ") + bstack11111ll_opy_ (u"ࠢࡾࠤ઎"))
        bstack11111lll_opy_ = bstack1ll1ll1ll_opy_[str(threading.get_ident())]
  except:
    pass
  if bstack111lll1ll_opy_:
    for driver in bstack111lll1ll_opy_:
      if bstack11111lll_opy_ == driver.session_id:
        if test:
          bstack1lll1l11l_opy_ = str(test.data)
        if not bstack1lllll111l_opy_ and bstack1lll1l11l_opy_:
          bstack11ll1l11_opy_ = {
            bstack11111ll_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨએ"): bstack11111ll_opy_ (u"ࠩࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪઐ"),
            bstack11111ll_opy_ (u"ࠪࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸ࠭ઑ"): {
              bstack11111ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ઒"): bstack1lll1l11l_opy_
            }
          }
          bstack1llllll11_opy_ = bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࡿࠪઓ").format(json.dumps(bstack11ll1l11_opy_))
          driver.execute_script(bstack1llllll11_opy_)
        if bstack1l1l1l1l1_opy_:
          bstack1ll1ll1l11_opy_ = {
            bstack11111ll_opy_ (u"࠭ࡡࡤࡶ࡬ࡳࡳ࠭ઔ"): bstack11111ll_opy_ (u"ࠧࡢࡰࡱࡳࡹࡧࡴࡦࠩક"),
            bstack11111ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫખ"): {
              bstack11111ll_opy_ (u"ࠩࡧࡥࡹࡧࠧગ"): bstack1lll1l11l_opy_ + bstack11111ll_opy_ (u"ࠪࠤࡵࡧࡳࡴࡧࡧࠥࠬઘ"),
              bstack11111ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪઙ"): bstack11111ll_opy_ (u"ࠬ࡯࡮ࡧࡱࠪચ")
            }
          }
          bstack11ll1l11_opy_ = {
            bstack11111ll_opy_ (u"࠭ࡡࡤࡶ࡬ࡳࡳ࠭છ"): bstack11111ll_opy_ (u"ࠧࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠪજ"),
            bstack11111ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫઝ"): {
              bstack11111ll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩઞ"): bstack11111ll_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪટ")
            }
          }
          if bstack1l1l1l1l1_opy_.status == bstack11111ll_opy_ (u"ࠫࡕࡇࡓࡔࠩઠ"):
            bstack111l1111l_opy_ = bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࡿࠪડ").format(json.dumps(bstack1ll1ll1l11_opy_))
            driver.execute_script(bstack111l1111l_opy_)
            bstack1llllll11_opy_ = bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࢀࠫઢ").format(json.dumps(bstack11ll1l11_opy_))
            driver.execute_script(bstack1llllll11_opy_)
          elif bstack1l1l1l1l1_opy_.status == bstack11111ll_opy_ (u"ࠧࡇࡃࡌࡐࠬણ"):
            reason = bstack11111ll_opy_ (u"ࠣࠤત")
            bstack1111l1ll_opy_ = bstack1lll1l11l_opy_ + bstack11111ll_opy_ (u"ࠩࠣࡪࡦ࡯࡬ࡦࡦࠪથ")
            if bstack1l1l1l1l1_opy_.message:
              reason = str(bstack1l1l1l1l1_opy_.message)
              bstack1111l1ll_opy_ = bstack1111l1ll_opy_ + bstack11111ll_opy_ (u"ࠪࠤࡼ࡯ࡴࡩࠢࡨࡶࡷࡵࡲ࠻ࠢࠪદ") + reason
            bstack1ll1ll1l11_opy_[bstack11111ll_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧધ")] = {
              bstack11111ll_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫન"): bstack11111ll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬ઩"),
              bstack11111ll_opy_ (u"ࠧࡥࡣࡷࡥࠬપ"): bstack1111l1ll_opy_
            }
            bstack11ll1l11_opy_[bstack11111ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫફ")] = {
              bstack11111ll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩબ"): bstack11111ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪભ"),
              bstack11111ll_opy_ (u"ࠫࡷ࡫ࡡࡴࡱࡱࠫમ"): reason
            }
            bstack111l1111l_opy_ = bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࡿࠪય").format(json.dumps(bstack1ll1ll1l11_opy_))
            driver.execute_script(bstack111l1111l_opy_)
            bstack1llllll11_opy_ = bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࢀࠫર").format(json.dumps(bstack11ll1l11_opy_))
            driver.execute_script(bstack1llllll11_opy_)
  elif bstack11111lll_opy_:
    try:
      data = {}
      bstack1lll1l11l_opy_ = None
      if test:
        bstack1lll1l11l_opy_ = str(test.data)
      if not bstack1lllll111l_opy_ and bstack1lll1l11l_opy_:
        data[bstack11111ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬ઱")] = bstack1lll1l11l_opy_
      if bstack1l1l1l1l1_opy_:
        if bstack1l1l1l1l1_opy_.status == bstack11111ll_opy_ (u"ࠨࡒࡄࡗࡘ࠭લ"):
          data[bstack11111ll_opy_ (u"ࠩࡶࡸࡦࡺࡵࡴࠩળ")] = bstack11111ll_opy_ (u"ࠪࡴࡦࡹࡳࡦࡦࠪ઴")
        elif bstack1l1l1l1l1_opy_.status == bstack11111ll_opy_ (u"ࠫࡋࡇࡉࡍࠩવ"):
          data[bstack11111ll_opy_ (u"ࠬࡹࡴࡢࡶࡸࡷࠬશ")] = bstack11111ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭ષ")
          if bstack1l1l1l1l1_opy_.message:
            data[bstack11111ll_opy_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧસ")] = str(bstack1l1l1l1l1_opy_.message)
      user = CONFIG[bstack11111ll_opy_ (u"ࠨࡷࡶࡩࡷࡔࡡ࡮ࡧࠪહ")]
      key = CONFIG[bstack11111ll_opy_ (u"ࠩࡤࡧࡨ࡫ࡳࡴࡍࡨࡽࠬ઺")]
      url = bstack11111ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࢀࢃ࠺ࡼࡿࡃࡥࡵ࡯࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡥࡺࡺ࡯࡮ࡣࡷࡩ࠴ࡹࡥࡴࡵ࡬ࡳࡳࡹ࠯ࡼࡿ࠱࡮ࡸࡵ࡮ࠨ઻").format(user, key, bstack11111lll_opy_)
      headers = {
        bstack11111ll_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧ઼ࠪ"): bstack11111ll_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨઽ"),
      }
      if bool(data):
        requests.put(url, json=data, headers=headers)
    except Exception as e:
      logger.error(bstack1lll111l1l_opy_.format(str(e)))
  if bstack1lll111lll_opy_:
    bstack1l111ll1l_opy_(bstack1lll111lll_opy_)
  if bstack1ll11ll11_opy_:
    bstack111llll11_opy_(bstack1ll11ll11_opy_)
  bstack111l1l11l_opy_(self, test)
def bstack1lllll1l1l_opy_(self, parent, test, skip_on_failure=None, rpa=False):
  global bstack1ll11l1l1_opy_
  bstack1ll11l1l1_opy_(self, parent, test, skip_on_failure=skip_on_failure, rpa=rpa)
  global bstack1l1l1l1l1_opy_
  bstack1l1l1l1l1_opy_ = self._test
def bstack1l11lll1_opy_():
  global bstack1111llll_opy_
  try:
    if os.path.exists(bstack1111llll_opy_):
      os.remove(bstack1111llll_opy_)
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"࠭ࡅࡳࡴࡲࡶࠥ࡯࡮ࠡࡦࡨࡰࡪࡺࡩ࡯ࡩࠣࡶࡴࡨ࡯ࡵࠢࡵࡩࡵࡵࡲࡵࠢࡩ࡭ࡱ࡫࠺ࠡࠩા") + str(e))
def bstack1l1l11l1l_opy_():
  global bstack1111llll_opy_
  bstack1l111l1l_opy_ = {}
  try:
    if not os.path.isfile(bstack1111llll_opy_):
      with open(bstack1111llll_opy_, bstack11111ll_opy_ (u"ࠧࡸࠩિ")):
        pass
      with open(bstack1111llll_opy_, bstack11111ll_opy_ (u"ࠣࡹ࠮ࠦી")) as outfile:
        json.dump({}, outfile)
    if os.path.exists(bstack1111llll_opy_):
      bstack1l111l1l_opy_ = json.load(open(bstack1111llll_opy_, bstack11111ll_opy_ (u"ࠩࡵࡦࠬુ")))
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠪࡉࡷࡸ࡯ࡳࠢ࡬ࡲࠥࡸࡥࡢࡦ࡬ࡲ࡬ࠦࡲࡰࡤࡲࡸࠥࡸࡥࡱࡱࡵࡸࠥ࡬ࡩ࡭ࡧ࠽ࠤࠬૂ") + str(e))
  finally:
    return bstack1l111l1l_opy_
def bstack1lll1lll1l_opy_(platform_index, item_index):
  global bstack1111llll_opy_
  try:
    bstack1l111l1l_opy_ = bstack1l1l11l1l_opy_()
    bstack1l111l1l_opy_[item_index] = platform_index
    with open(bstack1111llll_opy_, bstack11111ll_opy_ (u"ࠦࡼ࠱ࠢૃ")) as outfile:
      json.dump(bstack1l111l1l_opy_, outfile)
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠬࡋࡲࡳࡱࡵࠤ࡮ࡴࠠࡸࡴ࡬ࡸ࡮ࡴࡧࠡࡶࡲࠤࡷࡵࡢࡰࡶࠣࡶࡪࡶ࡯ࡳࡶࠣࡪ࡮ࡲࡥ࠻ࠢࠪૄ") + str(e))
def bstack1l111l11_opy_(bstack1l1l1l1l_opy_):
  global CONFIG
  bstack1llll1ll1_opy_ = bstack11111ll_opy_ (u"࠭ࠧૅ")
  if not bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ૆") in CONFIG:
    logger.info(bstack11111ll_opy_ (u"ࠨࡐࡲࠤࡵࡲࡡࡵࡨࡲࡶࡲࡹࠠࡱࡣࡶࡷࡪࡪࠠࡶࡰࡤࡦࡱ࡫ࠠࡵࡱࠣ࡫ࡪࡴࡥࡳࡣࡷࡩࠥࡸࡥࡱࡱࡵࡸࠥ࡬࡯ࡳࠢࡕࡳࡧࡵࡴࠡࡴࡸࡲࠬે"))
  try:
    platform = CONFIG[bstack11111ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬૈ")][bstack1l1l1l1l_opy_]
    if bstack11111ll_opy_ (u"ࠪࡳࡸ࠭ૉ") in platform:
      bstack1llll1ll1_opy_ += str(platform[bstack11111ll_opy_ (u"ࠫࡴࡹࠧ૊")]) + bstack11111ll_opy_ (u"ࠬ࠲ࠠࠨો")
    if bstack11111ll_opy_ (u"࠭࡯ࡴࡘࡨࡶࡸ࡯࡯࡯ࠩૌ") in platform:
      bstack1llll1ll1_opy_ += str(platform[bstack11111ll_opy_ (u"ࠧࡰࡵ࡙ࡩࡷࡹࡩࡰࡰ્ࠪ")]) + bstack11111ll_opy_ (u"ࠨ࠮ࠣࠫ૎")
    if bstack11111ll_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࡐࡤࡱࡪ࠭૏") in platform:
      bstack1llll1ll1_opy_ += str(platform[bstack11111ll_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࡑࡥࡲ࡫ࠧૐ")]) + bstack11111ll_opy_ (u"ࠫ࠱ࠦࠧ૑")
    if bstack11111ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡖࡦࡴࡶ࡭ࡴࡴࠧ૒") in platform:
      bstack1llll1ll1_opy_ += str(platform[bstack11111ll_opy_ (u"࠭ࡰ࡭ࡣࡷࡪࡴࡸ࡭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ૓")]) + bstack11111ll_opy_ (u"ࠧ࠭ࠢࠪ૔")
    if bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡐࡤࡱࡪ࠭૕") in platform:
      bstack1llll1ll1_opy_ += str(platform[bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡑࡥࡲ࡫ࠧ૖")]) + bstack11111ll_opy_ (u"ࠪ࠰ࠥ࠭૗")
    if bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶ࡛࡫ࡲࡴ࡫ࡲࡲࠬ૘") in platform:
      bstack1llll1ll1_opy_ += str(platform[bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࡜ࡥࡳࡵ࡬ࡳࡳ࠭૙")]) + bstack11111ll_opy_ (u"࠭ࠬࠡࠩ૚")
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠧࡔࡱࡰࡩࠥ࡫ࡲࡳࡱࡵࠤ࡮ࡴࠠࡨࡧࡱࡩࡷࡧࡴࡪࡰࡪࠤࡵࡲࡡࡵࡨࡲࡶࡲࠦࡳࡵࡴ࡬ࡲ࡬ࠦࡦࡰࡴࠣࡶࡪࡶ࡯ࡳࡶࠣ࡫ࡪࡴࡥࡳࡣࡷ࡭ࡴࡴࠧ૛") + str(e))
  finally:
    if bstack1llll1ll1_opy_[len(bstack1llll1ll1_opy_) - 2:] == bstack11111ll_opy_ (u"ࠨ࠮ࠣࠫ૜"):
      bstack1llll1ll1_opy_ = bstack1llll1ll1_opy_[:-2]
    return bstack1llll1ll1_opy_
def bstack11l1ll1l_opy_(path, bstack1llll1ll1_opy_):
  try:
    import xml.etree.ElementTree as ET
    bstack11111ll1_opy_ = ET.parse(path)
    bstack1llll11111_opy_ = bstack11111ll1_opy_.getroot()
    bstack1l1l1ll11_opy_ = None
    for suite in bstack1llll11111_opy_.iter(bstack11111ll_opy_ (u"ࠩࡶࡹ࡮ࡺࡥࠨ૝")):
      if bstack11111ll_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪ૞") in suite.attrib:
        suite.attrib[bstack11111ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ૟")] += bstack11111ll_opy_ (u"ࠬࠦࠧૠ") + bstack1llll1ll1_opy_
        bstack1l1l1ll11_opy_ = suite
    bstack1lll11l11l_opy_ = None
    for robot in bstack1llll11111_opy_.iter(bstack11111ll_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬૡ")):
      bstack1lll11l11l_opy_ = robot
    bstack1ll1lll1ll_opy_ = len(bstack1lll11l11l_opy_.findall(bstack11111ll_opy_ (u"ࠧࡴࡷ࡬ࡸࡪ࠭ૢ")))
    if bstack1ll1lll1ll_opy_ == 1:
      bstack1lll11l11l_opy_.remove(bstack1lll11l11l_opy_.findall(bstack11111ll_opy_ (u"ࠨࡵࡸ࡭ࡹ࡫ࠧૣ"))[0])
      bstack111ll1l1l_opy_ = ET.Element(bstack11111ll_opy_ (u"ࠩࡶࡹ࡮ࡺࡥࠨ૤"), attrib={bstack11111ll_opy_ (u"ࠪࡲࡦࡳࡥࠨ૥"): bstack11111ll_opy_ (u"ࠫࡘࡻࡩࡵࡧࡶࠫ૦"), bstack11111ll_opy_ (u"ࠬ࡯ࡤࠨ૧"): bstack11111ll_opy_ (u"࠭ࡳ࠱ࠩ૨")})
      bstack1lll11l11l_opy_.insert(1, bstack111ll1l1l_opy_)
      bstack1lll11lll1_opy_ = None
      for suite in bstack1lll11l11l_opy_.iter(bstack11111ll_opy_ (u"ࠧࡴࡷ࡬ࡸࡪ࠭૩")):
        bstack1lll11lll1_opy_ = suite
      bstack1lll11lll1_opy_.append(bstack1l1l1ll11_opy_)
      bstack1ll1ll1lll_opy_ = None
      for status in bstack1l1l1ll11_opy_.iter(bstack11111ll_opy_ (u"ࠨࡵࡷࡥࡹࡻࡳࠨ૪")):
        bstack1ll1ll1lll_opy_ = status
      bstack1lll11lll1_opy_.append(bstack1ll1ll1lll_opy_)
    bstack11111ll1_opy_.write(path)
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠩࡈࡶࡷࡵࡲࠡ࡫ࡱࠤࡵࡧࡲࡴ࡫ࡱ࡫ࠥࡽࡨࡪ࡮ࡨࠤ࡬࡫࡮ࡦࡴࡤࡸ࡮ࡴࡧࠡࡴࡲࡦࡴࡺࠠࡳࡧࡳࡳࡷࡺࠧ૫") + str(e))
def bstack1llll1l1l_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name):
  global bstack111l1l1ll_opy_
  global CONFIG
  if bstack11111ll_opy_ (u"ࠥࡴࡾࡺࡨࡰࡰࡳࡥࡹ࡮ࠢ૬") in options:
    del options[bstack11111ll_opy_ (u"ࠦࡵࡿࡴࡩࡱࡱࡴࡦࡺࡨࠣ૭")]
  bstack1l1ll11l1_opy_ = bstack1l1l11l1l_opy_()
  for bstack11llll1ll_opy_ in bstack1l1ll11l1_opy_.keys():
    path = os.path.join(os.getcwd(), bstack11111ll_opy_ (u"ࠬࡶࡡࡣࡱࡷࡣࡷ࡫ࡳࡶ࡮ࡷࡷࠬ૮"), str(bstack11llll1ll_opy_), bstack11111ll_opy_ (u"࠭࡯ࡶࡶࡳࡹࡹ࠴ࡸ࡮࡮ࠪ૯"))
    bstack11l1ll1l_opy_(path, bstack1l111l11_opy_(bstack1l1ll11l1_opy_[bstack11llll1ll_opy_]))
  bstack1l11lll1_opy_()
  return bstack111l1l1ll_opy_(outs_dir, pabot_args, options, start_time_string, tests_root_name)
def bstack111l1llll_opy_(self, ff_profile_dir):
  global bstack1lll1ll11_opy_
  if not ff_profile_dir:
    return None
  return bstack1lll1ll11_opy_(self, ff_profile_dir)
def bstack111111l1_opy_(datasources, opts_for_run, outs_dir, pabot_args, suite_group):
  from pabot.pabot import QueueItem
  global CONFIG
  global bstack1llll1l1l1_opy_
  bstack1l1l1l11_opy_ = []
  if bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ૰") in CONFIG:
    bstack1l1l1l11_opy_ = CONFIG[bstack11111ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ૱")]
  return [
    QueueItem(
      datasources,
      outs_dir,
      opts_for_run,
      suite,
      pabot_args[bstack11111ll_opy_ (u"ࠤࡦࡳࡲࡳࡡ࡯ࡦࠥ૲")],
      pabot_args[bstack11111ll_opy_ (u"ࠥࡺࡪࡸࡢࡰࡵࡨࠦ૳")],
      argfile,
      pabot_args.get(bstack11111ll_opy_ (u"ࠦ࡭࡯ࡶࡦࠤ૴")),
      pabot_args[bstack11111ll_opy_ (u"ࠧࡶࡲࡰࡥࡨࡷࡸ࡫ࡳࠣ૵")],
      platform[0],
      bstack1llll1l1l1_opy_
    )
    for suite in suite_group
    for argfile in pabot_args[bstack11111ll_opy_ (u"ࠨࡡࡳࡩࡸࡱࡪࡴࡴࡧ࡫࡯ࡩࡸࠨ૶")] or [(bstack11111ll_opy_ (u"ࠢࠣ૷"), None)]
    for platform in enumerate(bstack1l1l1l11_opy_)
  ]
def bstack11l11llll_opy_(self, datasources, outs_dir, options,
                        execution_item, command, verbose, argfile,
                        hive=None, processes=0, platform_index=0, bstack1lllll1l11_opy_=bstack11111ll_opy_ (u"ࠨࠩ૸")):
  global bstack1lll1lllll_opy_
  self.platform_index = platform_index
  self.bstack1ll1llll1_opy_ = bstack1lllll1l11_opy_
  bstack1lll1lllll_opy_(self, datasources, outs_dir, options,
                      execution_item, command, verbose, argfile, hive, processes)
def bstack111l1ll1l_opy_(caller_id, datasources, is_last, item, outs_dir):
  global bstack1llll11ll_opy_
  global bstack1llll1lll1_opy_
  if not bstack11111ll_opy_ (u"ࠩࡹࡥࡷ࡯ࡡࡣ࡮ࡨࠫૹ") in item.options:
    item.options[bstack11111ll_opy_ (u"ࠪࡺࡦࡸࡩࡢࡤ࡯ࡩࠬૺ")] = []
  for v in item.options[bstack11111ll_opy_ (u"ࠫࡻࡧࡲࡪࡣࡥࡰࡪ࠭ૻ")]:
    if bstack11111ll_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡕࡒࡁࡕࡈࡒࡖࡒࡏࡎࡅࡇ࡛ࠫૼ") in v:
      item.options[bstack11111ll_opy_ (u"࠭ࡶࡢࡴ࡬ࡥࡧࡲࡥࠨ૽")].remove(v)
    if bstack11111ll_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑࡃࡍࡋࡄࡖࡌ࡙ࠧ૾") in v:
      item.options[bstack11111ll_opy_ (u"ࠨࡸࡤࡶ࡮ࡧࡢ࡭ࡧࠪ૿")].remove(v)
  item.options[bstack11111ll_opy_ (u"ࠩࡹࡥࡷ࡯ࡡࡣ࡮ࡨࠫ଀")].insert(0, bstack11111ll_opy_ (u"ࠪࡆࡘ࡚ࡁࡄࡍࡓࡐࡆ࡚ࡆࡐࡔࡐࡍࡓࡊࡅ࡙࠼ࡾࢁࠬଁ").format(item.platform_index))
  item.options[bstack11111ll_opy_ (u"ࠫࡻࡧࡲࡪࡣࡥࡰࡪ࠭ଂ")].insert(0, bstack11111ll_opy_ (u"ࠬࡈࡓࡕࡃࡆࡏࡉࡋࡆࡍࡑࡆࡅࡑࡏࡄࡆࡐࡗࡍࡋࡏࡅࡓ࠼ࡾࢁࠬଃ").format(item.bstack1ll1llll1_opy_))
  if bstack1llll1lll1_opy_:
    item.options[bstack11111ll_opy_ (u"࠭ࡶࡢࡴ࡬ࡥࡧࡲࡥࠨ଄")].insert(0, bstack11111ll_opy_ (u"ࠧࡃࡕࡗࡅࡈࡑࡃࡍࡋࡄࡖࡌ࡙࠺ࡼࡿࠪଅ").format(bstack1llll1lll1_opy_))
  return bstack1llll11ll_opy_(caller_id, datasources, is_last, item, outs_dir)
def bstack11l1111l1_opy_(command, item_index):
  global bstack1llll1lll1_opy_
  if bstack1llll1lll1_opy_:
    command[0] = command[0].replace(bstack11111ll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧଆ"), bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠮ࡵࡧ࡯ࠥࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱࠦ࠭࠮ࡤࡶࡸࡦࡩ࡫ࡠ࡫ࡷࡩࡲࡥࡩ࡯ࡦࡨࡼࠥ࠭ଇ") + str(
      item_index) + bstack11111ll_opy_ (u"ࠪࠤࠬଈ") + bstack1llll1lll1_opy_, 1)
  else:
    command[0] = command[0].replace(bstack11111ll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪଉ"),
                                    bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠱ࡸࡪ࡫ࠡࡴࡲࡦࡴࡺ࠭ࡪࡰࡷࡩࡷࡴࡡ࡭ࠢ࠰࠱ࡧࡹࡴࡢࡥ࡮ࡣ࡮ࡺࡥ࡮ࡡ࡬ࡲࡩ࡫ࡸࠡࠩଊ") + str(item_index), 1)
def bstack1111ll1l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index):
  global bstack1l1l1lll1_opy_
  bstack11l1111l1_opy_(command, item_index)
  return bstack1l1l1lll1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index)
def bstack1l11llll_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir):
  global bstack1l1l1lll1_opy_
  bstack11l1111l1_opy_(command, item_index)
  return bstack1l1l1lll1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir)
def bstack1ll1l1ll1l_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout):
  global bstack1l1l1lll1_opy_
  bstack11l1111l1_opy_(command, item_index)
  return bstack1l1l1lll1_opy_(command, stderr, stdout, item_name, verbose, pool_id, item_index, outs_dir, process_timeout)
def bstack11lllll1l_opy_(self, runner, quiet=False, capture=True):
  global bstack11l111l1l_opy_
  bstack11lll1l11_opy_ = bstack11l111l1l_opy_(self, runner, quiet=False, capture=True)
  if self.exception:
    if not hasattr(runner, bstack11111ll_opy_ (u"࠭ࡥࡹࡥࡨࡴࡹ࡯࡯࡯ࡡࡤࡶࡷ࠭ଋ")):
      runner.exception_arr = []
    if not hasattr(runner, bstack11111ll_opy_ (u"ࠧࡦࡺࡦࡣࡹࡸࡡࡤࡧࡥࡥࡨࡱ࡟ࡢࡴࡵࠫଌ")):
      runner.exc_traceback_arr = []
    runner.exception = self.exception
    runner.exc_traceback = self.exc_traceback
    runner.exception_arr.append(self.exception)
    runner.exc_traceback_arr.append(self.exc_traceback)
  return bstack11lll1l11_opy_
def bstack1ll11l11l_opy_(self, name, context, *args):
  global bstack1l1l1111l_opy_
  if name == bstack11111ll_opy_ (u"ࠨࡤࡨࡪࡴࡸࡥࡠࡨࡨࡥࡹࡻࡲࡦࠩ଍"):
    bstack1l1l1111l_opy_(self, name, context, *args)
    try:
      if not bstack1lllll111l_opy_:
        bstack111ll1ll_opy_ = threading.current_thread().bstackSessionDriver if bstack1111llll1_opy_(bstack11111ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨ଎")) else context.browser
        bstack1lll111111_opy_ = str(self.feature.name)
        bstack1lll1lll11_opy_(context, bstack1lll111111_opy_)
        bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢ࡯ࡣࡰࡩࠧࡀࠠࠨଏ") + json.dumps(bstack1lll111111_opy_) + bstack11111ll_opy_ (u"ࠫࢂࢃࠧଐ"))
      self.driver_before_scenario = False
    except Exception as e:
      logger.debug(bstack11111ll_opy_ (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡨࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠤ࡮ࡴࠠࡣࡧࡩࡳࡷ࡫ࠠࡧࡧࡤࡸࡺࡸࡥ࠻ࠢࡾࢁࠬ଑").format(str(e)))
  elif name == bstack11111ll_opy_ (u"࠭ࡢࡦࡨࡲࡶࡪࡥࡳࡤࡧࡱࡥࡷ࡯࡯ࠨ଒"):
    bstack1l1l1111l_opy_(self, name, context, *args)
    try:
      if not hasattr(self, bstack11111ll_opy_ (u"ࠧࡥࡴ࡬ࡺࡪࡸ࡟ࡣࡧࡩࡳࡷ࡫࡟ࡴࡥࡨࡲࡦࡸࡩࡰࠩଓ")):
        self.driver_before_scenario = True
      if (not bstack1lllll111l_opy_):
        scenario_name = args[0].name
        feature_name = bstack1lll111111_opy_ = str(self.feature.name)
        bstack1lll111111_opy_ = feature_name + bstack11111ll_opy_ (u"ࠨࠢ࠰ࠤࠬଔ") + scenario_name
        bstack111ll1ll_opy_ = threading.current_thread().bstackSessionDriver if bstack1111llll1_opy_(bstack11111ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨକ")) else context.browser
        if self.driver_before_scenario:
          bstack1lll1lll11_opy_(context, bstack1lll111111_opy_)
          bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡎࡢ࡯ࡨࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢ࡯ࡣࡰࡩࠧࡀࠠࠨଖ") + json.dumps(bstack1lll111111_opy_) + bstack11111ll_opy_ (u"ࠫࢂࢃࠧଗ"))
    except Exception as e:
      logger.debug(bstack11111ll_opy_ (u"ࠬࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡵࡨࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠤ࡮ࡴࠠࡣࡧࡩࡳࡷ࡫ࠠࡴࡥࡨࡲࡦࡸࡩࡰ࠼ࠣࡿࢂ࠭ଘ").format(str(e)))
  elif name == bstack11111ll_opy_ (u"࠭ࡡࡧࡶࡨࡶࡤࡹࡣࡦࡰࡤࡶ࡮ࡵࠧଙ"):
    try:
      bstack1l1l11lll_opy_ = args[0].status.name
      bstack111ll1ll_opy_ = threading.current_thread().bstackSessionDriver if bstack11111ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱࡓࡦࡵࡶ࡭ࡴࡴࡄࡳ࡫ࡹࡩࡷ࠭ଚ") in threading.current_thread().__dict__.keys() else context.browser
      if str(bstack1l1l11lll_opy_).lower() == bstack11111ll_opy_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨଛ"):
        bstack1lll111ll_opy_ = bstack11111ll_opy_ (u"ࠩࠪଜ")
        bstack11111l1l1_opy_ = bstack11111ll_opy_ (u"ࠪࠫଝ")
        bstack1l1l11l11_opy_ = bstack11111ll_opy_ (u"ࠫࠬଞ")
        try:
          import traceback
          bstack1lll111ll_opy_ = self.exception.__class__.__name__
          bstack1ll1ll1l1_opy_ = traceback.format_tb(self.exc_traceback)
          bstack11111l1l1_opy_ = bstack11111ll_opy_ (u"ࠬࠦࠧଟ").join(bstack1ll1ll1l1_opy_)
          bstack1l1l11l11_opy_ = bstack1ll1ll1l1_opy_[-1]
        except Exception as e:
          logger.debug(bstack1llllll1ll_opy_.format(str(e)))
        bstack1lll111ll_opy_ += bstack1l1l11l11_opy_
        bstack11l1l11l_opy_(context, json.dumps(str(args[0].name) + bstack11111ll_opy_ (u"ࠨࠠ࠮ࠢࡉࡥ࡮ࡲࡥࡥࠣ࡟ࡲࠧଠ") + str(bstack11111l1l1_opy_)),
                            bstack11111ll_opy_ (u"ࠢࡦࡴࡵࡳࡷࠨଡ"))
        if self.driver_before_scenario:
          bstack1l1l1l111_opy_(context, bstack11111ll_opy_ (u"ࠣࡨࡤ࡭ࡱ࡫ࡤࠣଢ"), bstack1lll111ll_opy_)
          bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡤࡲࡳࡵࡴࡢࡶࡨࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡥࡣࡷࡥࠧࡀࠧଣ") + json.dumps(str(args[0].name) + bstack11111ll_opy_ (u"ࠥࠤ࠲ࠦࡆࡢ࡫࡯ࡩࡩࠧ࡜࡯ࠤତ") + str(bstack11111l1l1_opy_)) + bstack11111ll_opy_ (u"ࠫ࠱ࠦࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠡࠤࡨࡶࡷࡵࡲࠣࡿࢀࠫଥ"))
        if self.driver_before_scenario:
          bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼࠤࡤࡧࡹ࡯࡯࡯ࠤ࠽ࠤࠧࡹࡥࡵࡕࡨࡷࡸ࡯࡯࡯ࡕࡷࡥࡹࡻࡳࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡸࡺࡡࡵࡷࡶࠦ࠿ࠨࡦࡢ࡫࡯ࡩࡩࠨࠬࠡࠤࡵࡩࡦࡹ࡯࡯ࠤ࠽ࠤࠬଦ") + json.dumps(bstack11111ll_opy_ (u"ࠨࡓࡤࡧࡱࡥࡷ࡯࡯ࠡࡨࡤ࡭ࡱ࡫ࡤࠡࡹ࡬ࡸ࡭ࡀࠠ࡝ࡰࠥଧ") + str(bstack1lll111ll_opy_)) + bstack11111ll_opy_ (u"ࠧࡾࡿࠪନ"))
      else:
        bstack11l1l11l_opy_(context, bstack11111ll_opy_ (u"ࠣࡒࡤࡷࡸ࡫ࡤࠢࠤ଩"), bstack11111ll_opy_ (u"ࠤ࡬ࡲ࡫ࡵࠢପ"))
        if self.driver_before_scenario:
          bstack1l1l1l111_opy_(context, bstack11111ll_opy_ (u"ࠥࡴࡦࡹࡳࡦࡦࠥଫ"))
        bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡧࡥࡹࡧࠢ࠻ࠩବ") + json.dumps(str(args[0].name) + bstack11111ll_opy_ (u"ࠧࠦ࠭ࠡࡒࡤࡷࡸ࡫ࡤࠢࠤଭ")) + bstack11111ll_opy_ (u"࠭ࠬࠡࠤ࡯ࡩࡻ࡫࡬ࠣ࠼ࠣࠦ࡮ࡴࡦࡰࠤࢀࢁࠬମ"))
        if self.driver_before_scenario:
          bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡗࡹࡧࡴࡶࡵࠥ࠰ࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࠨࡳࡵࡣࡷࡹࡸࠨ࠺ࠣࡲࡤࡷࡸ࡫ࡤࠣࡿࢀࠫଯ"))
    except Exception as e:
      logger.debug(bstack11111ll_opy_ (u"ࠨࡈࡤ࡭ࡱ࡫ࡤࠡࡶࡲࠤࡲࡧࡲ࡬ࠢࡶࡩࡸࡹࡩࡰࡰࠣࡷࡹࡧࡴࡶࡵࠣ࡭ࡳࠦࡡࡧࡶࡨࡶࠥ࡬ࡥࡢࡶࡸࡶࡪࡀࠠࡼࡿࠪର").format(str(e)))
  elif name == bstack11111ll_opy_ (u"ࠩࡤࡪࡹ࡫ࡲࡠࡨࡨࡥࡹࡻࡲࡦࠩ଱"):
    try:
      bstack111ll1ll_opy_ = threading.current_thread().bstackSessionDriver if bstack1111llll1_opy_(bstack11111ll_opy_ (u"ࠪࡦࡸࡺࡡࡤ࡭ࡖࡩࡸࡹࡩࡰࡰࡇࡶ࡮ࡼࡥࡳࠩଲ")) else context.browser
      if context.failed is True:
        bstack111l1111_opy_ = []
        bstack1l11l11l1_opy_ = []
        bstack1ll1l1l1l_opy_ = []
        bstack111ll1lll_opy_ = bstack11111ll_opy_ (u"ࠫࠬଳ")
        try:
          import traceback
          for exc in self.exception_arr:
            bstack111l1111_opy_.append(exc.__class__.__name__)
          for exc_tb in self.exc_traceback_arr:
            bstack1ll1ll1l1_opy_ = traceback.format_tb(exc_tb)
            bstack1llll1llll_opy_ = bstack11111ll_opy_ (u"ࠬࠦࠧ଴").join(bstack1ll1ll1l1_opy_)
            bstack1l11l11l1_opy_.append(bstack1llll1llll_opy_)
            bstack1ll1l1l1l_opy_.append(bstack1ll1ll1l1_opy_[-1])
        except Exception as e:
          logger.debug(bstack1llllll1ll_opy_.format(str(e)))
        bstack1lll111ll_opy_ = bstack11111ll_opy_ (u"࠭ࠧଵ")
        for i in range(len(bstack111l1111_opy_)):
          bstack1lll111ll_opy_ += bstack111l1111_opy_[i] + bstack1ll1l1l1l_opy_[i] + bstack11111ll_opy_ (u"ࠧ࡝ࡰࠪଶ")
        bstack111ll1lll_opy_ = bstack11111ll_opy_ (u"ࠨࠢࠪଷ").join(bstack1l11l11l1_opy_)
        if not self.driver_before_scenario:
          bstack11l1l11l_opy_(context, bstack111ll1lll_opy_, bstack11111ll_opy_ (u"ࠤࡨࡶࡷࡵࡲࠣସ"))
          bstack1l1l1l111_opy_(context, bstack11111ll_opy_ (u"ࠥࡪࡦ࡯࡬ࡦࡦࠥହ"), bstack1lll111ll_opy_)
          bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡧࡥࡹࡧࠢ࠻ࠩ଺") + json.dumps(bstack111ll1lll_opy_) + bstack11111ll_opy_ (u"ࠬ࠲ࠠࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠢࠥࡩࡷࡸ࡯ࡳࠤࢀࢁࠬ଻"))
          bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡖࡸࡦࡺࡵࡴࠤ࠯ࠤࠧࡧࡲࡨࡷࡰࡩࡳࡺࡳࠣ࠼ࠣࡿࠧࡹࡴࡢࡶࡸࡷࠧࡀࠢࡧࡣ࡬ࡰࡪࡪࠢ࠭ࠢࠥࡶࡪࡧࡳࡰࡰࠥ࠾଼ࠥ࠭") + json.dumps(bstack11111ll_opy_ (u"ࠢࡔࡱࡰࡩࠥࡹࡣࡦࡰࡤࡶ࡮ࡵࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢ࡟ࡲࠧଽ") + str(bstack1lll111ll_opy_)) + bstack11111ll_opy_ (u"ࠨࡿࢀࠫା"))
      else:
        if not self.driver_before_scenario:
          bstack11l1l11l_opy_(context, bstack11111ll_opy_ (u"ࠤࡉࡩࡦࡺࡵࡳࡧ࠽ࠤࠧି") + str(self.feature.name) + bstack11111ll_opy_ (u"ࠥࠤࡵࡧࡳࡴࡧࡧࠥࠧୀ"), bstack11111ll_opy_ (u"ࠦ࡮ࡴࡦࡰࠤୁ"))
          bstack1l1l1l111_opy_(context, bstack11111ll_opy_ (u"ࠧࡶࡡࡴࡵࡨࡨࠧୂ"))
          bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡩࡧࡴࡢࠤ࠽ࠫୃ") + json.dumps(bstack11111ll_opy_ (u"ࠢࡇࡧࡤࡸࡺࡸࡥ࠻ࠢࠥୄ") + str(self.feature.name) + bstack11111ll_opy_ (u"ࠣࠢࡳࡥࡸࡹࡥࡥࠣࠥ୅")) + bstack11111ll_opy_ (u"ࠩ࠯ࠤࠧࡲࡥࡷࡧ࡯ࠦ࠿ࠦࠢࡪࡰࡩࡳࠧࢃࡽࠨ୆"))
          bstack111ll1ll_opy_.execute_script(bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡷࡪࡺࡓࡦࡵࡶ࡭ࡴࡴࡓࡵࡣࡷࡹࡸࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡶࡸࡦࡺࡵࡴࠤ࠽ࠦࡵࡧࡳࡴࡧࡧࠦࢂࢃࠧେ"))
    except Exception as e:
      logger.debug(bstack11111ll_opy_ (u"ࠫࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠ࡮ࡣࡵ࡯ࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡳࡵࡣࡷࡹࡸࠦࡩ࡯ࠢࡤࡪࡹ࡫ࡲࠡࡨࡨࡥࡹࡻࡲࡦ࠼ࠣࡿࢂ࠭ୈ").format(str(e)))
  else:
    bstack1l1l1111l_opy_(self, name, context, *args)
  if name in [bstack11111ll_opy_ (u"ࠬࡧࡦࡵࡧࡵࡣ࡫࡫ࡡࡵࡷࡵࡩࠬ୉"), bstack11111ll_opy_ (u"࠭ࡡࡧࡶࡨࡶࡤࡹࡣࡦࡰࡤࡶ࡮ࡵࠧ୊")]:
    bstack1l1l1111l_opy_(self, name, context, *args)
    if (name == bstack11111ll_opy_ (u"ࠧࡢࡨࡷࡩࡷࡥࡳࡤࡧࡱࡥࡷ࡯࡯ࠨୋ") and self.driver_before_scenario) or (
            name == bstack11111ll_opy_ (u"ࠨࡣࡩࡸࡪࡸ࡟ࡧࡧࡤࡸࡺࡸࡥࠨୌ") and not self.driver_before_scenario):
      try:
        bstack111ll1ll_opy_ = threading.current_thread().bstackSessionDriver if bstack1111llll1_opy_(bstack11111ll_opy_ (u"ࠩࡥࡷࡹࡧࡣ࡬ࡕࡨࡷࡸ࡯࡯࡯ࡆࡵ࡭ࡻ࡫ࡲࠨ୍")) else context.browser
        bstack111ll1ll_opy_.quit()
      except Exception:
        pass
def bstack1lll1l11l1_opy_(config, startdir):
  return bstack11111ll_opy_ (u"ࠥࡨࡷ࡯ࡶࡦࡴ࠽ࠤࢀ࠶ࡽࠣ୎").format(bstack11111ll_opy_ (u"ࠦࡇࡸ࡯ࡸࡵࡨࡶࡘࡺࡡࡤ࡭ࠥ୏"))
class Notset:
  def __repr__(self):
    return bstack11111ll_opy_ (u"ࠧࡂࡎࡐࡖࡖࡉ࡙ࡄࠢ୐")
notset = Notset()
def bstack1l1llll1l_opy_(self, name: str, default=notset, skip: bool = False):
  global bstack11l111l11_opy_
  if str(name).lower() == bstack11111ll_opy_ (u"࠭ࡤࡳ࡫ࡹࡩࡷ࠭୑"):
    return bstack11111ll_opy_ (u"ࠢࡃࡴࡲࡻࡸ࡫ࡲࡔࡶࡤࡧࡰࠨ୒")
  else:
    return bstack11l111l11_opy_(self, name, default, skip)
def bstack11l1111ll_opy_(item, when):
  global bstack11l111lll_opy_
  try:
    bstack11l111lll_opy_(item, when)
  except Exception as e:
    pass
def bstack1ll1ll11l1_opy_():
  return
def bstack1l11ll11_opy_(type, name, status, reason, bstack1l1l111l1_opy_, bstack1ll1l11lll_opy_):
  bstack11ll1l11_opy_ = {
    bstack11111ll_opy_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࠨ୓"): type,
    bstack11111ll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ୔"): {}
  }
  if type == bstack11111ll_opy_ (u"ࠪࡥࡳࡴ࡯ࡵࡣࡷࡩࠬ୕"):
    bstack11ll1l11_opy_[bstack11111ll_opy_ (u"ࠫࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠧୖ")][bstack11111ll_opy_ (u"ࠬࡲࡥࡷࡧ࡯ࠫୗ")] = bstack1l1l111l1_opy_
    bstack11ll1l11_opy_[bstack11111ll_opy_ (u"࠭ࡡࡳࡩࡸࡱࡪࡴࡴࡴࠩ୘")][bstack11111ll_opy_ (u"ࠧࡥࡣࡷࡥࠬ୙")] = json.dumps(str(bstack1ll1l11lll_opy_))
  if type == bstack11111ll_opy_ (u"ࠨࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡓࡧ࡭ࡦࠩ୚"):
    bstack11ll1l11_opy_[bstack11111ll_opy_ (u"ࠩࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠬ୛")][bstack11111ll_opy_ (u"ࠪࡲࡦࡳࡥࠨଡ଼")] = name
  if type == bstack11111ll_opy_ (u"ࠫࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠧଢ଼"):
    bstack11ll1l11_opy_[bstack11111ll_opy_ (u"ࠬࡧࡲࡨࡷࡰࡩࡳࡺࡳࠨ୞")][bstack11111ll_opy_ (u"࠭ࡳࡵࡣࡷࡹࡸ࠭ୟ")] = status
    if status == bstack11111ll_opy_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧୠ"):
      bstack11ll1l11_opy_[bstack11111ll_opy_ (u"ࠨࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠫୡ")][bstack11111ll_opy_ (u"ࠩࡵࡩࡦࡹ࡯࡯ࠩୢ")] = json.dumps(str(reason))
  bstack1llllll11_opy_ = bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡷࡹࡧࡣ࡬ࡡࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠥࢁࡽࠨୣ").format(json.dumps(bstack11ll1l11_opy_))
  return bstack1llllll11_opy_
def bstack11ll11l11_opy_(item, call, rep):
  global bstack11l11lll_opy_
  global bstack111lll1ll_opy_
  global bstack1lllll111l_opy_
  name = bstack11111ll_opy_ (u"ࠫࠬ୤")
  try:
    if rep.when == bstack11111ll_opy_ (u"ࠬࡩࡡ࡭࡮ࠪ୥"):
      bstack11111lll_opy_ = threading.current_thread().bstack1l1111ll1_opy_
      try:
        if not bstack1lllll111l_opy_:
          name = str(rep.nodeid)
          bstack1llll111l_opy_ = bstack1l11ll11_opy_(bstack11111ll_opy_ (u"࠭ࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧ୦"), name, bstack11111ll_opy_ (u"ࠧࠨ୧"), bstack11111ll_opy_ (u"ࠨࠩ୨"), bstack11111ll_opy_ (u"ࠩࠪ୩"), bstack11111ll_opy_ (u"ࠪࠫ୪"))
          for driver in bstack111lll1ll_opy_:
            if bstack11111lll_opy_ == driver.session_id:
              driver.execute_script(bstack1llll111l_opy_)
      except Exception as e:
        logger.debug(bstack11111ll_opy_ (u"ࠫࡊࡸࡲࡰࡴࠣ࡭ࡳࠦࡳࡦࡶࡷ࡭ࡳ࡭ࠠࡴࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠥ࡬࡯ࡳࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡳࡦࡵࡶ࡭ࡴࡴ࠺ࠡࡽࢀࠫ୫").format(str(e)))
      try:
        status = bstack11111ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ୬") if rep.outcome.lower() == bstack11111ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭୭") else bstack11111ll_opy_ (u"ࠧࡱࡣࡶࡷࡪࡪࠧ୮")
        reason = bstack11111ll_opy_ (u"ࠨࠩ୯")
        if (reason != bstack11111ll_opy_ (u"ࠤࠥ୰")):
          try:
            if (threading.current_thread().bstackTestErrorMessages == None):
              threading.current_thread().bstackTestErrorMessages = []
          except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
          threading.current_thread().bstackTestErrorMessages.append(str(reason))
        if status == bstack11111ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪୱ"):
          reason = rep.longrepr.reprcrash.message
          if (not threading.current_thread().bstackTestErrorMessages):
            threading.current_thread().bstackTestErrorMessages = []
          threading.current_thread().bstackTestErrorMessages.append(reason)
        level = bstack11111ll_opy_ (u"ࠫ࡮ࡴࡦࡰࠩ୲") if status == bstack11111ll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬ୳") else bstack11111ll_opy_ (u"࠭ࡥࡳࡴࡲࡶࠬ୴")
        data = name + bstack11111ll_opy_ (u"ࠧࠡࡲࡤࡷࡸ࡫ࡤࠢࠩ୵") if status == bstack11111ll_opy_ (u"ࠨࡲࡤࡷࡸ࡫ࡤࠨ୶") else name + bstack11111ll_opy_ (u"ࠩࠣࡪࡦ࡯࡬ࡦࡦࠤࠤࠬ୷") + reason
        bstack1llll11lll_opy_ = bstack1l11ll11_opy_(bstack11111ll_opy_ (u"ࠪࡥࡳࡴ࡯ࡵࡣࡷࡩࠬ୸"), bstack11111ll_opy_ (u"ࠫࠬ୹"), bstack11111ll_opy_ (u"ࠬ࠭୺"), bstack11111ll_opy_ (u"࠭ࠧ୻"), level, data)
        for driver in bstack111lll1ll_opy_:
          if bstack11111lll_opy_ == driver.session_id:
            driver.execute_script(bstack1llll11lll_opy_)
      except Exception as e:
        logger.debug(bstack11111ll_opy_ (u"ࠧࡆࡴࡵࡳࡷࠦࡩ࡯ࠢࡶࡩࡹࡺࡩ࡯ࡩࠣࡷࡪࡹࡳࡪࡱࡱࠤࡨࡵ࡮ࡵࡧࡻࡸࠥ࡬࡯ࡳࠢࡳࡽࡹ࡫ࡳࡵ࠯ࡥࡨࡩࠦࡳࡦࡵࡶ࡭ࡴࡴ࠺ࠡࡽࢀࠫ୼").format(str(e)))
  except Exception as e:
    logger.debug(bstack11111ll_opy_ (u"ࠨࡇࡵࡶࡴࡸࠠࡪࡰࠣ࡫ࡪࡺࡴࡪࡰࡪࠤࡸࡺࡡࡵࡧࠣ࡭ࡳࠦࡰࡺࡶࡨࡷࡹ࠳ࡢࡥࡦࠣࡸࡪࡹࡴࠡࡵࡷࡥࡹࡻࡳ࠻ࠢࡾࢁࠬ୽").format(str(e)))
  bstack11l11lll_opy_(item, call, rep)
def bstack1lll1l1l11_opy_(framework_name):
  global bstack111lll1l_opy_
  global bstack1ll1llll1l_opy_
  global bstack1lll11111l_opy_
  bstack111lll1l_opy_ = framework_name
  logger.info(bstack1ll111l11_opy_.format(bstack111lll1l_opy_.split(bstack11111ll_opy_ (u"ࠩ࠰ࠫ୾"))[0]))
  try:
    from selenium import webdriver
    from selenium.webdriver.common.service import Service
    from selenium.webdriver.remote.webdriver import WebDriver
    if bstack11llll1l_opy_:
      Service.start = bstack111l1lll_opy_
      Service.stop = bstack111l11ll_opy_
      webdriver.Remote.get = bstack1l1lll11l_opy_
      WebDriver.close = bstack11lll11l_opy_
      WebDriver.quit = bstack1l1111lll_opy_
      webdriver.Remote.__init__ = bstack1l11l1ll_opy_
    if not bstack11llll1l_opy_ and bstack1lll11l1l1_opy_.on():
      webdriver.Remote.__init__ = bstack11ll1ll1_opy_
    bstack1ll1llll1l_opy_ = True
  except Exception as e:
    pass
  bstack111lll1l1_opy_()
  if not bstack1ll1llll1l_opy_:
    bstack1111ll11l_opy_(bstack11111ll_opy_ (u"ࠥࡔࡦࡩ࡫ࡢࡩࡨࡷࠥࡴ࡯ࡵࠢ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠧ୿"), bstack11l11111l_opy_)
  if bstack11ll111l1_opy_():
    try:
      from selenium.webdriver.remote.remote_connection import RemoteConnection
      RemoteConnection._get_proxy_url = bstack1111lll1_opy_
    except Exception as e:
      logger.error(bstack1l1ll111l_opy_.format(str(e)))
  if (bstack11111ll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪ஀") in str(framework_name).lower()):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        WebDriverCreator._get_ff_profile = bstack111l1llll_opy_
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCache.close = bstack1lll11111_opy_
      except Exception as e:
        logger.warn(bstack11ll1l1l1_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        ApplicationCache.close = bstack1l111ll11_opy_
      except Exception as e:
        logger.debug(bstack111llll1l_opy_ + str(e))
    except Exception as e:
      bstack1111ll11l_opy_(e, bstack11ll1l1l1_opy_)
    Output.end_test = bstack111ll111l_opy_
    TestStatus.__init__ = bstack1lllll1l1l_opy_
    QueueItem.__init__ = bstack11l11llll_opy_
    pabot._create_items = bstack111111l1_opy_
    try:
      from pabot import __version__ as bstack1lllll11ll_opy_
      if version.parse(bstack1lllll11ll_opy_) >= version.parse(bstack11111ll_opy_ (u"ࠬ࠸࠮࠲࠷࠱࠴ࠬ஁")):
        pabot._run = bstack1ll1l1ll1l_opy_
      elif version.parse(bstack1lllll11ll_opy_) >= version.parse(bstack11111ll_opy_ (u"࠭࠲࠯࠳࠶࠲࠵࠭ஂ")):
        pabot._run = bstack1l11llll_opy_
      else:
        pabot._run = bstack1111ll1l_opy_
    except Exception as e:
      pabot._run = bstack1111ll1l_opy_
    pabot._create_command_for_execution = bstack111l1ll1l_opy_
    pabot._report_results = bstack1llll1l1l_opy_
  if bstack11111ll_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧஃ") in str(framework_name).lower():
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack1111ll11l_opy_(e, bstack1l11lll1l_opy_)
    Runner.run_hook = bstack1ll11l11l_opy_
    Step.run = bstack11lllll1l_opy_
  if bstack11111ll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ஄") in str(framework_name).lower():
    if not bstack11llll1l_opy_:
      return
    try:
      from pytest_selenium import pytest_selenium
      from _pytest.config import Config
      pytest_selenium.pytest_report_header = bstack1lll1l11l1_opy_
      from pytest_selenium.drivers import browserstack
      browserstack.pytest_selenium_runtest_makereport = bstack1ll1ll11l1_opy_
      Config.getoption = bstack1l1llll1l_opy_
    except Exception as e:
      pass
    try:
      from _pytest import runner
      runner._update_current_test_var = bstack11l1111ll_opy_
    except Exception as e:
      pass
    try:
      from pytest_bdd import reporting
      reporting.runtest_makereport = bstack11ll11l11_opy_
    except Exception as e:
      pass
def bstack11111ll1l_opy_():
  global CONFIG
  if bstack11111ll_opy_ (u"ࠩࡳࡥࡷࡧ࡬࡭ࡧ࡯ࡷࡕ࡫ࡲࡑ࡮ࡤࡸ࡫ࡵࡲ࡮ࠩஅ") in CONFIG and int(CONFIG[bstack11111ll_opy_ (u"ࠪࡴࡦࡸࡡ࡭࡮ࡨࡰࡸࡖࡥࡳࡒ࡯ࡥࡹ࡬࡯ࡳ࡯ࠪஆ")]) > 1:
    logger.warn(bstack1ll11111l_opy_)
def bstack1lllll1lll_opy_(arg):
  bstack1lll1l1l11_opy_(bstack1l1l1ll1_opy_)
  from behave.__main__ import main as bstack11l1ll1l1_opy_
  bstack11l1ll1l1_opy_(arg)
def bstack11l11ll11_opy_():
  logger.info(bstack11l111ll1_opy_)
  import argparse
  parser = argparse.ArgumentParser()
  parser.add_argument(bstack11111ll_opy_ (u"ࠫࡸ࡫ࡴࡶࡲࠪஇ"), help=bstack11111ll_opy_ (u"ࠬࡍࡥ࡯ࡧࡵࡥࡹ࡫ࠠࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࠦࡣࡰࡰࡩ࡭࡬࠭ஈ"))
  parser.add_argument(bstack11111ll_opy_ (u"࠭࠭ࡶࠩஉ"), bstack11111ll_opy_ (u"ࠧ࠮࠯ࡸࡷࡪࡸ࡮ࡢ࡯ࡨࠫஊ"), help=bstack11111ll_opy_ (u"ࠨ࡛ࡲࡹࡷࠦࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࠥࡻࡳࡦࡴࡱࡥࡲ࡫ࠧ஋"))
  parser.add_argument(bstack11111ll_opy_ (u"ࠩ࠰࡯ࠬ஌"), bstack11111ll_opy_ (u"ࠪ࠱࠲ࡱࡥࡺࠩ஍"), help=bstack11111ll_opy_ (u"ࠫ࡞ࡵࡵࡳࠢࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠡࡣࡦࡧࡪࡹࡳࠡ࡭ࡨࡽࠬஎ"))
  parser.add_argument(bstack11111ll_opy_ (u"ࠬ࠳ࡦࠨஏ"), bstack11111ll_opy_ (u"࠭࠭࠮ࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫஐ"), help=bstack11111ll_opy_ (u"࡚ࠧࡱࡸࡶࠥࡺࡥࡴࡶࠣࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭஑"))
  bstack11llll11_opy_ = parser.parse_args()
  try:
    bstack1l11ll1l1_opy_ = bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࠮ࡨࡧࡱࡩࡷ࡯ࡣ࠯ࡻࡰࡰ࠳ࡹࡡ࡮ࡲ࡯ࡩࠬஒ")
    if bstack11llll11_opy_.framework and bstack11llll11_opy_.framework not in (bstack11111ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩஓ"), bstack11111ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰ࠶ࠫஔ")):
      bstack1l11ll1l1_opy_ = bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠴ࡹ࡮࡮࠱ࡷࡦࡳࡰ࡭ࡧࠪக")
    bstack1111l1l1_opy_ = os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack1l11ll1l1_opy_)
    bstack1lll1l111l_opy_ = open(bstack1111l1l1_opy_, bstack11111ll_opy_ (u"ࠬࡸࠧ஖"))
    bstack1lll111l11_opy_ = bstack1lll1l111l_opy_.read()
    bstack1lll1l111l_opy_.close()
    if bstack11llll11_opy_.username:
      bstack1lll111l11_opy_ = bstack1lll111l11_opy_.replace(bstack11111ll_opy_ (u"࡙࠭ࡐࡗࡕࡣ࡚࡙ࡅࡓࡐࡄࡑࡊ࠭஗"), bstack11llll11_opy_.username)
    if bstack11llll11_opy_.key:
      bstack1lll111l11_opy_ = bstack1lll111l11_opy_.replace(bstack11111ll_opy_ (u"࡚ࠧࡑࡘࡖࡤࡇࡃࡄࡇࡖࡗࡤࡑࡅ࡚ࠩ஘"), bstack11llll11_opy_.key)
    if bstack11llll11_opy_.framework:
      bstack1lll111l11_opy_ = bstack1lll111l11_opy_.replace(bstack11111ll_opy_ (u"ࠨ࡛ࡒ࡙ࡗࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠩங"), bstack11llll11_opy_.framework)
    file_name = bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫࠯ࡻࡰࡰࠬச")
    file_path = os.path.abspath(file_name)
    bstack1lll1ll11l_opy_ = open(file_path, bstack11111ll_opy_ (u"ࠪࡻࠬ஛"))
    bstack1lll1ll11l_opy_.write(bstack1lll111l11_opy_)
    bstack1lll1ll11l_opy_.close()
    logger.info(bstack1lll11l111_opy_)
    try:
      os.environ[bstack11111ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡊࡗࡇࡍࡆ࡙ࡒࡖࡐ࠭ஜ")] = bstack11llll11_opy_.framework if bstack11llll11_opy_.framework != None else bstack11111ll_opy_ (u"ࠧࠨ஝")
      config = yaml.safe_load(bstack1lll111l11_opy_)
      config[bstack11111ll_opy_ (u"࠭ࡳࡰࡷࡵࡧࡪ࠭ஞ")] = bstack11111ll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴ࠭ࡴࡧࡷࡹࡵ࠭ட")
      bstack11llll11l_opy_(bstack11l11111_opy_, config)
    except Exception as e:
      logger.debug(bstack1ll111l1l_opy_.format(str(e)))
  except Exception as e:
    logger.error(bstack1l11ll111_opy_.format(str(e)))
def bstack11llll11l_opy_(bstack11lll111_opy_, config, bstack1l111lll_opy_={}):
  global bstack11llll1l_opy_
  if not config:
    return
  bstack11ll11111_opy_ = bstack1lll11ll1_opy_ if not bstack11llll1l_opy_ else (
    bstack11ll11ll_opy_ if bstack11111ll_opy_ (u"ࠨࡣࡳࡴࠬ஠") in config else bstack1lll1111ll_opy_)
  data = {
    bstack11111ll_opy_ (u"ࠩࡸࡷࡪࡸࡎࡢ࡯ࡨࠫ஡"): config[bstack11111ll_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬ஢")],
    bstack11111ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧண"): config[bstack11111ll_opy_ (u"ࠬࡧࡣࡤࡧࡶࡷࡐ࡫ࡹࠨத")],
    bstack11111ll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪ஥"): bstack11lll111_opy_,
    bstack11111ll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪ஦"): {
      bstack11111ll_opy_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࡢࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭஧"): str(config[bstack11111ll_opy_ (u"ࠩࡶࡳࡺࡸࡣࡦࠩந")]) if bstack11111ll_opy_ (u"ࠪࡷࡴࡻࡲࡤࡧࠪன") in config else bstack11111ll_opy_ (u"ࠦࡺࡴ࡫࡯ࡱࡺࡲࠧப"),
      bstack11111ll_opy_ (u"ࠬࡸࡥࡧࡧࡵࡶࡪࡸࠧ஫"): bstack111l1l111_opy_(os.getenv(bstack11111ll_opy_ (u"ࠨࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࠣ஬"), bstack11111ll_opy_ (u"ࠢࠣ஭"))),
      bstack11111ll_opy_ (u"ࠨ࡮ࡤࡲ࡬ࡻࡡࡨࡧࠪம"): bstack11111ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩய"),
      bstack11111ll_opy_ (u"ࠪࡴࡷࡵࡤࡶࡥࡷࠫர"): bstack11ll11111_opy_,
      bstack11111ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧற"): config[bstack11111ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨல")] if config[bstack11111ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡓࡧ࡭ࡦࠩள")] else bstack11111ll_opy_ (u"ࠢࡶࡰ࡮ࡲࡴࡽ࡮ࠣழ"),
      bstack11111ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪவ"): str(config[bstack11111ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫஶ")]) if bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬஷ") in config else bstack11111ll_opy_ (u"ࠦࡺࡴ࡫࡯ࡱࡺࡲࠧஸ"),
      bstack11111ll_opy_ (u"ࠬࡵࡳࠨஹ"): sys.platform,
      bstack11111ll_opy_ (u"࠭ࡨࡰࡵࡷࡲࡦࡳࡥࠨ஺"): socket.gethostname()
    }
  }
  update(data[bstack11111ll_opy_ (u"ࠧࡦࡸࡨࡲࡹࡥࡰࡳࡱࡳࡩࡷࡺࡩࡦࡵࠪ஻")], bstack1l111lll_opy_)
  try:
    response = bstack11ll1lll_opy_(bstack11111ll_opy_ (u"ࠨࡒࡒࡗ࡙࠭஼"), bstack1lll1l1ll1_opy_(bstack1llllll111_opy_), data, {
      bstack11111ll_opy_ (u"ࠩࡤࡹࡹ࡮ࠧ஽"): (config[bstack11111ll_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬா")], config[bstack11111ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧி")])
    })
    if response:
      logger.debug(bstack1lll1l111_opy_.format(bstack11lll111_opy_, str(response.json())))
  except Exception as e:
    logger.debug(bstack11l1ll111_opy_.format(str(e)))
def bstack111l1l111_opy_(framework):
  return bstack11111ll_opy_ (u"ࠧࢁࡽ࠮ࡲࡼࡸ࡭ࡵ࡮ࡢࡩࡨࡲࡹ࠵ࡻࡾࠤீ").format(str(framework), __version__) if framework else bstack11111ll_opy_ (u"ࠨࡰࡺࡶ࡫ࡳࡳࡧࡧࡦࡰࡷ࠳ࢀࢃࠢு").format(
    __version__)
def bstack1ll1l11ll_opy_():
  global CONFIG
  if bool(CONFIG):
    return
  try:
    bstack1ll1l1l111_opy_()
    logger.debug(bstack11lll11l1_opy_.format(str(CONFIG)))
    bstack11l11ll1l_opy_()
    bstack1l1ll1lll_opy_()
  except Exception as e:
    logger.error(bstack11111ll_opy_ (u"ࠢࡇࡣ࡬ࡰࡪࡪࠠࡵࡱࠣࡷࡪࡺࡵࡱ࠮ࠣࡩࡷࡸ࡯ࡳ࠼ࠣࠦூ") + str(e))
    sys.exit(1)
  sys.excepthook = bstack1lll1llll_opy_
  atexit.register(bstack11ll11l1l_opy_)
  signal.signal(signal.SIGINT, bstack11l1l1ll1_opy_)
  signal.signal(signal.SIGTERM, bstack11l1l1ll1_opy_)
def bstack1lll1llll_opy_(exctype, value, traceback):
  global bstack111lll1ll_opy_
  try:
    for driver in bstack111lll1ll_opy_:
      driver.execute_script(
        bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࠧࡧࡣࡵ࡫ࡲࡲࠧࡀࠠࠣࡵࡨࡸࡘ࡫ࡳࡴ࡫ࡲࡲࡘࡺࡡࡵࡷࡶࠦ࠱ࠦࠢࡢࡴࡪࡹࡲ࡫࡮ࡵࡵࠥ࠾ࠥࢁࠢࡴࡶࡤࡸࡺࡹࠢ࠻ࠤࡩࡥ࡮ࡲࡥࡥࠤ࠯ࠤࠧࡸࡥࡢࡵࡲࡲࠧࡀࠠࠨ௃") + json.dumps(
          bstack11111ll_opy_ (u"ࠤࡖࡩࡸࡹࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣࡻ࡮ࡺࡨ࠻ࠢ࡟ࡲࠧ௄") + str(value)) + bstack11111ll_opy_ (u"ࠪࢁࢂ࠭௅"))
  except Exception:
    pass
  bstack11lll1l1_opy_(value)
  sys.__excepthook__(exctype, value, traceback)
  sys.exit(1)
def bstack11lll1l1_opy_(message=bstack11111ll_opy_ (u"ࠫࠬெ")):
  global CONFIG
  try:
    if message:
      bstack1l111lll_opy_ = {
        bstack11111ll_opy_ (u"ࠬ࡫ࡲࡳࡱࡵࠫே"): str(message)
      }
      bstack11llll11l_opy_(bstack111l11l11_opy_, CONFIG, bstack1l111lll_opy_)
    else:
      bstack11llll11l_opy_(bstack111l11l11_opy_, CONFIG)
  except Exception as e:
    logger.debug(bstack1111l11l_opy_.format(str(e)))
def bstack1lll1l1l_opy_(bstack11ll1ll11_opy_, size):
  bstack1ll1lll11l_opy_ = []
  while len(bstack11ll1ll11_opy_) > size:
    bstack1l11111l1_opy_ = bstack11ll1ll11_opy_[:size]
    bstack1ll1lll11l_opy_.append(bstack1l11111l1_opy_)
    bstack11ll1ll11_opy_ = bstack11ll1ll11_opy_[size:]
  bstack1ll1lll11l_opy_.append(bstack11ll1ll11_opy_)
  return bstack1ll1lll11l_opy_
def bstack1ll1ll11ll_opy_(args):
  if bstack11111ll_opy_ (u"࠭࠭࡮ࠩை") in args and bstack11111ll_opy_ (u"ࠧࡱࡦࡥࠫ௉") in args:
    return True
  return False
def run_on_browserstack(bstack11ll11lll_opy_=None, bstack1lll1l11ll_opy_=None, bstack1ll1llll11_opy_=False):
  global CONFIG
  global bstack1l1l1l1ll_opy_
  global bstack1llll11l11_opy_
  bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠨࠩொ")
  if bstack11ll11lll_opy_ and isinstance(bstack11ll11lll_opy_, str):
    bstack11ll11lll_opy_ = eval(bstack11ll11lll_opy_)
  if bstack11ll11lll_opy_:
    CONFIG = bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠩࡆࡓࡓࡌࡉࡈࠩோ")]
    bstack1l1l1l1ll_opy_ = bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠪࡌ࡚ࡈ࡟ࡖࡔࡏࠫௌ")]
    bstack1llll11l11_opy_ = bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠫࡎ࡙࡟ࡂࡒࡓࡣࡆ࡛ࡔࡐࡏࡄࡘࡊ்࠭")]
    bstack1llllll1l1_opy_.set_property(bstack11111ll_opy_ (u"ࠬࡏࡓࡠࡃࡓࡔࡤࡇࡕࡕࡑࡐࡅ࡙ࡋࠧ௎"), bstack1llll11l11_opy_)
    bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭௏")
  if not bstack1ll1llll11_opy_:
    if len(sys.argv) <= 1:
      logger.critical(bstack11l11ll1_opy_)
      return
    if sys.argv[1] == bstack11111ll_opy_ (u"ࠧ࠮࠯ࡹࡩࡷࡹࡩࡰࡰࠪௐ") or sys.argv[1] == bstack11111ll_opy_ (u"ࠨ࠯ࡹࠫ௑"):
      logger.info(bstack11111ll_opy_ (u"ࠩࡅࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࠡࡒࡼࡸ࡭ࡵ࡮ࠡࡕࡇࡏࠥࡼࡻࡾࠩ௒").format(__version__))
      return
    if sys.argv[1] == bstack11111ll_opy_ (u"ࠪࡷࡪࡺࡵࡱࠩ௓"):
      bstack11l11ll11_opy_()
      return
  args = sys.argv
  bstack1ll1l11ll_opy_()
  global bstack1ll1l1llll_opy_
  global bstack1111ll11_opy_
  global bstack11l1lll1_opy_
  global bstack1llll1ll11_opy_
  global bstack1llll1l1l1_opy_
  global bstack1llll1lll1_opy_
  global bstack1ll1l1111_opy_
  global bstack1lll11111l_opy_
  if not bstack1ll1ll11l_opy_:
    if args[1] == bstack11111ll_opy_ (u"ࠫࡵࡿࡴࡩࡱࡱࠫ௔") or args[1] == bstack11111ll_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲ࠸࠭௕"):
      bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠭௖")
      args = args[2:]
    elif args[1] == bstack11111ll_opy_ (u"ࠧࡳࡱࡥࡳࡹ࠭ௗ"):
      bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠨࡴࡲࡦࡴࡺࠧ௘")
      args = args[2:]
    elif args[1] == bstack11111ll_opy_ (u"ࠩࡳࡥࡧࡵࡴࠨ௙"):
      bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩ௚")
      args = args[2:]
    elif args[1] == bstack11111ll_opy_ (u"ࠫࡷࡵࡢࡰࡶ࠰࡭ࡳࡺࡥࡳࡰࡤࡰࠬ௛"):
      bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱ࠭௜")
      args = args[2:]
    elif args[1] == bstack11111ll_opy_ (u"࠭ࡰࡺࡶࡨࡷࡹ࠭௝"):
      bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠧࡱࡻࡷࡩࡸࡺࠧ௞")
      args = args[2:]
    elif args[1] == bstack11111ll_opy_ (u"ࠨࡤࡨ࡬ࡦࡼࡥࠨ௟"):
      bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠩࡥࡩ࡭ࡧࡶࡦࠩ௠")
      args = args[2:]
    else:
      if not bstack11111ll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭௡") in CONFIG or str(CONFIG[bstack11111ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧ௢")]).lower() in [bstack11111ll_opy_ (u"ࠬࡶࡹࡵࡪࡲࡲࠬ௣"), bstack11111ll_opy_ (u"࠭ࡰࡺࡶ࡫ࡳࡳ࠹ࠧ௤")]:
        bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧ௥")
        args = args[1:]
      elif str(CONFIG[bstack11111ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫ௦")]).lower() == bstack11111ll_opy_ (u"ࠩࡵࡳࡧࡵࡴࠨ௧"):
        bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵࠩ௨")
        args = args[1:]
      elif str(CONFIG[bstack11111ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱࠧ௩")]).lower() == bstack11111ll_opy_ (u"ࠬࡶࡡࡣࡱࡷࠫ௪"):
        bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"࠭ࡰࡢࡤࡲࡸࠬ௫")
        args = args[1:]
      elif str(CONFIG[bstack11111ll_opy_ (u"ࠧࡧࡴࡤࡱࡪࡽ࡯ࡳ࡭ࠪ௬")]).lower() == bstack11111ll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ௭"):
        bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࠩ௮")
        args = args[1:]
      elif str(CONFIG[bstack11111ll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰ࠭௯")]).lower() == bstack11111ll_opy_ (u"ࠫࡧ࡫ࡨࡢࡸࡨࠫ௰"):
        bstack1ll1ll11l_opy_ = bstack11111ll_opy_ (u"ࠬࡨࡥࡩࡣࡹࡩࠬ௱")
        args = args[1:]
      else:
        os.environ[bstack11111ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡌࡒࡂࡏࡈ࡛ࡔࡘࡋࠨ௲")] = bstack1ll1ll11l_opy_
        bstack11l1ll11_opy_(bstack1llll1ll1l_opy_)
  global bstack11l11l111_opy_
  if bstack11ll11lll_opy_:
    try:
      os.environ[bstack11111ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡆࡓࡃࡐࡉ࡜ࡕࡒࡌࠩ௳")] = bstack1ll1ll11l_opy_
      bstack11llll11l_opy_(bstack1l111ll1_opy_, CONFIG)
    except Exception as e:
      logger.debug(bstack1111l11l_opy_.format(str(e)))
  global bstack111ll1ll1_opy_
  global bstack11l1111l_opy_
  global bstack111l1l11l_opy_
  global bstack111llll11_opy_
  global bstack1l111ll1l_opy_
  global bstack1ll11l1l1_opy_
  global bstack1lll1ll11_opy_
  global bstack1l1l1lll1_opy_
  global bstack1lll1lllll_opy_
  global bstack1llll11ll_opy_
  global bstack1l1llllll_opy_
  global bstack1l1l1111l_opy_
  global bstack11l111l1l_opy_
  global bstack1l1l1llll_opy_
  global bstack11l11l11l_opy_
  global bstack11l111l11_opy_
  global bstack11l111lll_opy_
  global bstack111l1l1ll_opy_
  global bstack11l11lll_opy_
  try:
    from selenium import webdriver
    from selenium.webdriver.remote.webdriver import WebDriver
    bstack111ll1ll1_opy_ = webdriver.Remote.__init__
    bstack11l1111l_opy_ = WebDriver.quit
    bstack1l1llllll_opy_ = WebDriver.close
    bstack1l1l1llll_opy_ = WebDriver.get
  except Exception as e:
    pass
  try:
    import Browser
    from subprocess import Popen
    bstack11l11l111_opy_ = Popen.__init__
  except Exception as e:
    pass
  if bstack11lll1ll_opy_(CONFIG):
    if bstack1ll1l1l11l_opy_() < version.parse(bstack1l111l1l1_opy_):
      logger.error(bstack11ll1ll1l_opy_.format(bstack1ll1l1l11l_opy_()))
    else:
      try:
        from selenium.webdriver.remote.remote_connection import RemoteConnection
        bstack11l11l11l_opy_ = RemoteConnection._get_proxy_url
      except Exception as e:
        logger.error(bstack1l1ll111l_opy_.format(str(e)))
  if bstack1ll1ll11l_opy_ != bstack11111ll_opy_ (u"ࠨࡲࡼࡸ࡭ࡵ࡮ࠨ௴") or (bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩ௵") and not bstack11ll11lll_opy_):
    bstack1ll11l1ll_opy_()
  if (bstack1ll1ll11l_opy_ in [bstack11111ll_opy_ (u"ࠪࡴࡦࡨ࡯ࡵࠩ௶"), bstack11111ll_opy_ (u"ࠫࡷࡵࡢࡰࡶࠪ௷"), bstack11111ll_opy_ (u"ࠬࡸ࡯ࡣࡱࡷ࠱࡮ࡴࡴࡦࡴࡱࡥࡱ࠭௸")]):
    try:
      from robot import run_cli
      from robot.output import Output
      from robot.running.status import TestStatus
      from pabot.pabot import QueueItem
      from pabot import pabot
      try:
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCreator
        from SeleniumLibrary.keywords.webdrivertools.webdrivertools import WebDriverCache
        WebDriverCreator._get_ff_profile = bstack111l1llll_opy_
        bstack1l111ll1l_opy_ = WebDriverCache.close
      except Exception as e:
        logger.warn(bstack11ll1l1l1_opy_ + str(e))
      try:
        from AppiumLibrary.utils.applicationcache import ApplicationCache
        bstack111llll11_opy_ = ApplicationCache.close
      except Exception as e:
        logger.debug(bstack111llll1l_opy_ + str(e))
    except Exception as e:
      bstack1111ll11l_opy_(e, bstack11ll1l1l1_opy_)
    if bstack1ll1ll11l_opy_ != bstack11111ll_opy_ (u"࠭ࡲࡰࡤࡲࡸ࠲࡯࡮ࡵࡧࡵࡲࡦࡲࠧ௹"):
      bstack1l11lll1_opy_()
    bstack111l1l11l_opy_ = Output.end_test
    bstack1ll11l1l1_opy_ = TestStatus.__init__
    bstack1l1l1lll1_opy_ = pabot._run
    bstack1lll1lllll_opy_ = QueueItem.__init__
    bstack1llll11ll_opy_ = pabot._create_command_for_execution
    bstack111l1l1ll_opy_ = pabot._report_results
  if bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"ࠧࡣࡧ࡫ࡥࡻ࡫ࠧ௺"):
    try:
      from behave.runner import Runner
      from behave.model import Step
    except Exception as e:
      bstack1111ll11l_opy_(e, bstack1l11lll1l_opy_)
    bstack1l1l1111l_opy_ = Runner.run_hook
    bstack11l111l1l_opy_ = Step.run
  if bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"ࠨࡲࡼࡸࡪࡹࡴࠨ௻"):
    try:
      bstack1lll11l1l1_opy_.launch(CONFIG, {
        bstack11111ll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡤࡴࡡ࡮ࡧࠪ௼"): bstack11111ll_opy_ (u"ࠪࡔࡾࡺࡥࡴࡶࠪ௽"),
        bstack11111ll_opy_ (u"ࠫ࡫ࡸࡡ࡮ࡧࡺࡳࡷࡱ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨ௾"): bstack1ll11l11_opy_.version(),
        bstack11111ll_opy_ (u"ࠬࡹࡤ࡬ࡡࡹࡩࡷࡹࡩࡰࡰࠪ௿"): __version__
      })
      from _pytest.config import Config
      bstack11l111l11_opy_ = Config.getoption
      from _pytest import runner
      bstack11l111lll_opy_ = runner._update_current_test_var
    except Exception as e:
      logger.warn(e, bstack1l1l1lll_opy_)
    try:
      from pytest_bdd import reporting
      bstack11l11lll_opy_ = reporting.runtest_makereport
    except Exception as e:
      logger.debug(bstack11111ll_opy_ (u"࠭ࡐ࡭ࡧࡤࡷࡪࠦࡩ࡯ࡵࡷࡥࡱࡲࠠࡱࡻࡷࡩࡸࡺ࠭ࡣࡦࡧࠤࡹࡵࠠࡳࡷࡱࠤࡵࡿࡴࡦࡵࡷ࠱ࡧࡪࡤࠡࡶࡨࡷࡹࡹࠧఀ"))
  if bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"ࠧࡱࡻࡷ࡬ࡴࡴࠧఁ"):
    bstack1111ll11_opy_ = True
    if bstack11ll11lll_opy_ and bstack1ll1llll11_opy_:
      bstack1llll1l1l1_opy_ = CONFIG.get(bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡕࡷࡥࡨࡱࡌࡰࡥࡤࡰࡔࡶࡴࡪࡱࡱࡷࠬం"), {}).get(bstack11111ll_opy_ (u"ࠩ࡯ࡳࡨࡧ࡬ࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫః"))
      bstack1lll1l1l11_opy_(bstack11l1l111l_opy_)
    elif bstack11ll11lll_opy_:
      bstack1llll1l1l1_opy_ = CONFIG.get(bstack11111ll_opy_ (u"ࠪࡦࡷࡵࡷࡴࡧࡵࡗࡹࡧࡣ࡬ࡎࡲࡧࡦࡲࡏࡱࡶ࡬ࡳࡳࡹࠧఄ"), {}).get(bstack11111ll_opy_ (u"ࠫࡱࡵࡣࡢ࡮ࡌࡨࡪࡴࡴࡪࡨ࡬ࡩࡷ࠭అ"))
      global bstack111lll1ll_opy_
      try:
        if bstack1ll1ll11ll_opy_(bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨఆ")]) and multiprocessing.current_process().name == bstack11111ll_opy_ (u"࠭࠰ࠨఇ"):
          bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪఈ")].remove(bstack11111ll_opy_ (u"ࠨ࠯ࡰࠫఉ"))
          bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬఊ")].remove(bstack11111ll_opy_ (u"ࠪࡴࡩࡨࠧఋ"))
          bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧఌ")] = bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨ఍")][0]
          with open(bstack11ll11lll_opy_[bstack11111ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩఎ")], bstack11111ll_opy_ (u"ࠧࡳࠩఏ")) as f:
            bstack1l11l1l11_opy_ = f.read()
          bstack1lllll11l_opy_ = bstack11111ll_opy_ (u"ࠣࠤࠥࡪࡷࡵ࡭ࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡴࡦ࡮ࠤ࡮ࡳࡰࡰࡴࡷࠤࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢ࡭ࡳ࡯ࡴࡪࡣ࡯࡭ࡿ࡫࠻ࠡࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡪࡰ࡬ࡸ࡮ࡧ࡬ࡪࡼࡨࠬࢀࢃࠩ࠼ࠢࡩࡶࡴࡳࠠࡱࡦࡥࠤ࡮ࡳࡰࡰࡴࡷࠤࡕࡪࡢ࠼ࠢࡲ࡫ࡤࡪࡢࠡ࠿ࠣࡔࡩࡨ࠮ࡥࡱࡢࡦࡷ࡫ࡡ࡬࠽ࠍࡨࡪ࡬ࠠ࡮ࡱࡧࡣࡧࡸࡥࡢ࡭ࠫࡷࡪࡲࡦ࠭ࠢࡤࡶ࡬࠲ࠠࡵࡧࡰࡴࡴࡸࡡࡳࡻࠣࡁࠥ࠶ࠩ࠻ࠌࠣࠤࡹࡸࡹ࠻ࠌࠣࠤࠥࠦࡡࡳࡩࠣࡁࠥࡹࡴࡳࠪ࡬ࡲࡹ࠮ࡡࡳࡩࠬ࠯࠶࠶ࠩࠋࠢࠣࡩࡽࡩࡥࡱࡶࠣࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡡࡴࠢࡨ࠾ࠏࠦࠠࠡࠢࡳࡥࡸࡹࠊࠡࠢࡲ࡫ࡤࡪࡢࠩࡵࡨࡰ࡫࠲ࡡࡳࡩ࠯ࡸࡪࡳࡰࡰࡴࡤࡶࡾ࠯ࠊࡑࡦࡥ࠲ࡩࡵ࡟ࡣࠢࡀࠤࡲࡵࡤࡠࡤࡵࡩࡦࡱࠊࡑࡦࡥ࠲ࡩࡵ࡟ࡣࡴࡨࡥࡰࠦ࠽ࠡ࡯ࡲࡨࡤࡨࡲࡦࡣ࡮ࠎࡕࡪࡢࠩࠫ࠱ࡷࡪࡺ࡟ࡵࡴࡤࡧࡪ࠮ࠩ࡝ࡰࠥࠦࠧఐ").format(str(bstack11ll11lll_opy_))
          bstack111l11lll_opy_ = bstack1lllll11l_opy_ + bstack1l11l1l11_opy_
          bstack1ll11lllll_opy_ = bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠩࡩ࡭ࡱ࡫࡟࡯ࡣࡰࡩࠬ఑")] + bstack11111ll_opy_ (u"ࠪࡣࡧࡹࡴࡢࡥ࡮ࡣࡹ࡫࡭ࡱ࠰ࡳࡽࠬఒ")
          with open(bstack1ll11lllll_opy_, bstack11111ll_opy_ (u"ࠫࡼ࠭ఓ")):
            pass
          with open(bstack1ll11lllll_opy_, bstack11111ll_opy_ (u"ࠧࡽࠫࠣఔ")) as f:
            f.write(bstack111l11lll_opy_)
          import subprocess
          process_data = subprocess.run([bstack11111ll_opy_ (u"ࠨࡰࡺࡶ࡫ࡳࡳࠨక"), bstack1ll11lllll_opy_])
          if os.path.exists(bstack1ll11lllll_opy_):
            os.unlink(bstack1ll11lllll_opy_)
          os._exit(process_data.returncode)
        else:
          if bstack1ll1ll11ll_opy_(bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪఖ")]):
            bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫగ")].remove(bstack11111ll_opy_ (u"ࠩ࠰ࡱࠬఘ"))
            bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠪࡪ࡮ࡲࡥࡠࡰࡤࡱࡪ࠭ఙ")].remove(bstack11111ll_opy_ (u"ࠫࡵࡪࡢࠨచ"))
            bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨఛ")] = bstack11ll11lll_opy_[bstack11111ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩజ")][0]
          bstack1lll1l1l11_opy_(bstack11l1l111l_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪఝ")])))
          sys.argv = sys.argv[2:]
          mod_globals = globals()
          mod_globals[bstack11111ll_opy_ (u"ࠨࡡࡢࡲࡦࡳࡥࡠࡡࠪఞ")] = bstack11111ll_opy_ (u"ࠩࡢࡣࡲࡧࡩ࡯ࡡࡢࠫట")
          mod_globals[bstack11111ll_opy_ (u"ࠪࡣࡤ࡬ࡩ࡭ࡧࡢࡣࠬఠ")] = os.path.abspath(bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠫ࡫࡯࡬ࡦࡡࡱࡥࡲ࡫ࠧడ")])
          exec(open(bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠬ࡬ࡩ࡭ࡧࡢࡲࡦࡳࡥࠨఢ")]).read(), mod_globals)
      except BaseException as e:
        try:
          traceback.print_exc()
          logger.error(bstack11111ll_opy_ (u"࠭ࡃࡢࡷࡪ࡬ࡹࠦࡅࡹࡥࡨࡴࡹ࡯࡯࡯࠼ࠣࡿࢂ࠭ణ").format(str(e)))
          for driver in bstack111lll1ll_opy_:
            bstack1lll1l11ll_opy_.append({
              bstack11111ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬత"): bstack11ll11lll_opy_[bstack11111ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫథ")],
              bstack11111ll_opy_ (u"ࠩࡨࡶࡷࡵࡲࠨద"): str(e),
              bstack11111ll_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩధ"): multiprocessing.current_process().name
            })
            driver.execute_script(
              bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡷࡹࡧࡴࡶࡵࠥ࠾ࠧ࡬ࡡࡪ࡮ࡨࡨࠧ࠲ࠠࠣࡴࡨࡥࡸࡵ࡮ࠣ࠼ࠣࠫన") + json.dumps(
                bstack11111ll_opy_ (u"࡙ࠧࡥࡴࡵ࡬ࡳࡳࠦࡦࡢ࡫࡯ࡩࡩࠦࡷࡪࡶ࡫࠾ࠥࡢ࡮ࠣ఩") + str(e)) + bstack11111ll_opy_ (u"࠭ࡽࡾࠩప"))
        except Exception:
          pass
      finally:
        try:
          for driver in bstack111lll1ll_opy_:
            driver.quit()
        except Exception as e:
          pass
    else:
      bstack1ll1ll1111_opy_()
      bstack11111ll1l_opy_()
      bstack1ll11ll1_opy_ = {
        bstack11111ll_opy_ (u"ࠧࡧ࡫࡯ࡩࡤࡴࡡ࡮ࡧࠪఫ"): args[0],
        bstack11111ll_opy_ (u"ࠨࡅࡒࡒࡋࡏࡇࠨబ"): CONFIG,
        bstack11111ll_opy_ (u"ࠩࡋ࡙ࡇࡥࡕࡓࡎࠪభ"): bstack1l1l1l1ll_opy_,
        bstack11111ll_opy_ (u"ࠪࡍࡘࡥࡁࡑࡒࡢࡅ࡚࡚ࡏࡎࡃࡗࡉࠬమ"): bstack1llll11l11_opy_
      }
      if bstack11111ll_opy_ (u"ࠫࡵࡲࡡࡵࡨࡲࡶࡲࡹࠧయ") in CONFIG:
        bstack1lllll11_opy_ = []
        manager = multiprocessing.Manager()
        bstack1l111l111_opy_ = manager.list()
        if bstack1ll1ll11ll_opy_(args):
          for index, platform in enumerate(CONFIG[bstack11111ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨర")]):
            if index == 0:
              bstack1ll11ll1_opy_[bstack11111ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩఱ")] = args
            bstack1lllll11_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1ll11ll1_opy_, bstack1l111l111_opy_)))
        else:
          for index, platform in enumerate(CONFIG[bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪల")]):
            bstack1lllll11_opy_.append(multiprocessing.Process(name=str(index),
                                                       target=run_on_browserstack,
                                                       args=(bstack1ll11ll1_opy_, bstack1l111l111_opy_)))
        for t in bstack1lllll11_opy_:
          t.start()
        for t in bstack1lllll11_opy_:
          t.join()
        bstack1ll1l1111_opy_ = list(bstack1l111l111_opy_)
      else:
        if bstack1ll1ll11ll_opy_(args):
          bstack1ll11ll1_opy_[bstack11111ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫళ")] = args
          test = multiprocessing.Process(name=str(0),
                                         target=run_on_browserstack, args=(bstack1ll11ll1_opy_,))
          test.start()
          test.join()
        else:
          bstack1lll1l1l11_opy_(bstack11l1l111l_opy_)
          sys.path.append(os.path.dirname(os.path.abspath(args[0])))
          mod_globals = globals()
          mod_globals[bstack11111ll_opy_ (u"ࠩࡢࡣࡳࡧ࡭ࡦࡡࡢࠫఴ")] = bstack11111ll_opy_ (u"ࠪࡣࡤࡳࡡࡪࡰࡢࡣࠬవ")
          mod_globals[bstack11111ll_opy_ (u"ࠫࡤࡥࡦࡪ࡮ࡨࡣࡤ࠭శ")] = os.path.abspath(args[0])
          sys.argv = sys.argv[2:]
          exec(open(args[0]).read(), mod_globals)
  elif bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"ࠬࡶࡡࡣࡱࡷࠫష") or bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"࠭ࡲࡰࡤࡲࡸࠬస"):
    try:
      from pabot import pabot
    except Exception as e:
      bstack1111ll11l_opy_(e, bstack11ll1l1l1_opy_)
    bstack1ll1ll1111_opy_()
    bstack1lll1l1l11_opy_(bstack1ll1lllll_opy_)
    if bstack11111ll_opy_ (u"ࠧ࠮࠯ࡳࡶࡴࡩࡥࡴࡵࡨࡷࠬహ") in args:
      i = args.index(bstack11111ll_opy_ (u"ࠨ࠯࠰ࡴࡷࡵࡣࡦࡵࡶࡩࡸ࠭఺"))
      args.pop(i)
      args.pop(i)
    args.insert(0, str(bstack1ll1l1llll_opy_))
    args.insert(0, str(bstack11111ll_opy_ (u"ࠩ࠰࠱ࡵࡸ࡯ࡤࡧࡶࡷࡪࡹࠧ఻")))
    pabot.main(args)
  elif bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"ࠪࡶࡴࡨ࡯ࡵ࠯࡬ࡲࡹ࡫ࡲ࡯ࡣ࡯఼ࠫ"):
    try:
      from robot import run_cli
    except Exception as e:
      bstack1111ll11l_opy_(e, bstack11ll1l1l1_opy_)
    for a in args:
      if bstack11111ll_opy_ (u"ࠫࡇ࡙ࡔࡂࡅࡎࡔࡑࡇࡔࡇࡑࡕࡑࡎࡔࡄࡆ࡚ࠪఽ") in a:
        bstack1llll1ll11_opy_ = int(a.split(bstack11111ll_opy_ (u"ࠬࡀࠧా"))[1])
      if bstack11111ll_opy_ (u"࠭ࡂࡔࡖࡄࡇࡐࡊࡅࡇࡎࡒࡇࡆࡒࡉࡅࡇࡑࡘࡎࡌࡉࡆࡔࠪి") in a:
        bstack1llll1l1l1_opy_ = str(a.split(bstack11111ll_opy_ (u"ࠧ࠻ࠩీ"))[1])
      if bstack11111ll_opy_ (u"ࠨࡄࡖࡘࡆࡉࡋࡄࡎࡌࡅࡗࡍࡓࠨు") in a:
        bstack1llll1lll1_opy_ = str(a.split(bstack11111ll_opy_ (u"ࠩ࠽ࠫూ"))[1])
    bstack1111l11l1_opy_ = None
    if bstack11111ll_opy_ (u"ࠪ࠱࠲ࡨࡳࡵࡣࡦ࡯ࡤ࡯ࡴࡦ࡯ࡢ࡭ࡳࡪࡥࡹࠩృ") in args:
      i = args.index(bstack11111ll_opy_ (u"ࠫ࠲࠳ࡢࡴࡶࡤࡧࡰࡥࡩࡵࡧࡰࡣ࡮ࡴࡤࡦࡺࠪౄ"))
      args.pop(i)
      bstack1111l11l1_opy_ = args.pop(i)
    if bstack1111l11l1_opy_ is not None:
      global bstack11111l11_opy_
      bstack11111l11_opy_ = bstack1111l11l1_opy_
    bstack1lll1l1l11_opy_(bstack1ll1lllll_opy_)
    run_cli(args)
  elif bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"ࠬࡶࡹࡵࡧࡶࡸࠬ౅"):
    bstack1ll111ll1_opy_ = bstack1ll11l11_opy_(args, logger, CONFIG, bstack11llll1l_opy_)
    bstack1ll111ll1_opy_.bstack1ll11lll_opy_()
    bstack1ll1ll1111_opy_()
    bstack1lll11111l_opy_ = bstack1ll111ll1_opy_.bstack1ll1lll1_opy_()
    bstack1ll111ll1_opy_.bstack1ll11ll1_opy_(bstack1lllll111l_opy_)
    bstack11l1lll1_opy_ = True
    bstack1lll1111_opy_ = bstack1ll111ll1_opy_.bstack1l1ll1ll_opy_()
    bstack1ll111ll1_opy_.bstack1ll111l1_opy_(bstack1lll1111_opy_, bstack1lll1l1l11_opy_)
  elif bstack1ll1ll11l_opy_ == bstack11111ll_opy_ (u"࠭ࡢࡦࡪࡤࡺࡪ࠭ె"):
    try:
      from behave.__main__ import main as bstack11l1ll1l1_opy_
      from behave.configuration import Configuration
    except Exception as e:
      bstack1111ll11l_opy_(e, bstack1l11lll1l_opy_)
    bstack1ll1ll1111_opy_()
    bstack11l1lll1_opy_ = True
    bstack1l1ll1l1_opy_ = 1
    if bstack11111ll_opy_ (u"ࠧࡱࡣࡵࡥࡱࡲࡥ࡭ࡵࡓࡩࡷࡖ࡬ࡢࡶࡩࡳࡷࡳࠧే") in CONFIG:
      bstack1l1ll1l1_opy_ = CONFIG[bstack11111ll_opy_ (u"ࠨࡲࡤࡶࡦࡲ࡬ࡦ࡮ࡶࡔࡪࡸࡐ࡭ࡣࡷࡪࡴࡸ࡭ࠨై")]
    bstack1ll11l1l_opy_ = int(bstack1l1ll1l1_opy_) * int(len(CONFIG[bstack11111ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࡷࠬ౉")]))
    config = Configuration(args)
    bstack11l1l1l1l_opy_ = config.paths
    if len(bstack11l1l1l1l_opy_) == 0:
      import glob
      pattern = bstack11111ll_opy_ (u"ࠪ࠮࠯࠵ࠪ࠯ࡨࡨࡥࡹࡻࡲࡦࠩొ")
      bstack1ll1lll11_opy_ = glob.glob(pattern, recursive=True)
      args.extend(bstack1ll1lll11_opy_)
      config = Configuration(args)
      bstack11l1l1l1l_opy_ = config.paths
    bstack1ll111ll_opy_ = [os.path.normpath(item) for item in bstack11l1l1l1l_opy_]
    bstack1ll1l1lll_opy_ = [os.path.normpath(item) for item in args]
    bstack1l1llll11_opy_ = [item for item in bstack1ll1l1lll_opy_ if item not in bstack1ll111ll_opy_]
    import platform as pf
    if pf.system().lower() == bstack11111ll_opy_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡷࠬో"):
      from pathlib import PureWindowsPath, PurePosixPath
      bstack1ll111ll_opy_ = [str(PurePosixPath(PureWindowsPath(bstack1llll1l1_opy_)))
                    for bstack1llll1l1_opy_ in bstack1ll111ll_opy_]
    bstack1ll1l1ll_opy_ = []
    for spec in bstack1ll111ll_opy_:
      bstack1lll11l1_opy_ = []
      bstack1lll11l1_opy_ += bstack1l1llll11_opy_
      bstack1lll11l1_opy_.append(spec)
      bstack1ll1l1ll_opy_.append(bstack1lll11l1_opy_)
    execution_items = []
    for bstack1lll11l1_opy_ in bstack1ll1l1ll_opy_:
      for index, _ in enumerate(CONFIG[bstack11111ll_opy_ (u"ࠬࡶ࡬ࡢࡶࡩࡳࡷࡳࡳࠨౌ")]):
        item = {}
        item[bstack11111ll_opy_ (u"࠭ࡡࡳࡩ్ࠪ")] = bstack11111ll_opy_ (u"ࠧࠡࠩ౎").join(bstack1lll11l1_opy_)
        item[bstack11111ll_opy_ (u"ࠨ࡫ࡱࡨࡪࡾࠧ౏")] = index
        execution_items.append(item)
    bstack1lll1111_opy_ = bstack1lll1l1l_opy_(execution_items, bstack1ll11l1l_opy_)
    for execution_item in bstack1lll1111_opy_:
      bstack1lllll11_opy_ = []
      for item in execution_item:
        bstack1lllll11_opy_.append(bstack1l1ll111_opy_(name=str(item[bstack11111ll_opy_ (u"ࠩ࡬ࡲࡩ࡫ࡸࠨ౐")]),
                                             target=bstack1lllll1lll_opy_,
                                             args=(item[bstack11111ll_opy_ (u"ࠪࡥࡷ࡭ࠧ౑")],)))
      for t in bstack1lllll11_opy_:
        t.start()
      for t in bstack1lllll11_opy_:
        t.join()
  else:
    bstack11l1ll11_opy_(bstack1llll1ll1l_opy_)
  if not bstack11ll11lll_opy_:
    bstack1lllllll1l_opy_()
def browserstack_initialize(bstack11111lll1_opy_=None):
  run_on_browserstack(bstack11111lll1_opy_, None, True)
def bstack1lllllll1l_opy_():
  bstack1lll11l1l1_opy_.stop()
  bstack1lll11l1l1_opy_.bstack1l1111l1l_opy_()
  [bstack111l11l1_opy_, bstack1111l111l_opy_] = bstack1lll1l1lll_opy_()
  if bstack111l11l1_opy_ is not None and bstack1llll1l11_opy_() != -1:
    sessions = bstack1lllllllll_opy_(bstack111l11l1_opy_)
    bstack11l1llll1_opy_(sessions, bstack1111l111l_opy_)
def bstack1111l111_opy_(bstack1ll1l111l_opy_):
  if bstack1ll1l111l_opy_:
    return bstack1ll1l111l_opy_.capitalize()
  else:
    return bstack1ll1l111l_opy_
def bstack1lllll1ll1_opy_(bstack1lll11llll_opy_):
  if bstack11111ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ౒") in bstack1lll11llll_opy_ and bstack1lll11llll_opy_[bstack11111ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪ౓")] != bstack11111ll_opy_ (u"࠭ࠧ౔"):
    return bstack1lll11llll_opy_[bstack11111ll_opy_ (u"ࠧ࡯ࡣࡰࡩౕࠬ")]
  else:
    bstack1lll1l11l_opy_ = bstack11111ll_opy_ (u"ࠣࠤౖ")
    if bstack11111ll_opy_ (u"ࠩࡧࡩࡻ࡯ࡣࡦࠩ౗") in bstack1lll11llll_opy_ and bstack1lll11llll_opy_[bstack11111ll_opy_ (u"ࠪࡨࡪࡼࡩࡤࡧࠪౘ")] != None:
      bstack1lll1l11l_opy_ += bstack1lll11llll_opy_[bstack11111ll_opy_ (u"ࠫࡩ࡫ࡶࡪࡥࡨࠫౙ")] + bstack11111ll_opy_ (u"ࠧ࠲ࠠࠣౚ")
      if bstack1lll11llll_opy_[bstack11111ll_opy_ (u"࠭࡯ࡴࠩ౛")] == bstack11111ll_opy_ (u"ࠢࡪࡱࡶࠦ౜"):
        bstack1lll1l11l_opy_ += bstack11111ll_opy_ (u"ࠣ࡫ࡒࡗࠥࠨౝ")
      bstack1lll1l11l_opy_ += (bstack1lll11llll_opy_[bstack11111ll_opy_ (u"ࠩࡲࡷࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭౞")] or bstack11111ll_opy_ (u"ࠪࠫ౟"))
      return bstack1lll1l11l_opy_
    else:
      bstack1lll1l11l_opy_ += bstack1111l111_opy_(bstack1lll11llll_opy_[bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬౠ")]) + bstack11111ll_opy_ (u"ࠧࠦࠢౡ") + (
              bstack1lll11llll_opy_[bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸ࡟ࡷࡧࡵࡷ࡮ࡵ࡮ࠨౢ")] or bstack11111ll_opy_ (u"ࠧࠨౣ")) + bstack11111ll_opy_ (u"ࠣ࠮ࠣࠦ౤")
      if bstack1lll11llll_opy_[bstack11111ll_opy_ (u"ࠩࡲࡷࠬ౥")] == bstack11111ll_opy_ (u"࡛ࠥ࡮ࡴࡤࡰࡹࡶࠦ౦"):
        bstack1lll1l11l_opy_ += bstack11111ll_opy_ (u"ࠦ࡜࡯࡮ࠡࠤ౧")
      bstack1lll1l11l_opy_ += bstack1lll11llll_opy_[bstack11111ll_opy_ (u"ࠬࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ౨")] or bstack11111ll_opy_ (u"࠭ࠧ౩")
      return bstack1lll1l11l_opy_
def bstack1l11lllll_opy_(bstack1lllll1111_opy_):
  if bstack1lllll1111_opy_ == bstack11111ll_opy_ (u"ࠢࡥࡱࡱࡩࠧ౪"):
    return bstack11111ll_opy_ (u"ࠨ࠾ࡷࡨࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࠤࡸࡺࡹ࡭ࡧࡀࠦࡨࡵ࡬ࡰࡴ࠽࡫ࡷ࡫ࡥ࡯࠽ࠥࡂࡁ࡬࡯࡯ࡶࠣࡧࡴࡲ࡯ࡳ࠿ࠥ࡫ࡷ࡫ࡥ࡯ࠤࡁࡇࡴࡳࡰ࡭ࡧࡷࡩࡩࡂ࠯ࡧࡱࡱࡸࡃࡂ࠯ࡵࡦࡁࠫ౫")
  elif bstack1lllll1111_opy_ == bstack11111ll_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤ౬"):
    return bstack11111ll_opy_ (u"ࠪࡀࡹࡪࠠࡤ࡮ࡤࡷࡸࡃࠢࡣࡵࡷࡥࡨࡱ࠭ࡥࡣࡷࡥࠧࠦࡳࡵࡻ࡯ࡩࡂࠨࡣࡰ࡮ࡲࡶ࠿ࡸࡥࡥ࠽ࠥࡂࡁ࡬࡯࡯ࡶࠣࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࡈࡤ࡭ࡱ࡫ࡤ࠽࠱ࡩࡳࡳࡺ࠾࠽࠱ࡷࡨࡃ࠭౭")
  elif bstack1lllll1111_opy_ == bstack11111ll_opy_ (u"ࠦࡵࡧࡳࡴࡧࡧࠦ౮"):
    return bstack11111ll_opy_ (u"ࠬࡂࡴࡥࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢࠡࡵࡷࡽࡱ࡫࠽ࠣࡥࡲࡰࡴࡸ࠺ࡨࡴࡨࡩࡳࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡨࡴࡨࡩࡳࠨ࠾ࡑࡣࡶࡷࡪࡪ࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ౯")
  elif bstack1lllll1111_opy_ == bstack11111ll_opy_ (u"ࠨࡥࡳࡴࡲࡶࠧ౰"):
    return bstack11111ll_opy_ (u"ࠧ࠽ࡶࡧࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࡵࡩࡩࡁࠢ࠿࠾ࡩࡳࡳࡺࠠࡤࡱ࡯ࡳࡷࡃࠢࡳࡧࡧࠦࡃࡋࡲࡳࡱࡵࡀ࠴࡬࡯࡯ࡶࡁࡀ࠴ࡺࡤ࠿ࠩ౱")
  elif bstack1lllll1111_opy_ == bstack11111ll_opy_ (u"ࠣࡶ࡬ࡱࡪࡵࡵࡵࠤ౲"):
    return bstack11111ll_opy_ (u"ࠩ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠦࠥࡹࡴࡺ࡮ࡨࡁࠧࡩ࡯࡭ࡱࡵ࠾ࠨ࡫ࡥࡢ࠵࠵࠺ࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࠣࡦࡧࡤ࠷࠷࠼ࠢ࠿ࡖ࡬ࡱࡪࡵࡵࡵ࠾࠲ࡪࡴࡴࡴ࠿࠾࠲ࡸࡩࡄࠧ౳")
  elif bstack1lllll1111_opy_ == bstack11111ll_opy_ (u"ࠥࡶࡺࡴ࡮ࡪࡰࡪࠦ౴"):
    return bstack11111ll_opy_ (u"ࠫࡁࡺࡤࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀࡢ࡭ࡣࡦ࡯ࡀࠨ࠾࠽ࡨࡲࡲࡹࠦࡣࡰ࡮ࡲࡶࡂࠨࡢ࡭ࡣࡦ࡯ࠧࡄࡒࡶࡰࡱ࡭ࡳ࡭࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ౵")
  else:
    return bstack11111ll_opy_ (u"ࠬࡂࡴࡥࠢࡤࡰ࡮࡭࡮࠾ࠤࡦࡩࡳࡺࡥࡳࠤࠣࡧࡱࡧࡳࡴ࠿ࠥࡦࡸࡺࡡࡤ࡭࠰ࡨࡦࡺࡡࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࡤ࡯ࡥࡨࡱ࠻ࠣࡀ࠿ࡪࡴࡴࡴࠡࡥࡲࡰࡴࡸ࠽ࠣࡤ࡯ࡥࡨࡱࠢ࠿ࠩ౶") + bstack1111l111_opy_(
      bstack1lllll1111_opy_) + bstack11111ll_opy_ (u"࠭࠼࠰ࡨࡲࡲࡹࡄ࠼࠰ࡶࡧࡂࠬ౷")
def bstack1ll1l11l1_opy_(session):
  return bstack11111ll_opy_ (u"ࠧ࠽ࡶࡵࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡷࡵࡷࠣࡀ࠿ࡸࡩࠦࡣ࡭ࡣࡶࡷࡂࠨࡢࡴࡶࡤࡧࡰ࠳ࡤࡢࡶࡤࠤࡸ࡫ࡳࡴ࡫ࡲࡲ࠲ࡴࡡ࡮ࡧࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࡻࡾࠤࠣࡸࡦࡸࡧࡦࡶࡀࠦࡤࡨ࡬ࡢࡰ࡮ࠦࡃࢁࡽ࠽࠱ࡤࡂࡁ࠵ࡴࡥࡀࡾࢁࢀࢃ࠼ࡵࡦࠣࡥࡱ࡯ࡧ࡯࠿ࠥࡧࡪࡴࡴࡦࡴࠥࠤࡨࡲࡡࡴࡵࡀࠦࡧࡹࡴࡢࡥ࡮࠱ࡩࡧࡴࡢࠤࡁࡿࢂࡂ࠯ࡵࡦࡁࡀࡹࡪࠠࡢ࡮࡬࡫ࡳࡃࠢࡤࡧࡱࡸࡪࡸࠢࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡤࡶࡸࡦࡩ࡫࠮ࡦࡤࡸࡦࠨ࠾ࡼࡿ࠿࠳ࡹࡪ࠾࠽ࡶࡧࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࠥࡩ࡬ࡢࡵࡶࡁࠧࡨࡳࡵࡣࡦ࡯࠲ࡪࡡࡵࡣࠥࡂࢀࢃ࠼࠰ࡶࡧࡂࡁࡺࡤࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠢࡦࡰࡦࡹࡳ࠾ࠤࡥࡷࡹࡧࡣ࡬࠯ࡧࡥࡹࡧࠢ࠿ࡽࢀࡀ࠴ࡺࡤ࠿࠾࠲ࡸࡷࡄࠧ౸").format(
    session[bstack11111ll_opy_ (u"ࠨࡲࡸࡦࡱ࡯ࡣࡠࡷࡵࡰࠬ౹")], bstack1lllll1ll1_opy_(session), bstack1l11lllll_opy_(session[bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡵࡷࡥࡹࡻࡳࠨ౺")]),
    bstack1l11lllll_opy_(session[bstack11111ll_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪ౻")]),
    bstack1111l111_opy_(session[bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࠬ౼")] or session[bstack11111ll_opy_ (u"ࠬࡪࡥࡷ࡫ࡦࡩࠬ౽")] or bstack11111ll_opy_ (u"࠭ࠧ౾")) + bstack11111ll_opy_ (u"ࠢࠡࠤ౿") + (session[bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡡࡹࡩࡷࡹࡩࡰࡰࠪಀ")] or bstack11111ll_opy_ (u"ࠩࠪಁ")),
    session[bstack11111ll_opy_ (u"ࠪࡳࡸ࠭ಂ")] + bstack11111ll_opy_ (u"ࠦࠥࠨಃ") + session[bstack11111ll_opy_ (u"ࠬࡵࡳࡠࡸࡨࡶࡸ࡯࡯࡯ࠩ಄")], session[bstack11111ll_opy_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨಅ")] or bstack11111ll_opy_ (u"ࠧࠨಆ"),
    session[bstack11111ll_opy_ (u"ࠨࡥࡵࡩࡦࡺࡥࡥࡡࡤࡸࠬಇ")] if session[bstack11111ll_opy_ (u"ࠩࡦࡶࡪࡧࡴࡦࡦࡢࡥࡹ࠭ಈ")] else bstack11111ll_opy_ (u"ࠪࠫಉ"))
def bstack11l1llll1_opy_(sessions, bstack1111l111l_opy_):
  try:
    bstack1ll1ll111_opy_ = bstack11111ll_opy_ (u"ࠦࠧಊ")
    if not os.path.exists(bstack1lllll11l1_opy_):
      os.mkdir(bstack1lllll11l1_opy_)
    with open(os.path.join(os.path.dirname(os.path.realpath(__file__)), bstack11111ll_opy_ (u"ࠬࡧࡳࡴࡧࡷࡷ࠴ࡸࡥࡱࡱࡵࡸ࠳࡮ࡴ࡮࡮ࠪಋ")), bstack11111ll_opy_ (u"࠭ࡲࠨಌ")) as f:
      bstack1ll1ll111_opy_ = f.read()
    bstack1ll1ll111_opy_ = bstack1ll1ll111_opy_.replace(bstack11111ll_opy_ (u"ࠧࡼࠧࡕࡉࡘ࡛ࡌࡕࡕࡢࡇࡔ࡛ࡎࡕࠧࢀࠫ಍"), str(len(sessions)))
    bstack1ll1ll111_opy_ = bstack1ll1ll111_opy_.replace(bstack11111ll_opy_ (u"ࠨࡽࠨࡆ࡚ࡏࡌࡅࡡࡘࡖࡑࠫࡽࠨಎ"), bstack1111l111l_opy_)
    bstack1ll1ll111_opy_ = bstack1ll1ll111_opy_.replace(bstack11111ll_opy_ (u"ࠩࡾࠩࡇ࡛ࡉࡍࡆࡢࡒࡆࡓࡅࠦࡿࠪಏ"),
                                              sessions[0].get(bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡࡱࡥࡲ࡫ࠧಐ")) if sessions[0] else bstack11111ll_opy_ (u"ࠫࠬ಑"))
    with open(os.path.join(bstack1lllll11l1_opy_, bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮࠱ࡷ࡫ࡰࡰࡴࡷ࠲࡭ࡺ࡭࡭ࠩಒ")), bstack11111ll_opy_ (u"࠭ࡷࠨಓ")) as stream:
      stream.write(bstack1ll1ll111_opy_.split(bstack11111ll_opy_ (u"ࠧࡼࠧࡖࡉࡘ࡙ࡉࡐࡐࡖࡣࡉࡇࡔࡂࠧࢀࠫಔ"))[0])
      for session in sessions:
        stream.write(bstack1ll1l11l1_opy_(session))
      stream.write(bstack1ll1ll111_opy_.split(bstack11111ll_opy_ (u"ࠨࡽࠨࡗࡊ࡙ࡓࡊࡑࡑࡗࡤࡊࡁࡕࡃࠨࢁࠬಕ"))[1])
    logger.info(bstack11111ll_opy_ (u"ࠩࡊࡩࡳ࡫ࡲࡢࡶࡨࡨࠥࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࠤࡧࡻࡩ࡭ࡦࠣࡥࡷࡺࡩࡧࡣࡦࡸࡸࠦࡡࡵࠢࡾࢁࠬಖ").format(bstack1lllll11l1_opy_));
  except Exception as e:
    logger.debug(bstack1llll1111l_opy_.format(str(e)))
def bstack1lllllllll_opy_(bstack111l11l1_opy_):
  global CONFIG
  try:
    host = bstack11111ll_opy_ (u"ࠪࡥࡵ࡯࠭ࡤ࡮ࡲࡹࡩ࠭ಗ") if bstack11111ll_opy_ (u"ࠫࡦࡶࡰࠨಘ") in CONFIG else bstack11111ll_opy_ (u"ࠬࡧࡰࡪࠩಙ")
    user = CONFIG[bstack11111ll_opy_ (u"࠭ࡵࡴࡧࡵࡒࡦࡳࡥࠨಚ")]
    key = CONFIG[bstack11111ll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪಛ")]
    bstack1lll11ll1l_opy_ = bstack11111ll_opy_ (u"ࠨࡣࡳࡴ࠲ࡧࡵࡵࡱࡰࡥࡹ࡫ࠧಜ") if bstack11111ll_opy_ (u"ࠩࡤࡴࡵ࠭ಝ") in CONFIG else bstack11111ll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷࡩࠬಞ")
    url = bstack11111ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࢁࡽ࠻ࡽࢀࡄࢀࢃ࠮ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰ࠴ࡣࡰ࡯࠲ࡿࢂ࠵ࡢࡶ࡫࡯ࡨࡸ࠵ࡻࡾ࠱ࡶࡩࡸࡹࡩࡰࡰࡶ࠲࡯ࡹ࡯࡯ࠩಟ").format(user, key, host, bstack1lll11ll1l_opy_,
                                                                                bstack111l11l1_opy_)
    headers = {
      bstack11111ll_opy_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡴࡺࡲࡨࠫಠ"): bstack11111ll_opy_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳࡯ࡹ࡯࡯ࠩಡ"),
    }
    proxies = bstack1l11l1ll1_opy_(CONFIG, url)
    response = requests.get(url, headers=headers, proxies=proxies)
    if response.json():
      return list(map(lambda session: session[bstack11111ll_opy_ (u"ࠧࡢࡷࡷࡳࡲࡧࡴࡪࡱࡱࡣࡸ࡫ࡳࡴ࡫ࡲࡲࠬಢ")], response.json()))
  except Exception as e:
    logger.debug(bstack1l11ll11l_opy_.format(str(e)))
def bstack1lll1l1lll_opy_():
  global CONFIG
  try:
    if bstack11111ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫಣ") in CONFIG:
      host = bstack11111ll_opy_ (u"ࠩࡤࡴ࡮࠳ࡣ࡭ࡱࡸࡨࠬತ") if bstack11111ll_opy_ (u"ࠪࡥࡵࡶࠧಥ") in CONFIG else bstack11111ll_opy_ (u"ࠫࡦࡶࡩࠨದ")
      user = CONFIG[bstack11111ll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫ࠧಧ")]
      key = CONFIG[bstack11111ll_opy_ (u"࠭ࡡࡤࡥࡨࡷࡸࡑࡥࡺࠩನ")]
      bstack1lll11ll1l_opy_ = bstack11111ll_opy_ (u"ࠧࡢࡲࡳ࠱ࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭಩") if bstack11111ll_opy_ (u"ࠨࡣࡳࡴࠬಪ") in CONFIG else bstack11111ll_opy_ (u"ࠩࡤࡹࡹࡵ࡭ࡢࡶࡨࠫಫ")
      url = bstack11111ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࢀࢃ࠺ࡼࡿࡃࡿࢂ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮࠱ࡾࢁ࠴ࡨࡵࡪ࡮ࡧࡷ࠳ࡰࡳࡰࡰࠪಬ").format(user, key, host, bstack1lll11ll1l_opy_)
      headers = {
        bstack11111ll_opy_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪಭ"): bstack11111ll_opy_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲࡮ࡸࡵ࡮ࠨಮ"),
      }
      if bstack11111ll_opy_ (u"࠭ࡢࡶ࡫࡯ࡨࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲࠨಯ") in CONFIG:
        params = {bstack11111ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬರ"): CONFIG[bstack11111ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪࡎࡢ࡯ࡨࠫಱ")], bstack11111ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡠ࡫ࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬಲ"): CONFIG[bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶࠬಳ")]}
      else:
        params = {bstack11111ll_opy_ (u"ࠫࡳࡧ࡭ࡦࠩ಴"): CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡒࡦࡳࡥࠨವ")]}
      proxies = bstack1l11l1ll1_opy_(CONFIG, url)
      response = requests.get(url, params=params, headers=headers, proxies=proxies)
      if response.json():
        bstack11l11lll1_opy_ = response.json()[0][bstack11111ll_opy_ (u"࠭ࡡࡶࡶࡲࡱࡦࡺࡩࡰࡰࡢࡦࡺ࡯࡬ࡥࠩಶ")]
        if bstack11l11lll1_opy_:
          bstack1111l111l_opy_ = bstack11l11lll1_opy_[bstack11111ll_opy_ (u"ࠧࡱࡷࡥࡰ࡮ࡩ࡟ࡶࡴ࡯ࠫಷ")].split(bstack11111ll_opy_ (u"ࠨࡲࡸࡦࡱ࡯ࡣ࠮ࡤࡸ࡭ࡱࡪࠧಸ"))[0] + bstack11111ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡴ࠱ࠪಹ") + bstack11l11lll1_opy_[
            bstack11111ll_opy_ (u"ࠪ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭಺")]
          logger.info(bstack11llll111_opy_.format(bstack1111l111l_opy_))
          bstack1ll1ll1ll1_opy_ = CONFIG[bstack11111ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡑࡥࡲ࡫ࠧ಻")]
          if bstack11111ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡍࡩ࡫࡮ࡵ࡫ࡩ࡭ࡪࡸ಼ࠧ") in CONFIG:
            bstack1ll1ll1ll1_opy_ += bstack11111ll_opy_ (u"࠭ࠠࠨಽ") + CONFIG[bstack11111ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩಾ")]
          if bstack1ll1ll1ll1_opy_ != bstack11l11lll1_opy_[bstack11111ll_opy_ (u"ࠨࡰࡤࡱࡪ࠭ಿ")]:
            logger.debug(bstack11lll1ll1_opy_.format(bstack11l11lll1_opy_[bstack11111ll_opy_ (u"ࠩࡱࡥࡲ࡫ࠧೀ")], bstack1ll1ll1ll1_opy_))
          return [bstack11l11lll1_opy_[bstack11111ll_opy_ (u"ࠪ࡬ࡦࡹࡨࡦࡦࡢ࡭ࡩ࠭ು")], bstack1111l111l_opy_]
    else:
      logger.warn(bstack1ll11l111_opy_)
  except Exception as e:
    logger.debug(bstack1111l1ll1_opy_.format(str(e)))
  return [None, None]
def bstack111llllll_opy_(url, bstack1l111111l_opy_=False):
  global CONFIG
  global bstack1l11llll1_opy_
  if not bstack1l11llll1_opy_:
    hostname = bstack1ll1l1l1l1_opy_(url)
    is_private = bstack1lll1l1111_opy_(hostname)
    if (bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡏࡳࡨࡧ࡬ࠨೂ") in CONFIG and not CONFIG[bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡐࡴࡩࡡ࡭ࠩೃ")]) and (is_private or bstack1l111111l_opy_):
      bstack1l11llll1_opy_ = hostname
def bstack1ll1l1l1l1_opy_(url):
  return urlparse(url).hostname
def bstack1lll1l1111_opy_(hostname):
  for bstack111111l1l_opy_ in bstack11l11l1l1_opy_:
    regex = re.compile(bstack111111l1l_opy_)
    if regex.match(hostname):
      return True
  return False
def bstack1111llll1_opy_(key_name):
  return True if key_name in threading.current_thread().__dict__.keys() else False