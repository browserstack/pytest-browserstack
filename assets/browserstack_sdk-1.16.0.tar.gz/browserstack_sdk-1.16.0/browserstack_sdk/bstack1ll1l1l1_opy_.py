# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack1l1l1l1_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11111ll_opy_ (bstack11111l1_opy_):
    global bstack1lll11_opy_
    bstack1l1ll_opy_ = ord (bstack11111l1_opy_ [-1])
    bstack1ll1l1_opy_ = bstack11111l1_opy_ [:-1]
    bstack1lll11l_opy_ = bstack1l1ll_opy_ % len (bstack1ll1l1_opy_)
    bstack1lllll1_opy_ = bstack1ll1l1_opy_ [:bstack1lll11l_opy_] + bstack1ll1l1_opy_ [bstack1lll11l_opy_:]
    if bstack1l1llll_opy_:
        bstack1l111_opy_ = unicode () .join ([unichr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1l111_opy_ = str () .join ([chr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1l111_opy_)
import os
from browserstack_sdk.bstack1llll11l_opy_ import *
from bstack_utils.helper import bstack1lll1l1l_opy_
from bstack_utils.messages import bstack1l1l1lll_opy_
from bstack_utils.constants import bstack1ll1l111_opy_
class bstack1ll11l11_opy_:
    def __init__(self, args, logger, bstack1ll1ll1l_opy_, bstack1l1lll1l_opy_):
        self.args = args
        self.logger = logger
        self.bstack1ll1ll1l_opy_ = bstack1ll1ll1l_opy_
        self.bstack1l1lll1l_opy_ = bstack1l1lll1l_opy_
        self._prepareconfig = None
        self.Config = None
        self.runner = None
        self.bstack1ll111ll_opy_ = []
        self.bstack1llll1ll_opy_ = None
        self.bstack1ll1l1ll_opy_ = []
        self.bstack1lll111l_opy_ = self.bstack1ll1lll1_opy_()
    def start(self):
        self.bstack1ll11lll_opy_()
        self.parse_args()
        self.bstack1lll1l11_opy_()
    def bstack1ll11ll1_opy_(self, bstack1l1lllll_opy_):
        self.parse_args()
        self.bstack1lll1l11_opy_()
        self.bstack1l1ll11l_opy_(bstack1l1lllll_opy_)
        self.bstack1lll11ll_opy_()
    @staticmethod
    def version():
        import pytest
        return pytest.__version__
    def bstack1ll1111l_opy_(self, arg):
        if arg in self.args:
            i = self.args.index(arg)
            self.args.pop(i + 1)
            self.args.pop(i)
    def parse_args(self):
        try:
            bstack1lll1lll_opy_ = [bstack11111ll_opy_ (u"ࠪ࠱࠲ࡧࡲࡨࡵࠪࡶ"), bstack11111ll_opy_ (u"ࠫ࠲࠳ࡤࡳ࡫ࡹࡩࡷ࠭ࡷ"), bstack11111ll_opy_ (u"ࠬ࠳࠭ࡱ࡮ࡸ࡫࡮ࡴࡳࠨࡸ"), bstack11111ll_opy_ (u"࠭࠭ࡱࠩࡹ"), bstack11111ll_opy_ (u"ࠧ࠮࠯ࡱࡹࡲࡶࡲࡰࡥࡨࡷࡸ࡫ࡳࠨࡺ"), bstack11111ll_opy_ (u"ࠨ࠯ࡱࠫࡻ")]
            for arg in bstack1lll1lll_opy_:
                self.bstack1ll1111l_opy_(arg)
        except Exception as exc:
            self.logger.error(str(exc))
    def bstack1llll111_opy_(self, bstack1ll111ll_opy_):
        try:
            if os.environ.get(bstack11111ll_opy_ (u"ࠤࡅࡖࡔ࡝ࡓࡆࡔࡖࡘࡆࡉࡋࡠࡔࡈࡖ࡚ࡔࠢࡼ"), None) == bstack11111ll_opy_ (u"ࠥࡸࡷࡻࡥࠣࡽ"):
                tests = os.environ.get(bstack11111ll_opy_ (u"ࠦࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡖࡊࡘࡕࡏࡡࡗࡉࡘ࡚ࡓࠣࡾ"), None)
                if bstack11111ll_opy_ (u"ࠧࡸࡥࡳࡷࡱࡘࡪࡹࡴࡴࠤࡿ") in self.bstack1ll1ll1l_opy_:
                    del self.bstack1ll1ll1l_opy_[bstack11111ll_opy_ (u"ࠨࡲࡦࡴࡸࡲ࡙࡫ࡳࡵࡵࠥࢀ")]
                if tests is None or tests == bstack11111ll_opy_ (u"ࠢ࡯ࡷ࡯ࡰࠧࢁ"):
                    return bstack1ll111ll_opy_
                bstack1ll111ll_opy_ = tests.split(bstack11111ll_opy_ (u"ࠨ࠮ࠪࢂ"))
                return bstack1ll111ll_opy_
        except Exception as exc:
            self.logger.error(str(exc))
        return bstack1ll111ll_opy_
    def get_args(self):
        return self.args
    def bstack1lll1l11_opy_(self):
        config = self._prepareconfig(self.args)
        bstack1ll111ll_opy_ = config.args
        bstack1ll1l11l_opy_ = config.invocation_params.args
        bstack1ll1l11l_opy_ = list(bstack1ll1l11l_opy_)
        bstack1l1llll1_opy_ = [os.path.normpath(item) for item in bstack1ll111ll_opy_]
        bstack1l1lll11_opy_ = [os.path.normpath(item) for item in bstack1ll1l11l_opy_]
        bstack1llll1ll_opy_ = [item for item in bstack1l1lll11_opy_ if item not in bstack1l1llll1_opy_]
        import platform as pf
        if pf.system().lower() == bstack11111ll_opy_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸࡵࠪࢃ"):
            from pathlib import PureWindowsPath, PurePosixPath
            bstack1ll111ll_opy_ = [str(PurePosixPath(PureWindowsPath(bstack1llll1l1_opy_)))
                          for bstack1llll1l1_opy_ in bstack1ll111ll_opy_]
        bstack1ll111ll_opy_ = self.bstack1llll111_opy_(bstack1ll111ll_opy_)
        self.bstack1ll111ll_opy_ = bstack1ll111ll_opy_
        self.bstack1llll1ll_opy_ = bstack1llll1ll_opy_
        return bstack1llll1ll_opy_
    def bstack1ll11lll_opy_(self):
        try:
            from _pytest.config import _prepareconfig
            from _pytest.config import Config
            from _pytest import runner
            import importlib
            bstack1ll1ll11_opy_ = importlib.find_loader(bstack11111ll_opy_ (u"ࠪࡴࡾࡺࡥࡴࡶࡢࡷࡪࡲࡥ࡯࡫ࡸࡱࠬࢄ"))
            self._prepareconfig = _prepareconfig
            self.Config = Config
            self.runner = runner
        except Exception as e:
            self.logger.warn(e, bstack1l1l1lll_opy_)
    def bstack1l1ll11l_opy_(self, bstack1l1lllll_opy_):
        if bstack11111ll_opy_ (u"ࠫ࠲࠳ࡣࡢࡥ࡫ࡩ࠲ࡩ࡬ࡦࡣࡵࠫࢅ") not in self.bstack1llll1ll_opy_:
            self.bstack1llll1ll_opy_.append(bstack11111ll_opy_ (u"ࠬ࠳࠭ࡤࡣࡦ࡬ࡪ࠳ࡣ࡭ࡧࡤࡶࠬࢆ"))
        if bstack1l1lllll_opy_:
            self.bstack1llll1ll_opy_.append(bstack11111ll_opy_ (u"࠭࠭࠮ࡵ࡮࡭ࡵ࡙ࡥࡴࡵ࡬ࡳࡳࡔࡡ࡮ࡧࠪࢇ"))
            self.bstack1llll1ll_opy_.append(bstack11111ll_opy_ (u"ࠧࡕࡴࡸࡩࠬ࢈"))
        if not self.bstack1lll111l_opy_:
            self.bstack1llll1ll_opy_.append(bstack11111ll_opy_ (u"ࠨ࠯ࡳࠫࢉ"))
            self.bstack1llll1ll_opy_.append(bstack11111ll_opy_ (u"ࠩࡳࡽࡹ࡫ࡳࡵࡡࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡱ࡮ࡸ࡫࡮ࡴࠧࢊ"))
        self.bstack1llll1ll_opy_.append(bstack11111ll_opy_ (u"ࠪ࠱࠲ࡪࡲࡪࡸࡨࡶࠬࢋ"))
        self.bstack1llll1ll_opy_.append(bstack11111ll_opy_ (u"ࠫࡨ࡮ࡲࡰ࡯ࡨࠫࢌ"))
    def bstack1lll11ll_opy_(self):
        bstack1ll1l1ll_opy_ = []
        for spec in self.bstack1ll111ll_opy_:
            bstack1lll11l1_opy_ = [spec]
            bstack1lll11l1_opy_ += self.bstack1llll1ll_opy_
            bstack1ll1l1ll_opy_.append(bstack1lll11l1_opy_)
        self.bstack1ll1l1ll_opy_ = bstack1ll1l1ll_opy_
        return bstack1ll1l1ll_opy_
    def bstack1ll1lll1_opy_(self):
        try:
            from pytest_bdd import reporting
            self.bstack1lll111l_opy_ = True
            return True
        except Exception as e:
            self.bstack1lll111l_opy_ = False
        return self.bstack1lll111l_opy_
    def bstack1l1ll1ll_opy_(self):
        bstack1l1ll1l1_opy_ = 1
        if bstack11111ll_opy_ (u"ࠬࡶࡡࡳࡣ࡯ࡰࡪࡲࡳࡑࡧࡵࡔࡱࡧࡴࡧࡱࡵࡱࠬࢍ") in self.bstack1ll1ll1l_opy_:
            bstack1l1ll1l1_opy_ = self.bstack1ll1ll1l_opy_[bstack11111ll_opy_ (u"࠭ࡰࡢࡴࡤࡰࡱ࡫࡬ࡴࡒࡨࡶࡕࡲࡡࡵࡨࡲࡶࡲ࠭ࢎ")]
        bstack1ll11l1l_opy_ = int(bstack1l1ll1l1_opy_) * int(len(self.bstack1ll1ll1l_opy_[bstack11111ll_opy_ (u"ࠧࡱ࡮ࡤࡸ࡫ࡵࡲ࡮ࡵࠪ࢏")]))
        execution_items = []
        for bstack1lll11l1_opy_ in self.bstack1ll1l1ll_opy_:
            for index, _ in enumerate(self.bstack1ll1ll1l_opy_[bstack11111ll_opy_ (u"ࠨࡲ࡯ࡥࡹ࡬࡯ࡳ࡯ࡶࠫ࢐")]):
                item = {}
                item[bstack11111ll_opy_ (u"ࠩࡤࡶ࡬࠭࢑")] = bstack1lll11l1_opy_
                item[bstack11111ll_opy_ (u"ࠪ࡭ࡳࡪࡥࡹࠩ࢒")] = index
                execution_items.append(item)
        bstack1lll1111_opy_ = bstack1lll1l1l_opy_(execution_items, bstack1ll11l1l_opy_)
        return bstack1lll1111_opy_
    def bstack1ll111l1_opy_(self, bstack1lll1111_opy_, bstack1lll1ll1_opy_):
        for execution_item in bstack1lll1111_opy_:
            bstack1lllll11_opy_ = []
            for item in execution_item:
                bstack1lllll11_opy_.append(bstack1l1ll111_opy_(name=str(item[bstack11111ll_opy_ (u"ࠫ࡮ࡴࡤࡦࡺࠪ࢓")]),
                                                     target=self.bstack1ll11111_opy_,
                                                     args=(item[bstack11111ll_opy_ (u"ࠬࡧࡲࡨࠩ࢔")], bstack1lll1ll1_opy_)))
            for t in bstack1lllll11_opy_:
                t.start()
            for t in bstack1lllll11_opy_:
                t.join()
    def bstack1ll11111_opy_(self, arg, bstack1lll1ll1_opy_):
        arg.append(bstack11111ll_opy_ (u"ࠨ࠭࠮࡫ࡰࡴࡴࡸࡴ࠮࡯ࡲࡨࡪࡃࡩ࡮ࡲࡲࡶࡹࡲࡩࡣࠤ࢕"))
        arg.append(bstack11111ll_opy_ (u"ࠢ࠮࡙ࠥ࢖"))
        arg.append(bstack11111ll_opy_ (u"ࠣ࡫ࡪࡲࡴࡸࡥ࠻ࡏࡲࡨࡺࡲࡥࠡࡣ࡯ࡶࡪࡧࡤࡺࠢ࡬ࡱࡵࡵࡲࡵࡧࡧ࠾ࡵࡿࡴࡦࡵࡷ࠲ࡕࡿࡴࡦࡵࡷ࡛ࡦࡸ࡮ࡪࡰࡪࠦࢗ"))
        arg.append(bstack11111ll_opy_ (u"ࠤ࠰࡛ࠧ࢘"))
        arg.append(bstack11111ll_opy_ (u"ࠥ࡭࡬ࡴ࡯ࡳࡧ࠽ࡘ࡭࡫ࠠࡩࡱࡲ࡯࡮ࡳࡰ࡭ࠤ࢙"))
        bstack1lll1ll1_opy_(bstack1ll1l111_opy_)
        if self.bstack1l1lll1l_opy_:
            os.environ[bstack11111ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢ࡙ࡘࡋࡒࡏࡃࡐࡉ࢚ࠬ")] = self.bstack1ll1ll1l_opy_[bstack11111ll_opy_ (u"ࠬࡻࡳࡦࡴࡑࡥࡲ࡫࢛ࠧ")]
            os.environ[bstack11111ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡇࡃࡄࡇࡖࡗࡤࡑࡅ࡚ࠩ࢜")] = self.bstack1ll1ll1l_opy_[bstack11111ll_opy_ (u"ࠧࡢࡥࡦࡩࡸࡹࡋࡦࡻࠪ࢝")]
        os.environ[bstack11111ll_opy_ (u"ࠨࡄࡕࡓ࡜࡙ࡅࡓࡕࡗࡅࡈࡑ࡟ࡂࡗࡗࡓࡒࡇࡔࡊࡑࡑࠫ࢞")] = self.bstack1l1lll1l_opy_.__str__()
        from _pytest.config import main as bstack1ll1llll_opy_
        bstack1ll1llll_opy_(arg)