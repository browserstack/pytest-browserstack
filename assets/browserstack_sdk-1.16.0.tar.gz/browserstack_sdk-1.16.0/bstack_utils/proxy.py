# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack1l1l1l1_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11111ll_opy_ (bstack11111l1_opy_):
    global bstack1lll11_opy_
    bstack1l1ll_opy_ = ord (bstack11111l1_opy_ [-1])
    bstack1ll1l1_opy_ = bstack11111l1_opy_ [:-1]
    bstack1lll11l_opy_ = bstack1l1ll_opy_ % len (bstack1ll1l1_opy_)
    bstack1lllll1_opy_ = bstack1ll1l1_opy_ [:bstack1lll11l_opy_] + bstack1ll1l1_opy_ [bstack1lll11l_opy_:]
    if bstack1l1llll_opy_:
        bstack1l111_opy_ = unicode () .join ([unichr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1l111_opy_ = str () .join ([chr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1l111_opy_)
import os
from urllib.parse import urlparse
from bstack_utils.messages import bstack1ll11l1l1l_opy_
def bstack1ll11ll11l_opy_(url):
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False
def bstack1ll11ll1l1_opy_(bstack1ll11l11ll_opy_, bstack1ll11ll111_opy_):
    from pypac import get_pac
    from pypac import PACSession
    from pypac.parser import PACFile
    import socket
    if os.path.isfile(bstack1ll11l11ll_opy_):
        with open(bstack1ll11l11ll_opy_) as f:
            pac = PACFile(f.read())
    elif bstack1ll11ll11l_opy_(bstack1ll11l11ll_opy_):
        pac = get_pac(url=bstack1ll11l11ll_opy_)
    else:
        raise Exception(bstack11111ll_opy_ (u"ࠨࡒࡤࡧࠥ࡬ࡩ࡭ࡧࠣࡨࡴ࡫ࡳࠡࡰࡲࡸࠥ࡫ࡸࡪࡵࡷ࠾ࠥࢁࡽࠨೆ").format(bstack1ll11l11ll_opy_))
    session = PACSession(pac)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect((bstack11111ll_opy_ (u"ࠤ࠻࠲࠽࠴࠸࠯࠺ࠥೇ"), 80))
        bstack1ll11l1ll1_opy_ = s.getsockname()[0]
        s.close()
    except:
        bstack1ll11l1ll1_opy_ = bstack11111ll_opy_ (u"ࠪ࠴࠳࠶࠮࠱࠰࠳ࠫೈ")
    proxy_url = session.get_pac().find_proxy_for_url(bstack1ll11ll111_opy_, bstack1ll11l1ll1_opy_)
    return proxy_url
def bstack11lll1ll_opy_(config):
    return bstack11111ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡒࡵࡳࡽࡿࠧ೉") in config or bstack11111ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࡔࡷࡵࡸࡺࠩೊ") in config
def bstack11l1l1lll_opy_(config):
    if not bstack11lll1ll_opy_(config):
        return
    if config.get(bstack11111ll_opy_ (u"࠭ࡨࡵࡶࡳࡔࡷࡵࡸࡺࠩೋ")):
        return config.get(bstack11111ll_opy_ (u"ࠧࡩࡶࡷࡴࡕࡸ࡯ࡹࡻࠪೌ"))
    if config.get(bstack11111ll_opy_ (u"ࠨࡪࡷࡸࡵࡹࡐࡳࡱࡻࡽ್ࠬ")):
        return config.get(bstack11111ll_opy_ (u"ࠩ࡫ࡸࡹࡶࡳࡑࡴࡲࡼࡾ࠭೎"))
def bstack1l11l1ll1_opy_(config, bstack1ll11ll111_opy_):
    proxy = bstack11l1l1lll_opy_(config)
    proxies = {}
    if config.get(bstack11111ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡑࡴࡲࡼࡾ࠭೏")) or config.get(bstack11111ll_opy_ (u"ࠫ࡭ࡺࡴࡱࡵࡓࡶࡴࡾࡹࠨ೐")):
        if proxy.endswith(bstack11111ll_opy_ (u"ࠬ࠴ࡰࡢࡥࠪ೑")):
            proxies = bstack1llllll11l_opy_(proxy, bstack1ll11ll111_opy_)
        else:
            proxies = {
                bstack11111ll_opy_ (u"࠭ࡨࡵࡶࡳࡷࠬ೒"): proxy
            }
    return proxies
def bstack1llllll11l_opy_(bstack1ll11l11ll_opy_, bstack1ll11ll111_opy_):
    proxies = {}
    global bstack1ll11l1lll_opy_
    if bstack11111ll_opy_ (u"ࠧࡑࡃࡆࡣࡕࡘࡏ࡙࡛ࠪ೓") in globals():
        return bstack1ll11l1lll_opy_
    try:
        proxy = bstack1ll11ll1l1_opy_(bstack1ll11l11ll_opy_, bstack1ll11ll111_opy_)
        if bstack11111ll_opy_ (u"ࠣࡆࡌࡖࡊࡉࡔࠣ೔") in proxy:
            proxies = {}
        elif bstack11111ll_opy_ (u"ࠤࡋࡘ࡙ࡖࠢೕ") in proxy or bstack11111ll_opy_ (u"ࠥࡌ࡙࡚ࡐࡔࠤೖ") in proxy or bstack11111ll_opy_ (u"ࠦࡘࡕࡃࡌࡕࠥ೗") in proxy:
            bstack1ll11l1l11_opy_ = proxy.split(bstack11111ll_opy_ (u"ࠧࠦࠢ೘"))
            if bstack11111ll_opy_ (u"ࠨ࠺࠰࠱ࠥ೙") in bstack11111ll_opy_ (u"ࠢࠣ೚").join(bstack1ll11l1l11_opy_[1:]):
                proxies = {
                    bstack11111ll_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧ೛"): bstack11111ll_opy_ (u"ࠤࠥ೜").join(bstack1ll11l1l11_opy_[1:])
                }
            else:
                proxies = {
                    bstack11111ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩೝ"): str(bstack1ll11l1l11_opy_[0]).lower() + bstack11111ll_opy_ (u"ࠦ࠿࠵࠯ࠣೞ") + bstack11111ll_opy_ (u"ࠧࠨ೟").join(bstack1ll11l1l11_opy_[1:])
                }
        elif bstack11111ll_opy_ (u"ࠨࡐࡓࡑ࡛࡝ࠧೠ") in proxy:
            bstack1ll11l1l11_opy_ = proxy.split(bstack11111ll_opy_ (u"ࠢࠡࠤೡ"))
            if bstack11111ll_opy_ (u"ࠣ࠼࠲࠳ࠧೢ") in bstack11111ll_opy_ (u"ࠤࠥೣ").join(bstack1ll11l1l11_opy_[1:]):
                proxies = {
                    bstack11111ll_opy_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ೤"): bstack11111ll_opy_ (u"ࠦࠧ೥").join(bstack1ll11l1l11_opy_[1:])
                }
            else:
                proxies = {
                    bstack11111ll_opy_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ೦"): bstack11111ll_opy_ (u"ࠨࡨࡵࡶࡳ࠾࠴࠵ࠢ೧") + bstack11111ll_opy_ (u"ࠢࠣ೨").join(bstack1ll11l1l11_opy_[1:])
                }
        else:
            proxies = {
                bstack11111ll_opy_ (u"ࠨࡪࡷࡸࡵࡹࠧ೩"): proxy
            }
    except Exception as e:
        print(bstack11111ll_opy_ (u"ࠤࡶࡳࡲ࡫ࠠࡦࡴࡵࡳࡷࠨ೪"), bstack1ll11l1l1l_opy_.format(bstack1ll11l11ll_opy_, str(e)))
    bstack1ll11l1lll_opy_ = proxies
    return proxies