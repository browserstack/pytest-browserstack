# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack1l1l1l1_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11111ll_opy_ (bstack11111l1_opy_):
    global bstack1lll11_opy_
    bstack1l1ll_opy_ = ord (bstack11111l1_opy_ [-1])
    bstack1ll1l1_opy_ = bstack11111l1_opy_ [:-1]
    bstack1lll11l_opy_ = bstack1l1ll_opy_ % len (bstack1ll1l1_opy_)
    bstack1lllll1_opy_ = bstack1ll1l1_opy_ [:bstack1lll11l_opy_] + bstack1ll1l1_opy_ [bstack1lll11l_opy_:]
    if bstack1l1llll_opy_:
        bstack1l111_opy_ = unicode () .join ([unichr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1l111_opy_ = str () .join ([chr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1l111_opy_)
import datetime
import os
import re
import subprocess
import git
import requests
from bstack_utils.config import Config
from bstack_utils.constants import bstack1ll11l1111_opy_
from bstack_utils.proxy import bstack1l11l1ll1_opy_
bstack1llllll1l1_opy_ = Config.get_instance()
def bstack1l1ll1l11l_opy_(config):
    return config[bstack11111ll_opy_ (u"ࠪࡹࡸ࡫ࡲࡏࡣࡰࡩࠬ࿘")]
def bstack1l1l1lllll_opy_(config):
    return config[bstack11111ll_opy_ (u"ࠫࡦࡩࡣࡦࡵࡶࡏࡪࡿࠧ࿙")]
def bstack1l1l11l1l1_opy_(obj):
    values = []
    bstack1l11lllll1_opy_ = re.compile(bstack11111ll_opy_ (u"ࡷࠨ࡞ࡄࡗࡖࡘࡔࡓ࡟ࡕࡃࡊࡣࡡࡪࠫࠥࠤ࿚"), re.I)
    for key in obj.keys():
        if bstack1l11lllll1_opy_.match(key):
            values.append(obj[key])
    return values
def bstack1l1ll11lll_opy_(config):
    tags = []
    tag = config.get(bstack11111ll_opy_ (u"ࠨࡣࡶࡵࡷࡳࡲ࡚ࡡࡨࠤ࿛")) or os.environ.get(bstack11111ll_opy_ (u"ࠢࡄࡗࡖࡘࡔࡓ࡟ࡕࡃࡊࠦ࿜"))
    if tag:
        tags.append(tag)
    tags.extend(bstack1l1l11l1l1_opy_(os.environ))
    tags.extend(bstack1l1l11l1l1_opy_(config))
    return tags
def bstack1l1l111l11_opy_(markers):
    tags = []
    for marker in markers:
        tags.append(marker.name)
    return tags
def bstack1l1l1111ll_opy_(bstack1l1l111111_opy_):
    if not bstack1l1l111111_opy_:
        return bstack11111ll_opy_ (u"ࠨࠩ࿝")
    return bstack11111ll_opy_ (u"ࠤࡾࢁࠥ࠮ࡻࡾࠫࠥ࿞").format(bstack1l1l111111_opy_.name, bstack1l1l111111_opy_.email)
def bstack1l1ll1l1l1_opy_():
    try:
        repo = git.Repo(search_parent_directories=True)
        bstack1l1l111ll1_opy_ = repo.common_dir
        info = {
            bstack11111ll_opy_ (u"ࠥࡷ࡭ࡧࠢ࿟"): repo.head.commit.hexsha,
            bstack11111ll_opy_ (u"ࠦࡸ࡮࡯ࡳࡶࡢࡷ࡭ࡧࠢ࿠"): repo.git.rev_parse(repo.head.commit, short=True),
            bstack11111ll_opy_ (u"ࠧࡨࡲࡢࡰࡦ࡬ࠧ࿡"): repo.active_branch.name,
            bstack11111ll_opy_ (u"ࠨࡴࡢࡩࠥ࿢"): repo.git.describe(all=True, tags=True, exact_match=True),
            bstack11111ll_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺࡴࡦࡴࠥ࿣"): bstack1l1l1111ll_opy_(repo.head.commit.committer),
            bstack11111ll_opy_ (u"ࠣࡥࡲࡱࡲ࡯ࡴࡵࡧࡵࡣࡩࡧࡴࡦࠤ࿤"): repo.head.commit.committed_datetime.isoformat(),
            bstack11111ll_opy_ (u"ࠤࡤࡹࡹ࡮࡯ࡳࠤ࿥"): bstack1l1l1111ll_opy_(repo.head.commit.author),
            bstack11111ll_opy_ (u"ࠥࡥࡺࡺࡨࡰࡴࡢࡨࡦࡺࡥࠣ࿦"): repo.head.commit.authored_datetime.isoformat(),
            bstack11111ll_opy_ (u"ࠦࡨࡵ࡭࡮࡫ࡷࡣࡲ࡫ࡳࡴࡣࡪࡩࠧ࿧"): repo.head.commit.message,
            bstack11111ll_opy_ (u"ࠧࡸ࡯ࡰࡶࠥ࿨"): repo.git.rev_parse(bstack11111ll_opy_ (u"ࠨ࠭࠮ࡵ࡫ࡳࡼ࠳ࡴࡰࡲ࡯ࡩࡻ࡫࡬ࠣ࿩")),
            bstack11111ll_opy_ (u"ࠢࡤࡱࡰࡱࡴࡴ࡟ࡨ࡫ࡷࡣࡩ࡯ࡲࠣ࿪"): bstack1l1l111ll1_opy_,
            bstack11111ll_opy_ (u"ࠣࡹࡲࡶࡰࡺࡲࡦࡧࡢ࡫࡮ࡺ࡟ࡥ࡫ࡵࠦ࿫"): subprocess.check_output([bstack11111ll_opy_ (u"ࠤࡪ࡭ࡹࠨ࿬"), bstack11111ll_opy_ (u"ࠥࡶࡪࡼ࠭ࡱࡣࡵࡷࡪࠨ࿭"), bstack11111ll_opy_ (u"ࠦ࠲࠳ࡧࡪࡶ࠰ࡧࡴࡳ࡭ࡰࡰ࠰ࡨ࡮ࡸࠢ࿮")]).strip().decode(
                bstack11111ll_opy_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ࿯")),
            bstack11111ll_opy_ (u"ࠨ࡬ࡢࡵࡷࡣࡹࡧࡧࠣ࿰"): repo.git.describe(tags=True, abbrev=0, always=True),
            bstack11111ll_opy_ (u"ࠢࡤࡱࡰࡱ࡮ࡺࡳࡠࡵ࡬ࡲࡨ࡫࡟࡭ࡣࡶࡸࡤࡺࡡࡨࠤ࿱"): repo.git.rev_list(
                bstack11111ll_opy_ (u"ࠣࡽࢀ࠲࠳ࢁࡽࠣ࿲").format(repo.head.commit, repo.git.describe(tags=True, abbrev=0, always=True)), count=True)
        }
        remotes = repo.remotes
        bstack1l1l111lll_opy_ = []
        for remote in remotes:
            bstack1l1l111l1l_opy_ = {
                bstack11111ll_opy_ (u"ࠤࡱࡥࡲ࡫ࠢ࿳"): remote.name,
                bstack11111ll_opy_ (u"ࠥࡹࡷࡲࠢ࿴"): remote.url,
            }
            bstack1l1l111lll_opy_.append(bstack1l1l111l1l_opy_)
        return {
            bstack11111ll_opy_ (u"ࠦࡳࡧ࡭ࡦࠤ࿵"): bstack11111ll_opy_ (u"ࠧ࡭ࡩࡵࠤ࿶"),
            **info,
            bstack11111ll_opy_ (u"ࠨࡲࡦ࡯ࡲࡸࡪࡹࠢ࿷"): bstack1l1l111lll_opy_
        }
    except Exception as err:
        print(bstack11111ll_opy_ (u"ࠢࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰࡰࡲࡸࡰࡦࡺࡩ࡯ࡩࠣࡋ࡮ࡺࠠ࡮ࡧࡷࡥࡩࡧࡴࡢࠢࡺ࡭ࡹ࡮ࠠࡦࡴࡵࡳࡷࡀࠠࡼࡿࠥ࿸").format(err))
        return {}
def bstack1l1ll11ll1_opy_():
    env = os.environ
    if (bstack11111ll_opy_ (u"ࠣࡌࡈࡒࡐࡏࡎࡔࡡࡘࡖࡑࠨ࿹") in env and len(env[bstack11111ll_opy_ (u"ࠤࡍࡉࡓࡑࡉࡏࡕࡢ࡙ࡗࡒࠢ࿺")]) > 0) or (
            bstack11111ll_opy_ (u"ࠥࡎࡊࡔࡋࡊࡐࡖࡣࡍࡕࡍࡆࠤ࿻") in env and len(env[bstack11111ll_opy_ (u"ࠦࡏࡋࡎࡌࡋࡑࡗࡤࡎࡏࡎࡇࠥ࿼")]) > 0):
        return {
            bstack11111ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥ࿽"): bstack11111ll_opy_ (u"ࠨࡊࡦࡰ࡮࡭ࡳࡹࠢ࿾"),
            bstack11111ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥ࿿"): env.get(bstack11111ll_opy_ (u"ࠣࡄࡘࡍࡑࡊ࡟ࡖࡔࡏࠦက")),
            bstack11111ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦခ"): env.get(bstack11111ll_opy_ (u"ࠥࡎࡔࡈ࡟ࡏࡃࡐࡉࠧဂ")),
            bstack11111ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥဃ"): env.get(bstack11111ll_opy_ (u"ࠧࡈࡕࡊࡎࡇࡣࡓ࡛ࡍࡃࡇࡕࠦင"))
        }
    if env.get(bstack11111ll_opy_ (u"ࠨࡃࡊࠤစ")) == bstack11111ll_opy_ (u"ࠢࡵࡴࡸࡩࠧဆ") and env.get(bstack11111ll_opy_ (u"ࠣࡅࡌࡖࡈࡒࡅࡄࡋࠥဇ")) == bstack11111ll_opy_ (u"ࠤࡷࡶࡺ࡫ࠢဈ"):
        return {
            bstack11111ll_opy_ (u"ࠥࡲࡦࡳࡥࠣဉ"): bstack11111ll_opy_ (u"ࠦࡈ࡯ࡲࡤ࡮ࡨࡇࡎࠨည"),
            bstack11111ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣဋ"): env.get(bstack11111ll_opy_ (u"ࠨࡃࡊࡔࡆࡐࡊࡥࡂࡖࡋࡏࡈࡤ࡛ࡒࡍࠤဌ")),
            bstack11111ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤဍ"): env.get(bstack11111ll_opy_ (u"ࠣࡅࡌࡖࡈࡒࡅࡠࡌࡒࡆࠧဎ")),
            bstack11111ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡰࡸࡱࡧ࡫ࡲࠣဏ"): env.get(bstack11111ll_opy_ (u"ࠥࡇࡎࡘࡃࡍࡇࡢࡆ࡚ࡏࡌࡅࡡࡑ࡙ࡒࠨတ"))
        }
    if env.get(bstack11111ll_opy_ (u"ࠦࡈࡏࠢထ")) == bstack11111ll_opy_ (u"ࠧࡺࡲࡶࡧࠥဒ") and env.get(bstack11111ll_opy_ (u"ࠨࡔࡓࡃ࡙ࡍࡘࠨဓ")) == bstack11111ll_opy_ (u"ࠢࡵࡴࡸࡩࠧန"):
        return {
            bstack11111ll_opy_ (u"ࠣࡰࡤࡱࡪࠨပ"): bstack11111ll_opy_ (u"ࠤࡗࡶࡦࡼࡩࡴࠢࡆࡍࠧဖ"),
            bstack11111ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡸࡶࡱࠨဗ"): env.get(bstack11111ll_opy_ (u"࡙ࠦࡘࡁࡗࡋࡖࡣࡇ࡛ࡉࡍࡆࡢ࡛ࡊࡈ࡟ࡖࡔࡏࠦဘ")),
            bstack11111ll_opy_ (u"ࠧࡰ࡯ࡣࡡࡱࡥࡲ࡫ࠢမ"): env.get(bstack11111ll_opy_ (u"ࠨࡔࡓࡃ࡙ࡍࡘࡥࡊࡐࡄࡢࡒࡆࡓࡅࠣယ")),
            bstack11111ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥ࡮ࡶ࡯ࡥࡩࡷࠨရ"): env.get(bstack11111ll_opy_ (u"ࠣࡖࡕࡅ࡛ࡏࡓࡠࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࠢလ"))
        }
    if env.get(bstack11111ll_opy_ (u"ࠤࡆࡍࠧဝ")) == bstack11111ll_opy_ (u"ࠥࡸࡷࡻࡥࠣသ") and env.get(bstack11111ll_opy_ (u"ࠦࡈࡏ࡟ࡏࡃࡐࡉࠧဟ")) == bstack11111ll_opy_ (u"ࠧࡩ࡯ࡥࡧࡶ࡬࡮ࡶࠢဠ"):
        return {
            bstack11111ll_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦအ"): bstack11111ll_opy_ (u"ࠢࡄࡱࡧࡩࡸ࡮ࡩࡱࠤဢ"),
            bstack11111ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦဣ"): None,
            bstack11111ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦဤ"): None,
            bstack11111ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤဥ"): None
        }
    if env.get(bstack11111ll_opy_ (u"ࠦࡇࡏࡔࡃࡗࡆࡏࡊ࡚࡟ࡃࡔࡄࡒࡈࡎࠢဦ")) and env.get(bstack11111ll_opy_ (u"ࠧࡈࡉࡕࡄࡘࡇࡐࡋࡔࡠࡅࡒࡑࡒࡏࡔࠣဧ")):
        return {
            bstack11111ll_opy_ (u"ࠨ࡮ࡢ࡯ࡨࠦဨ"): bstack11111ll_opy_ (u"ࠢࡃ࡫ࡷࡦࡺࡩ࡫ࡦࡶࠥဩ"),
            bstack11111ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟ࡶࡴ࡯ࠦဪ"): env.get(bstack11111ll_opy_ (u"ࠤࡅࡍ࡙ࡈࡕࡄࡍࡈࡘࡤࡍࡉࡕࡡࡋࡘ࡙ࡖ࡟ࡐࡔࡌࡋࡎࡔࠢါ")),
            bstack11111ll_opy_ (u"ࠥ࡮ࡴࡨ࡟࡯ࡣࡰࡩࠧာ"): None,
            bstack11111ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥိ"): env.get(bstack11111ll_opy_ (u"ࠧࡈࡉࡕࡄࡘࡇࡐࡋࡔࡠࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘࠢီ"))
        }
    if env.get(bstack11111ll_opy_ (u"ࠨࡃࡊࠤု")) == bstack11111ll_opy_ (u"ࠢࡵࡴࡸࡩࠧူ") and env.get(bstack11111ll_opy_ (u"ࠣࡆࡕࡓࡓࡋࠢေ")) == bstack11111ll_opy_ (u"ࠤࡷࡶࡺ࡫ࠢဲ"):
        return {
            bstack11111ll_opy_ (u"ࠥࡲࡦࡳࡥࠣဳ"): bstack11111ll_opy_ (u"ࠦࡉࡸ࡯࡯ࡧࠥဴ"),
            bstack11111ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣဵ"): env.get(bstack11111ll_opy_ (u"ࠨࡄࡓࡑࡑࡉࡤࡈࡕࡊࡎࡇࡣࡑࡏࡎࡌࠤံ")),
            bstack11111ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤ့"): None,
            bstack11111ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢး"): env.get(bstack11111ll_opy_ (u"ࠤࡇࡖࡔࡔࡅࡠࡄࡘࡍࡑࡊ࡟ࡏࡗࡐࡆࡊࡘ္ࠢ"))
        }
    if env.get(bstack11111ll_opy_ (u"ࠥࡇࡎࠨ်")) == bstack11111ll_opy_ (u"ࠦࡹࡸࡵࡦࠤျ") and env.get(bstack11111ll_opy_ (u"࡙ࠧࡅࡎࡃࡓࡌࡔࡘࡅࠣြ")) == bstack11111ll_opy_ (u"ࠨࡴࡳࡷࡨࠦွ"):
        return {
            bstack11111ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧှ"): bstack11111ll_opy_ (u"ࠣࡕࡨࡱࡦࡶࡨࡰࡴࡨࠦဿ"),
            bstack11111ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧ၀"): env.get(bstack11111ll_opy_ (u"ࠥࡗࡊࡓࡁࡑࡊࡒࡖࡊࡥࡏࡓࡉࡄࡒࡎࡠࡁࡕࡋࡒࡒࡤ࡛ࡒࡍࠤ၁")),
            bstack11111ll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨ၂"): env.get(bstack11111ll_opy_ (u"࡙ࠧࡅࡎࡃࡓࡌࡔࡘࡅࡠࡌࡒࡆࡤࡔࡁࡎࡇࠥ၃")),
            bstack11111ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧ၄"): env.get(bstack11111ll_opy_ (u"ࠢࡔࡇࡐࡅࡕࡎࡏࡓࡇࡢࡎࡔࡈ࡟ࡊࡆࠥ၅"))
        }
    if env.get(bstack11111ll_opy_ (u"ࠣࡅࡌࠦ၆")) == bstack11111ll_opy_ (u"ࠤࡷࡶࡺ࡫ࠢ၇") and env.get(bstack11111ll_opy_ (u"ࠥࡋࡎ࡚ࡌࡂࡄࡢࡇࡎࠨ၈")) == bstack11111ll_opy_ (u"ࠦࡹࡸࡵࡦࠤ၉"):
        return {
            bstack11111ll_opy_ (u"ࠧࡴࡡ࡮ࡧࠥ၊"): bstack11111ll_opy_ (u"ࠨࡇࡪࡶࡏࡥࡧࠨ။"),
            bstack11111ll_opy_ (u"ࠢࡣࡷ࡬ࡰࡩࡥࡵࡳ࡮ࠥ၌"): env.get(bstack11111ll_opy_ (u"ࠣࡅࡌࡣࡏࡕࡂࡠࡗࡕࡐࠧ၍")),
            bstack11111ll_opy_ (u"ࠤ࡭ࡳࡧࡥ࡮ࡢ࡯ࡨࠦ၎"): env.get(bstack11111ll_opy_ (u"ࠥࡇࡎࡥࡊࡐࡄࡢࡒࡆࡓࡅࠣ၏")),
            bstack11111ll_opy_ (u"ࠦࡧࡻࡩ࡭ࡦࡢࡲࡺࡳࡢࡦࡴࠥၐ"): env.get(bstack11111ll_opy_ (u"ࠧࡉࡉࡠࡌࡒࡆࡤࡏࡄࠣၑ"))
        }
    if env.get(bstack11111ll_opy_ (u"ࠨࡃࡊࠤၒ")) == bstack11111ll_opy_ (u"ࠢࡵࡴࡸࡩࠧၓ") and env.get(bstack11111ll_opy_ (u"ࠣࡄࡘࡍࡑࡊࡋࡊࡖࡈࠦၔ")) == bstack11111ll_opy_ (u"ࠤࡷࡶࡺ࡫ࠢၕ"):
        return {
            bstack11111ll_opy_ (u"ࠥࡲࡦࡳࡥࠣၖ"): bstack11111ll_opy_ (u"ࠦࡇࡻࡩ࡭ࡦ࡮࡭ࡹ࡫ࠢၗ"),
            bstack11111ll_opy_ (u"ࠧࡨࡵࡪ࡮ࡧࡣࡺࡸ࡬ࠣၘ"): env.get(bstack11111ll_opy_ (u"ࠨࡂࡖࡋࡏࡈࡐࡏࡔࡆࡡࡅ࡙ࡎࡒࡄࡠࡗࡕࡐࠧၙ")),
            bstack11111ll_opy_ (u"ࠢ࡫ࡱࡥࡣࡳࡧ࡭ࡦࠤၚ"): env.get(bstack11111ll_opy_ (u"ࠣࡄࡘࡍࡑࡊࡋࡊࡖࡈࡣࡑࡇࡂࡆࡎࠥၛ")) or env.get(bstack11111ll_opy_ (u"ࠤࡅ࡙ࡎࡒࡄࡌࡋࡗࡉࡤࡖࡉࡑࡇࡏࡍࡓࡋ࡟ࡏࡃࡐࡉࠧၜ")),
            bstack11111ll_opy_ (u"ࠥࡦࡺ࡯࡬ࡥࡡࡱࡹࡲࡨࡥࡳࠤၝ"): env.get(bstack11111ll_opy_ (u"ࠦࡇ࡛ࡉࡍࡆࡎࡍ࡙ࡋ࡟ࡃࡗࡌࡐࡉࡥࡎࡖࡏࡅࡉࡗࠨၞ"))
        }
    if env.get(bstack11111ll_opy_ (u"࡚ࠧࡆࡠࡄࡘࡍࡑࡊࠢၟ")) == bstack11111ll_opy_ (u"ࠨࡔࡳࡷࡨࠦၠ"):
        return {
            bstack11111ll_opy_ (u"ࠢ࡯ࡣࡰࡩࠧၡ"): bstack11111ll_opy_ (u"ࠣࡘ࡬ࡷࡺࡧ࡬ࠡࡕࡷࡹࡩ࡯࡯ࠡࡖࡨࡥࡲࠦࡓࡦࡴࡹ࡭ࡨ࡫ࡳࠣၢ"),
            bstack11111ll_opy_ (u"ࠤࡥࡹ࡮ࡲࡤࡠࡷࡵࡰࠧၣ"): bstack1l1l1llll1_opy_ (u"ࠥࡿࡪࡴࡶ࠯ࡩࡨࡸ࠭࠭ࡓ࡚ࡕࡗࡉࡒࡥࡔࡆࡃࡐࡊࡔ࡛ࡎࡅࡃࡗࡍࡔࡔࡓࡆࡔ࡙ࡉࡗ࡛ࡒࡊࠩࠬࢁࢀ࡫࡮ࡷ࠰ࡪࡩࡹ࠮ࠧࡔ࡛ࡖࡘࡊࡓ࡟ࡕࡇࡄࡑࡕࡘࡏࡋࡇࡆࡘࡎࡊࠧࠪࡿࠥၤ"),
            bstack11111ll_opy_ (u"ࠦ࡯ࡵࡢࡠࡰࡤࡱࡪࠨၥ"): env.get(bstack11111ll_opy_ (u"࡙࡙ࠧࡔࡖࡈࡑࡤࡊࡅࡇࡋࡑࡍ࡙ࡏࡏࡏࡋࡇࠦၦ")),
            bstack11111ll_opy_ (u"ࠨࡢࡶ࡫࡯ࡨࡤࡴࡵ࡮ࡤࡨࡶࠧၧ"): env.get(bstack11111ll_opy_ (u"ࠢࡃࡗࡌࡐࡉࡥࡂࡖࡋࡏࡈࡎࡊࠢၨ"))
        }
    return {bstack11111ll_opy_ (u"ࠣࡤࡸ࡭ࡱࡪ࡟࡯ࡷࡰࡦࡪࡸࠢၩ"): None}
def get_host_info():
    uname = os.uname()
    return {
        bstack11111ll_opy_ (u"ࠤ࡫ࡳࡸࡺ࡮ࡢ࡯ࡨࠦၪ"): uname.nodename,
        bstack11111ll_opy_ (u"ࠥࡴࡱࡧࡴࡧࡱࡵࡱࠧၫ"): uname.sysname,
        bstack11111ll_opy_ (u"ࠦࡹࡿࡰࡦࠤၬ"): uname.machine,
        bstack11111ll_opy_ (u"ࠧࡼࡥࡳࡵ࡬ࡳࡳࠨၭ"): uname.version,
        bstack11111ll_opy_ (u"ࠨࡡࡳࡥ࡫ࠦၮ"): uname.machine
    }
def bstack1l1l11111l_opy_():
    try:
        import selenium
        return True
    except ImportError:
        return False
def bstack1l1lllll1l_opy_():
    if bstack1llllll1l1_opy_.get_property(bstack11111ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨၯ")):
        return bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱࠧၰ")
    return bstack11111ll_opy_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࡢ࡫ࡷ࡯ࡤࠨၱ")
def bstack1l1ll11l11_opy_(driver):
    info = {
        bstack11111ll_opy_ (u"ࠪࡧࡦࡶࡡࡣ࡫࡯࡭ࡹ࡯ࡥࡴࠩၲ"): driver.capabilities,
        bstack11111ll_opy_ (u"ࠫࡸ࡫ࡳࡴ࡫ࡲࡲࡤ࡯ࡤࠨၳ"): driver.session_id,
        bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷ࠭ၴ"): driver.capabilities[bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡎࡢ࡯ࡨࠫၵ")],
        bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡠࡸࡨࡶࡸ࡯࡯࡯ࠩၶ"): driver.capabilities[bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡘࡨࡶࡸ࡯࡯࡯ࠩၷ")],
        bstack11111ll_opy_ (u"ࠩࡳࡰࡦࡺࡦࡰࡴࡰࠫၸ"): driver.capabilities[bstack11111ll_opy_ (u"ࠪࡴࡱࡧࡴࡧࡱࡵࡱࡓࡧ࡭ࡦࠩၹ")],
    }
    if bstack1l1lllll1l_opy_() == bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࠪၺ"):
        info[bstack11111ll_opy_ (u"ࠬࡶࡲࡰࡦࡸࡧࡹ࠭ၻ")] = bstack11111ll_opy_ (u"࠭ࡡࡱࡲ࠰ࡥࡺࡺ࡯࡮ࡣࡷࡩࠬၼ") if bstack1llllll1l1_opy_.get_property(bstack11111ll_opy_ (u"ࠧࡢࡲࡳࡣࡦࡻࡴࡰ࡯ࡤࡸࡪ࠭ၽ")) else bstack11111ll_opy_ (u"ࠨࡣࡸࡸࡴࡳࡡࡵࡧࠪၾ")
    return info
def bstack11ll1lll_opy_(bstack1l1l11ll11_opy_, url, data, config):
    headers = config[bstack11111ll_opy_ (u"ࠩ࡫ࡩࡦࡪࡥࡳࡵࠪၿ")]
    proxies = bstack1l11l1ll1_opy_(config, url)
    auth = config.get(bstack11111ll_opy_ (u"ࠪࡥࡺࡺࡨࠨႀ"), None)
    response = requests.request(
        bstack1l1l11ll11_opy_,
        url=url,
        headers=headers,
        auth=auth,
        json=data,
        proxies=proxies
    )
    return response
def bstack1lll1l1l_opy_(bstack11ll1ll11_opy_, size):
    bstack1ll1lll11l_opy_ = []
    while len(bstack11ll1ll11_opy_) > size:
        bstack1l11111l1_opy_ = bstack11ll1ll11_opy_[:size]
        bstack1ll1lll11l_opy_.append(bstack1l11111l1_opy_)
        bstack11ll1ll11_opy_ = bstack11ll1ll11_opy_[size:]
    bstack1ll1lll11l_opy_.append(bstack11ll1ll11_opy_)
    return bstack1ll1lll11l_opy_
def bstack1l1llll11l_opy_(message):
    os.write(1, bytes(message, bstack11111ll_opy_ (u"ࠫࡺࡺࡦ࠮࠺ࠪႁ")))
    os.write(1, bytes(bstack11111ll_opy_ (u"ࠬࡢ࡮ࠨႂ"), bstack11111ll_opy_ (u"࠭ࡵࡵࡨ࠰࠼ࠬႃ")))
def bstack1l1l1111l1_opy_():
    return os.environ[bstack11111ll_opy_ (u"ࠧࡃࡔࡒ࡛ࡘࡋࡒࡔࡖࡄࡇࡐࡥࡁࡖࡖࡒࡑࡆ࡚ࡉࡐࡐࠪႄ")].lower() == bstack11111ll_opy_ (u"ࠨࡶࡵࡹࡪ࠭ႅ")
def bstack1lll1l1ll1_opy_(bstack1l1llll1l1_opy_):
    return bstack1l1l1llll1_opy_ (u"ࠩࡾࡆࡗࡕࡗࡔࡇࡕࡗ࡙ࡇࡃࡌࡡࡄࡔࡎࡥࡕࡓࡎࢀ࠳ࢀ࡫࡮ࡥࡲࡲ࡭ࡳࡺࡽࠨႆ")
def bstack11111l1l_opy_():
    return datetime.datetime.utcnow().isoformat() + bstack11111ll_opy_ (u"ࠪ࡞ࠬႇ")
def bstack1l11llllll_opy_(outcome):
    _, exception, _ = outcome.excinfo or (None, None, None)
    if exception:
        return bstack11111ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫႈ")
    else:
        return bstack11111ll_opy_ (u"ࠬࡶࡡࡴࡵࡨࡨࠬႉ")
def bstack1ll11111l1_opy_(val):
    return val.__str__().lower() == bstack11111ll_opy_ (u"࠭ࡴࡳࡷࡨࠫႊ")
def bstack1l1l11l11l_opy_(val):
    return val.__str__().lower() == bstack11111ll_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ႋ")
def bstack1l1lll11ll_opy_(bstack1l1l11l1ll_opy_=Exception, bstack1l1ll1l1ll_opy_=False, default_value=None):
    def decorator(func):
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except bstack1l1l11l1ll_opy_ as e:
                print(bstack11111ll_opy_ (u"ࠣࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡾࢁࠥ࠳࠾ࠡࡽࢀ࠾ࠥࢁࡽࠣႌ").format(func.__name__, bstack1l1l11l1ll_opy_.__name__, str(e)))
                return default_value
        return wrapper
    def bstack1l11llll1l_opy_(bstack1l1l11l111_opy_):
        def wrapped(cls, *args, **kwargs):
            try:
                return bstack1l1l11l111_opy_(cls, *args, **kwargs)
            except bstack1l1l11l1ll_opy_ as e:
                print(bstack11111ll_opy_ (u"ࠤࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡨࡸࡲࡨࡺࡩࡰࡰࠣࡿࢂࠦ࠭࠿ࠢࡾࢁ࠿ࠦࡻࡾࠤႍ").format(bstack1l1l11l111_opy_.__name__, bstack1l1l11l1ll_opy_.__name__, str(e)))
                return default_value
        return wrapped
    if bstack1l1ll1l1ll_opy_:
        return bstack1l11llll1l_opy_
    else:
        return decorator
def bstack111ll1l11_opy_(bstack1ll1ll1l_opy_):
    if bstack11111ll_opy_ (u"ࠪࡥࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧႎ") in bstack1ll1ll1l_opy_ and bstack1l1l11l11l_opy_(bstack1ll1ll1l_opy_[bstack11111ll_opy_ (u"ࠫࡦࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨႏ")]):
        return False
    if bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡴࡴࠧ႐") in bstack1ll1ll1l_opy_ and bstack1l1l11l11l_opy_(bstack1ll1ll1l_opy_[bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡆࡻࡴࡰ࡯ࡤࡸ࡮ࡵ࡮ࠨ႑")]):
        return False
    return True