# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack1l1l1l1_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11111ll_opy_ (bstack11111l1_opy_):
    global bstack1lll11_opy_
    bstack1l1ll_opy_ = ord (bstack11111l1_opy_ [-1])
    bstack1ll1l1_opy_ = bstack11111l1_opy_ [:-1]
    bstack1lll11l_opy_ = bstack1l1ll_opy_ % len (bstack1ll1l1_opy_)
    bstack1lllll1_opy_ = bstack1ll1l1_opy_ [:bstack1lll11l_opy_] + bstack1ll1l1_opy_ [bstack1lll11l_opy_:]
    if bstack1l1llll_opy_:
        bstack1l111_opy_ = unicode () .join ([unichr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1l111_opy_ = str () .join ([chr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1l111_opy_)
conf = {
    bstack11111ll_opy_ (u"࠭ࡡࡱࡲࡢࡥࡺࡺ࡯࡮ࡣࡷࡩࠬೄ"): False,
    bstack11111ll_opy_ (u"ࠧࡣࡵࡷࡥࡨࡱ࡟ࡴࡧࡶࡷ࡮ࡵ࡮ࠨ೅"): True,
}
class Config(object):
    instance = None
    def __init__(self):
        self._1ll11lll11_opy_ = conf
    @classmethod
    def get_instance(cls):
        if cls.instance:
            return cls.instance
        return Config()
    def get_property(self, property_name):
        return self._1ll11lll11_opy_.get(property_name, None)
    def set_property(self, property_name, bstack1ll11ll1ll_opy_):
        self._1ll11lll11_opy_[property_name] = bstack1ll11ll1ll_opy_