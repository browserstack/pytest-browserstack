# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack1l1l1l1_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11111ll_opy_ (bstack11111l1_opy_):
    global bstack1lll11_opy_
    bstack1l1ll_opy_ = ord (bstack11111l1_opy_ [-1])
    bstack1ll1l1_opy_ = bstack11111l1_opy_ [:-1]
    bstack1lll11l_opy_ = bstack1l1ll_opy_ % len (bstack1ll1l1_opy_)
    bstack1lllll1_opy_ = bstack1ll1l1_opy_ [:bstack1lll11l_opy_] + bstack1ll1l1_opy_ [bstack1lll11l_opy_:]
    if bstack1l1llll_opy_:
        bstack1l111_opy_ = unicode () .join ([unichr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1l111_opy_ = str () .join ([chr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1l111_opy_)
import datetime
import json
import logging
import os
import threading
from bstack_utils.helper import bstack1l1ll1l1l1_opy_, bstack1l1ll11ll1_opy_, get_host_info, bstack1l1ll1l11l_opy_, bstack1l1l1lllll_opy_, bstack1l1ll11lll_opy_, \
    bstack1l1ll11l11_opy_, bstack1l1lllll1l_opy_, bstack11ll1lll_opy_, bstack1l1llll11l_opy_, bstack1ll11111l1_opy_, bstack1l1lll11ll_opy_
from bstack_utils.bstack1l1ll111ll_opy_ import bstack1l1ll111l1_opy_
bstack1l1ll1ll11_opy_ = [
    bstack11111ll_opy_ (u"ࠧࡍࡱࡪࡇࡷ࡫ࡡࡵࡧࡧ༘ࠫ"), bstack11111ll_opy_ (u"ࠨࡅࡅࡘࡘ࡫ࡳࡴ࡫ࡲࡲࡈࡸࡥࡢࡶࡨࡨ༙ࠬ"), bstack11111ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫ༚"), bstack11111ll_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡗࡰ࡯ࡰࡱࡧࡧࠫ༛"),
    bstack11111ll_opy_ (u"ࠫࡍࡵ࡯࡬ࡔࡸࡲࡋ࡯࡮ࡪࡵ࡫ࡩࡩ࠭༜"), bstack11111ll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳ࡙ࡴࡢࡴࡷࡩࡩ࠭༝"), bstack11111ll_opy_ (u"࠭ࡈࡰࡱ࡮ࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧ༞")
]
bstack1l1ll1llll_opy_ = bstack11111ll_opy_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡥࡲࡰࡱ࡫ࡣࡵࡱࡵ࠱ࡴࡨࡳࡦࡴࡹࡥࡧ࡯࡬ࡪࡶࡼ࠲ࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭࠱ࡧࡴࡳࠧ༟")
logger = logging.getLogger(__name__)
class bstack1lll11l1l1_opy_:
    bstack1l1ll111ll_opy_ = None
    bs_config = None
    @classmethod
    @bstack1l1lll11ll_opy_(bstack1l1ll1l1ll_opy_=True)
    def launch(cls, bs_config, bstack1l1l1lll1l_opy_):
        cls.bs_config = bs_config
        if not cls.bstack1l1lll11l1_opy_():
            return
        cls.bstack1l1ll111ll_opy_ = bstack1l1ll111l1_opy_(cls.bstack1l1lll111l_opy_)
        cls.bstack1l1ll111ll_opy_.start()
        bstack1l1lllllll_opy_ = bstack1l1ll1l11l_opy_(bs_config)
        bstack1l1lll1ll1_opy_ = bstack1l1l1lllll_opy_(bs_config)
        data = {
            bstack11111ll_opy_ (u"ࠨࡨࡲࡶࡲࡧࡴࠨ༠"): bstack11111ll_opy_ (u"ࠩ࡭ࡷࡴࡴࠧ༡"),
            bstack11111ll_opy_ (u"ࠪࡴࡷࡵࡪࡦࡥࡷࡣࡳࡧ࡭ࡦࠩ༢"): bs_config.get(bstack11111ll_opy_ (u"ࠫࡵࡸ࡯࡫ࡧࡦࡸࡓࡧ࡭ࡦࠩ༣"), bstack11111ll_opy_ (u"ࠬ࠭༤")),
            bstack11111ll_opy_ (u"࠭࡮ࡢ࡯ࡨࠫ༥"): bs_config.get(bstack11111ll_opy_ (u"ࠧࡣࡷ࡬ࡰࡩࡔࡡ࡮ࡧࠪ༦"), os.path.basename(os.path.abspath(os.getcwd()))),
            bstack11111ll_opy_ (u"ࠨࡤࡸ࡭ࡱࡪ࡟ࡪࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ༧"): bs_config.get(bstack11111ll_opy_ (u"ࠩࡥࡹ࡮ࡲࡤࡊࡦࡨࡲࡹ࡯ࡦࡪࡧࡵࠫ༨")),
            bstack11111ll_opy_ (u"ࠪࡨࡪࡹࡣࡳ࡫ࡳࡸ࡮ࡵ࡮ࠨ༩"): bs_config.get(bstack11111ll_opy_ (u"ࠫࡧࡻࡩ࡭ࡦࡇࡩࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠧ༪"), bstack11111ll_opy_ (u"ࠬ࠭༫")),
            bstack11111ll_opy_ (u"࠭ࡳࡵࡣࡵࡸࡤࡺࡩ࡮ࡧࠪ༬"): datetime.datetime.now().isoformat(),
            bstack11111ll_opy_ (u"ࠧࡵࡣࡪࡷࠬ༭"): bstack1l1ll11lll_opy_(bs_config),
            bstack11111ll_opy_ (u"ࠨࡪࡲࡷࡹࡥࡩ࡯ࡨࡲࠫ༮"): get_host_info(),
            bstack11111ll_opy_ (u"ࠩࡦ࡭ࡤ࡯࡮ࡧࡱࠪ༯"): bstack1l1ll11ll1_opy_(),
            bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡࡵࡹࡳࡥࡩࡥࡧࡱࡸ࡮࡬ࡩࡦࡴࠪ༰"): os.environ.get(bstack11111ll_opy_ (u"ࠫࡇࡘࡏࡘࡕࡈࡖࡘ࡚ࡁࡄࡍࡢࡆ࡚ࡏࡌࡅࡡࡕ࡙ࡓࡥࡉࡅࡇࡑࡘࡎࡌࡉࡆࡔࠪ༱")),
            bstack11111ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࡤࡺࡥࡴࡶࡶࡣࡷ࡫ࡲࡶࡰࠪ༲"): os.environ.get(bstack11111ll_opy_ (u"࠭ࡂࡓࡑ࡚ࡗࡊࡘࡓࡕࡃࡆࡏࡤࡘࡅࡓࡗࡑࠫ༳"), False),
            bstack11111ll_opy_ (u"ࠧࡷࡧࡵࡷ࡮ࡵ࡮ࡠࡥࡲࡲࡹࡸ࡯࡭ࠩ༴"): bstack1l1ll1l1l1_opy_(),
            bstack11111ll_opy_ (u"ࠨࡱࡥࡷࡪࡸࡶࡢࡤ࡬ࡰ࡮ࡺࡹࡠࡸࡨࡶࡸ࡯࡯࡯༵ࠩ"): {
                bstack11111ll_opy_ (u"ࠩࡩࡶࡦࡳࡥࡸࡱࡵ࡯ࡓࡧ࡭ࡦࠩ༶"): bstack1l1l1lll1l_opy_.get(bstack11111ll_opy_ (u"ࠪࡪࡷࡧ࡭ࡦࡹࡲࡶࡰࡥ࡮ࡢ࡯ࡨ༷ࠫ"), bstack11111ll_opy_ (u"ࠫࡕࡿࡴࡦࡵࡷࠫ༸")),
                bstack11111ll_opy_ (u"ࠬ࡬ࡲࡢ࡯ࡨࡻࡴࡸ࡫ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ༹"): bstack1l1l1lll1l_opy_.get(bstack11111ll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࡡࡹࡩࡷࡹࡩࡰࡰࠪ༺")),
                bstack11111ll_opy_ (u"ࠧࡴࡦ࡮࡚ࡪࡸࡳࡪࡱࡱࠫ༻"): bstack1l1l1lll1l_opy_.get(bstack11111ll_opy_ (u"ࠨࡵࡧ࡯ࡤࡼࡥࡳࡵ࡬ࡳࡳ࠭༼"))
            }
        }
        config = {
            bstack11111ll_opy_ (u"ࠩࡤࡹࡹ࡮ࠧ༽"): (bstack1l1lllllll_opy_, bstack1l1lll1ll1_opy_),
            bstack11111ll_opy_ (u"ࠪ࡬ࡪࡧࡤࡦࡴࡶࠫ༾"): cls.default_headers()
        }
        response = bstack11ll1lll_opy_(bstack11111ll_opy_ (u"ࠫࡕࡕࡓࡕࠩ༿"), cls.request_url(bstack11111ll_opy_ (u"ࠬࡧࡰࡪ࠱ࡹ࠵࠴ࡨࡵࡪ࡮ࡧࡷࠬཀ")), data, config)
        if response.status_code != 200:
            os.environ[bstack11111ll_opy_ (u"࠭ࡂࡔࡡࡗࡉࡘ࡚ࡏࡑࡕࡢࡆ࡚ࡏࡌࡅࡡࡆࡓࡒࡖࡌࡆࡖࡈࡈࠬཁ")] = bstack11111ll_opy_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ག")
            os.environ[bstack11111ll_opy_ (u"ࠨࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡐࡗࡕࠩགྷ")] = bstack11111ll_opy_ (u"ࠩࡱࡹࡱࡲࠧང")
            os.environ[bstack11111ll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡈࡂࡕࡋࡉࡉࡥࡉࡅࠩཅ")] = bstack11111ll_opy_ (u"ࠦࡳࡻ࡬࡭ࠤཆ")
            os.environ[bstack11111ll_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡄࡐࡑࡕࡗࡠࡕࡆࡖࡊࡋࡎࡔࡊࡒࡘࡘ࠭ཇ")] = bstack11111ll_opy_ (u"ࠨ࡮ࡶ࡮࡯ࠦ཈")
            bstack1ll1111l1l_opy_ = response.json()
            if bstack1ll1111l1l_opy_ and bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨཉ")]:
                error_message = bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩཊ")]
                if bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠩࡨࡶࡷࡵࡲࡕࡻࡳࡩࠬཋ")] == bstack11111ll_opy_ (u"ࠪࡉࡗࡘࡏࡓࡡࡌࡒ࡛ࡇࡌࡊࡆࡢࡇࡗࡋࡄࡆࡐࡗࡍࡆࡒࡓࠨཌ"):
                    logger.error(error_message)
                elif bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࡗࡽࡵ࡫ࠧཌྷ")] == bstack11111ll_opy_ (u"ࠬࡋࡒࡓࡑࡕࡣࡆࡉࡃࡆࡕࡖࡣࡉࡋࡎࡊࡇࡇࠫཎ"):
                    logger.info(error_message)
                elif bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"࠭ࡥࡳࡴࡲࡶ࡙ࡿࡰࡦࠩཏ")] == bstack11111ll_opy_ (u"ࠧࡆࡔࡕࡓࡗࡥࡓࡅࡍࡢࡈࡊࡖࡒࡆࡅࡄࡘࡊࡊࠧཐ"):
                    logger.error(error_message)
                else:
                    logger.error(error_message)
            else:
                logger.error(bstack1l1l1llll1_opy_ (u"ࠣࡆࡤࡸࡦࠦࡵࡱ࡮ࡲࡥࡩࠦࡴࡰࠢࡅࡶࡴࡽࡳࡦࡴࡖࡸࡦࡩ࡫ࠡࡖࡨࡷࡹࠦࡏࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾࠦࡦࡢ࡫࡯ࡩࡩࠦࡤࡶࡧࠣࡸࡴࠦࡳࡰ࡯ࡨࠤࡪࡸࡲࡰࡴࠥད"))
            return [None, None, None]
        os.environ[bstack11111ll_opy_ (u"ࠩࡅࡗࡤ࡚ࡅࡔࡖࡒࡔࡘࡥࡂࡖࡋࡏࡈࡤࡉࡏࡎࡒࡏࡉ࡙ࡋࡄࠨདྷ")] = bstack11111ll_opy_ (u"ࠪࡸࡷࡻࡥࠨན")
        bstack1ll1111l1l_opy_ = response.json()
        if bstack1ll1111l1l_opy_.get(bstack11111ll_opy_ (u"ࠫ࡯ࡽࡴࠨཔ")):
            os.environ[bstack11111ll_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡍ࡛࡙࠭ཕ")] = bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"࠭ࡪࡸࡶࠪབ")]
            os.environ[bstack11111ll_opy_ (u"ࠧࡄࡔࡈࡈࡊࡔࡔࡊࡃࡏࡗࡤࡌࡏࡓࡡࡆࡖࡆ࡙ࡈࡠࡔࡈࡔࡔࡘࡔࡊࡐࡊࠫབྷ")] = json.dumps({
                bstack11111ll_opy_ (u"ࠨࡷࡶࡩࡷࡴࡡ࡮ࡧࠪམ"): bstack1l1lllllll_opy_,
                bstack11111ll_opy_ (u"ࠩࡳࡥࡸࡹࡷࡰࡴࡧࠫཙ"): bstack1l1lll1ll1_opy_
            })
        if bstack1ll1111l1l_opy_.get(bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠬཚ")):
            os.environ[bstack11111ll_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡄࡘࡍࡑࡊ࡟ࡉࡃࡖࡌࡊࡊ࡟ࡊࡆࠪཛ")] = bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠬࡨࡵࡪ࡮ࡧࡣ࡭ࡧࡳࡩࡧࡧࡣ࡮ࡪࠧཛྷ")]
        if bstack1ll1111l1l_opy_.get(bstack11111ll_opy_ (u"࠭ࡡ࡭࡮ࡲࡻࡤࡹࡣࡳࡧࡨࡲࡸ࡮࡯ࡵࡵࠪཝ")):
            os.environ[bstack11111ll_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡆࡒࡌࡐ࡙ࡢࡗࡈࡘࡅࡆࡐࡖࡌࡔ࡚ࡓࠨཞ")] = str(bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠨࡣ࡯ࡰࡴࡽ࡟ࡴࡥࡵࡩࡪࡴࡳࡩࡱࡷࡷࠬཟ")])
        return [bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠩ࡭ࡻࡹ࠭འ")], bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠪࡦࡺ࡯࡬ࡥࡡ࡫ࡥࡸ࡮ࡥࡥࡡ࡬ࡨࠬཡ")], bstack1ll1111l1l_opy_[bstack11111ll_opy_ (u"ࠫࡦࡲ࡬ࡰࡹࡢࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࡳࠨར")]]
    @classmethod
    @bstack1l1lll11ll_opy_(bstack1l1ll1l1ll_opy_=True)
    def stop(cls):
        if not cls.on():
            return
        if os.environ[bstack11111ll_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡍ࡛࡙࠭ལ")] == bstack11111ll_opy_ (u"ࠨ࡮ࡶ࡮࡯ࠦཤ") or os.environ[bstack11111ll_opy_ (u"ࠧࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡇ࡛ࡉࡍࡆࡢࡌࡆ࡙ࡈࡆࡆࡢࡍࡉ࠭ཥ")] == bstack11111ll_opy_ (u"ࠣࡰࡸࡰࡱࠨས"):
            print(bstack11111ll_opy_ (u"ࠩࡈ࡜ࡈࡋࡐࡕࡋࡒࡒࠥࡏࡎࠡࡵࡷࡳࡵࡈࡵࡪ࡮ࡧ࡙ࡵࡹࡴࡳࡧࡤࡱࠥࡘࡅࡒࡗࡈࡗ࡙ࠦࡔࡐࠢࡗࡉࡘ࡚ࠠࡐࡄࡖࡉࡗ࡜ࡁࡃࡋࡏࡍ࡙࡟ࠠ࠻ࠢࡐ࡭ࡸࡹࡩ࡯ࡩࠣࡥࡺࡺࡨࡦࡰࡷ࡭ࡨࡧࡴࡪࡱࡱࠤࡹࡵ࡫ࡦࡰࠪཧ"))
            return {
                bstack11111ll_opy_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪཨ"): bstack11111ll_opy_ (u"ࠫࡪࡸࡲࡰࡴࠪཀྵ"),
                bstack11111ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ཪ"): bstack11111ll_opy_ (u"࠭ࡔࡰ࡭ࡨࡲ࠴ࡨࡵࡪ࡮ࡧࡍࡉࠦࡩࡴࠢࡸࡲࡩ࡫ࡦࡪࡰࡨࡨ࠱ࠦࡢࡶ࡫࡯ࡨࠥࡩࡲࡦࡣࡷ࡭ࡴࡴࠠ࡮࡫ࡪ࡬ࡹࠦࡨࡢࡸࡨࠤ࡫ࡧࡩ࡭ࡧࡧࠫཫ")
            }
        else:
            cls.bstack1l1ll111ll_opy_.shutdown()
            data = {
                bstack11111ll_opy_ (u"ࠧࡴࡶࡲࡴࡤࡺࡩ࡮ࡧࠪཬ"): datetime.datetime.now().isoformat()
            }
            config = {
                bstack11111ll_opy_ (u"ࠨࡪࡨࡥࡩ࡫ࡲࡴࠩ཭"): cls.default_headers()
            }
            bstack1l1llll1l1_opy_ = bstack11111ll_opy_ (u"ࠩࡤࡴ࡮࠵ࡶ࠲࠱ࡥࡹ࡮ࡲࡤࡴ࠱ࡾࢁ࠴ࡹࡴࡰࡲࠪ཮").format(os.environ[bstack11111ll_opy_ (u"ࠥࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡃࡗࡌࡐࡉࡥࡈࡂࡕࡋࡉࡉࡥࡉࡅࠤ཯")])
            bstack1l1lllll11_opy_ = cls.request_url(bstack1l1llll1l1_opy_)
            response = bstack11ll1lll_opy_(bstack11111ll_opy_ (u"ࠫࡕ࡛ࡔࠨ཰"), bstack1l1lllll11_opy_, data, config)
            if not response.ok:
                raise Exception(bstack11111ll_opy_ (u"࡙ࠧࡴࡰࡲࠣࡶࡪࡷࡵࡦࡵࡷࠤࡳࡵࡴࠡࡱ࡮ཱࠦ"))
    @classmethod
    def bstack1l1111l1l_opy_(cls):
        if cls.on():
            print(
                bstack11111ll_opy_ (u"࠭ࡖࡪࡵ࡬ࡸࠥ࡮ࡴࡵࡲࡶ࠾࠴࠵࡯ࡣࡵࡨࡶࡻࡧࡢࡪ࡮࡬ࡸࡾ࠴ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯࠳ࡩ࡯࡮࠱ࡥࡹ࡮ࡲࡤࡴ࠱ࡾࢁࠥࡺ࡯ࠡࡸ࡬ࡩࡼࠦࡢࡶ࡫࡯ࡨࠥࡸࡥࡱࡱࡵࡸ࠱ࠦࡩ࡯ࡵ࡬࡫࡭ࡺࡳ࠭ࠢࡤࡲࡩࠦ࡭ࡢࡰࡼࠤࡲࡵࡲࡦࠢࡧࡩࡧࡻࡧࡨ࡫ࡱ࡫ࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰࠣࡥࡱࡲࠠࡢࡶࠣࡳࡳ࡫ࠠࡱ࡮ࡤࡧࡪࠧ࡜࡯ིࠩ").format(os.environ[bstack11111ll_opy_ (u"ࠢࡃࡕࡢࡘࡊ࡙ࡔࡐࡒࡖࡣࡇ࡛ࡉࡍࡆࡢࡌࡆ࡙ࡈࡆࡆࡢࡍࡉࠨཱི")]))
    @classmethod
    def bstack1ll111111l_opy_(cls, bstack1l1llllll1_opy_, bstack1l1ll1ll1l_opy_=bstack11111ll_opy_ (u"ࠨࡣࡳ࡭࠴ࡼ࠱࠰ࡤࡤࡸࡨ࡮ུࠧ")):
        if not cls.on():
            return
        bstack11lll111_opy_ = bstack1l1llllll1_opy_[bstack11111ll_opy_ (u"ࠩࡨࡺࡪࡴࡴࡠࡶࡼࡴࡪཱུ࠭")]
        bstack1ll1111l11_opy_ = {
            bstack11111ll_opy_ (u"ࠪࡘࡪࡹࡴࡓࡷࡱࡗࡹࡧࡲࡵࡧࡧࠫྲྀ"): bstack11111ll_opy_ (u"࡙ࠫ࡫ࡳࡵࡡࡖࡸࡦࡸࡴࡠࡗࡳࡰࡴࡧࡤࠨཷ"),
            bstack11111ll_opy_ (u"࡚ࠬࡥࡴࡶࡕࡹࡳࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠧླྀ"): bstack11111ll_opy_ (u"࠭ࡔࡦࡵࡷࡣࡊࡴࡤࡠࡗࡳࡰࡴࡧࡤࠨཹ"),
            bstack11111ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔ࡭࡬ࡴࡵ࡫ࡤࠨེ"): bstack11111ll_opy_ (u"ࠨࡖࡨࡷࡹࡥࡓ࡬࡫ࡳࡴࡪࡪ࡟ࡖࡲ࡯ࡳࡦࡪཻࠧ"),
            bstack11111ll_opy_ (u"ࠩࡏࡳ࡬ࡉࡲࡦࡣࡷࡩࡩོ࠭"): bstack11111ll_opy_ (u"ࠪࡐࡴ࡭࡟ࡖࡲ࡯ࡳࡦࡪཽࠧ"),
            bstack11111ll_opy_ (u"ࠫࡍࡵ࡯࡬ࡔࡸࡲࡘࡺࡡࡳࡶࡨࡨࠬཾ"): bstack11111ll_opy_ (u"ࠬࡎ࡯ࡰ࡭ࡢࡗࡹࡧࡲࡵࡡࡘࡴࡱࡵࡡࡥࠩཿ"),
            bstack11111ll_opy_ (u"࠭ࡈࡰࡱ࡮ࡖࡺࡴࡆࡪࡰ࡬ࡷ࡭࡫ࡤࠨྀ"): bstack11111ll_opy_ (u"ࠧࡉࡱࡲ࡯ࡤࡋ࡮ࡥࡡࡘࡴࡱࡵࡡࡥཱྀࠩ"),
            bstack11111ll_opy_ (u"ࠨࡅࡅࡘࡘ࡫ࡳࡴ࡫ࡲࡲࡈࡸࡥࡢࡶࡨࡨࠬྂ"): bstack11111ll_opy_ (u"ࠩࡆࡆ࡙ࡥࡕࡱ࡮ࡲࡥࡩ࠭ྃ")
        }.get(bstack11lll111_opy_)
        if bstack1l1ll1ll1l_opy_ == bstack11111ll_opy_ (u"ࠪࡥࡵ࡯࠯ࡷ࠳࠲ࡦࡦࡺࡣࡩ྄ࠩ"):
            cls.bstack1l1ll111ll_opy_.add(bstack1l1llllll1_opy_)
        elif bstack1l1ll1ll1l_opy_ == bstack11111ll_opy_ (u"ࠫࡦࡶࡩ࠰ࡸ࠴࠳ࡸࡩࡲࡦࡧࡱࡷ࡭ࡵࡴࡴࠩ྅"):
            cls.bstack1l1lll111l_opy_([bstack1l1llllll1_opy_], bstack1l1ll1ll1l_opy_)
    @classmethod
    @bstack1l1lll11ll_opy_(bstack1l1ll1l1ll_opy_=True)
    def bstack1l1lll111l_opy_(cls, bstack1l1llllll1_opy_, bstack1l1ll1ll1l_opy_=bstack11111ll_opy_ (u"ࠬࡧࡰࡪ࠱ࡹ࠵࠴ࡨࡡࡵࡥ࡫ࠫ྆")):
        config = {
            bstack11111ll_opy_ (u"࠭ࡨࡦࡣࡧࡩࡷࡹࠧ྇"): cls.default_headers()
        }
        response = bstack11ll1lll_opy_(bstack11111ll_opy_ (u"ࠧࡑࡑࡖࡘࠬྈ"), cls.request_url(bstack1l1ll1ll1l_opy_), bstack1l1llllll1_opy_, config)
        bstack1l1ll1l111_opy_ = response.json()
    @classmethod
    @bstack1l1lll11ll_opy_(bstack1l1ll1l1ll_opy_=True)
    def bstack1l1llll111_opy_(cls, bstack1l1ll11l1l_opy_):
        bstack1l1lll1lll_opy_ = []
        for log in bstack1l1ll11l1l_opy_:
            bstack1l1lll1lll_opy_.append({
                bstack11111ll_opy_ (u"ࠨ࡭࡬ࡲࡩ࠭ྉ"): bstack11111ll_opy_ (u"ࠩࡗࡉࡘ࡚࡟ࡍࡑࡊࠫྊ"),
                bstack11111ll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩྋ"): log[bstack11111ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪྌ")],
                bstack11111ll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨྍ"): log[bstack11111ll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩྎ")],
                bstack11111ll_opy_ (u"ࠧࡩࡶࡷࡴࡤࡸࡥࡴࡲࡲࡲࡸ࡫ࠧྏ"): {},
                bstack11111ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩྐ"): log[bstack11111ll_opy_ (u"ࠩࡰࡩࡸࡹࡡࡨࡧࠪྑ")],
                bstack11111ll_opy_ (u"ࠪࡸࡪࡹࡴࡠࡴࡸࡲࡤࡻࡵࡪࡦࠪྒ"): log[bstack11111ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫྒྷ")]
            })
        cls.bstack1ll111111l_opy_({
            bstack11111ll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩྔ"): bstack11111ll_opy_ (u"࠭ࡌࡰࡩࡆࡶࡪࡧࡴࡦࡦࠪྕ"),
            bstack11111ll_opy_ (u"ࠧ࡭ࡱࡪࡷࠬྖ"): bstack1l1lll1lll_opy_
        })
    @classmethod
    @bstack1l1lll11ll_opy_(bstack1l1ll1l1ll_opy_=True)
    def bstack1ll1111ll1_opy_(cls, steps):
        bstack1l1llll1ll_opy_ = []
        for step in steps:
            bstack1l1ll1lll1_opy_ = {
                bstack11111ll_opy_ (u"ࠨ࡭࡬ࡲࡩ࠭ྗ"): bstack11111ll_opy_ (u"ࠩࡗࡉࡘ࡚࡟ࡔࡖࡈࡔࠬ྘"),
                bstack11111ll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩྙ"): step[bstack11111ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪྚ")],
                bstack11111ll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨྛ"): step[bstack11111ll_opy_ (u"࠭ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩྜ")],
                bstack11111ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨྜྷ"): step[bstack11111ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩྞ")],
                bstack11111ll_opy_ (u"ࠩࡧࡹࡷࡧࡴࡪࡱࡱࠫྟ"): step[bstack11111ll_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬྠ")]
            }
            if bstack11111ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡵࡶ࡫ࡧࠫྡ") in step:
                bstack1l1ll1lll1_opy_[bstack11111ll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬྡྷ")] = step[bstack11111ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ྣ")]
            elif bstack11111ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧྤ") in step:
                bstack1l1ll1lll1_opy_[bstack11111ll_opy_ (u"ࠨࡪࡲࡳࡰࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨྥ")] = step[bstack11111ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩྦ")]
            bstack1l1llll1ll_opy_.append(bstack1l1ll1lll1_opy_)
        cls.bstack1ll111111l_opy_({
            bstack11111ll_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧྦྷ"): bstack11111ll_opy_ (u"ࠫࡑࡵࡧࡄࡴࡨࡥࡹ࡫ࡤࠨྨ"),
            bstack11111ll_opy_ (u"ࠬࡲ࡯ࡨࡵࠪྩ"): bstack1l1llll1ll_opy_
        })
    @classmethod
    @bstack1l1lll11ll_opy_(bstack1l1ll1l1ll_opy_=True)
    def bstack1ll1111lll_opy_(cls, screenshot):
        cls.bstack1ll111111l_opy_({
            bstack11111ll_opy_ (u"࠭ࡥࡷࡧࡱࡸࡤࡺࡹࡱࡧࠪྪ"): bstack11111ll_opy_ (u"ࠧࡍࡱࡪࡇࡷ࡫ࡡࡵࡧࡧࠫྫ"),
            bstack11111ll_opy_ (u"ࠨ࡮ࡲ࡫ࡸ࠭ྫྷ"): [{
                bstack11111ll_opy_ (u"ࠩ࡮࡭ࡳࡪࠧྭ"): bstack11111ll_opy_ (u"ࠪࡘࡊ࡙ࡔࡠࡕࡆࡖࡊࡋࡎࡔࡊࡒࡘࠬྮ"),
                bstack11111ll_opy_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧྯ"): datetime.datetime.utcnow().isoformat() + bstack11111ll_opy_ (u"ࠬࡠࠧྰ"),
                bstack11111ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧྱ"): screenshot[bstack11111ll_opy_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭ྲ")],
                bstack11111ll_opy_ (u"ࠨࡶࡨࡷࡹࡥࡲࡶࡰࡢࡹࡺ࡯ࡤࠨླ"): screenshot[bstack11111ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩྴ")]
            }]
        }, bstack1l1ll1ll1l_opy_=bstack11111ll_opy_ (u"ࠪࡥࡵ࡯࠯ࡷ࠳࠲ࡷࡨࡸࡥࡦࡰࡶ࡬ࡴࡺࡳࠨྵ"))
    @classmethod
    @bstack1l1lll11ll_opy_(bstack1l1ll1l1ll_opy_=True)
    def bstack111l11ll1_opy_(cls, driver):
        bstack1ll11111ll_opy_ = cls.bstack1ll11111ll_opy_()
        if not bstack1ll11111ll_opy_:
            return
        cls.bstack1ll111111l_opy_({
            bstack11111ll_opy_ (u"ࠫࡪࡼࡥ࡯ࡶࡢࡸࡾࡶࡥࠨྶ"): bstack11111ll_opy_ (u"ࠬࡉࡂࡕࡕࡨࡷࡸ࡯࡯࡯ࡅࡵࡩࡦࡺࡥࡥࠩྷ"),
            bstack11111ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࠨྸ"): {
                bstack11111ll_opy_ (u"ࠢࡶࡷ࡬ࡨࠧྐྵ"): cls.bstack1ll11111ll_opy_(),
                bstack11111ll_opy_ (u"ࠣ࡫ࡱࡸࡪ࡭ࡲࡢࡶ࡬ࡳࡳࡹࠢྺ"): cls.bstack1l1lll1111_opy_(driver)
            }
        })
    @classmethod
    def on(cls):
        if not getattr(cls, bstack11111ll_opy_ (u"ࠩࡥࡷࡤࡩ࡯࡯ࡨ࡬࡫ࠬྻ"), None):
            return False
        if not cls.bstack1l1lll11l1_opy_():
            return False
        if os.environ.get(bstack11111ll_opy_ (u"ࠪࡆࡘࡥࡔࡆࡕࡗࡓࡕ࡙࡟ࡋ࡙ࡗࠫྼ"), None) is None or os.environ[bstack11111ll_opy_ (u"ࠫࡇ࡙࡟ࡕࡇࡖࡘࡔࡖࡓࡠࡌ࡚ࡘࠬ྽")] == bstack11111ll_opy_ (u"ࠧࡴࡵ࡭࡮ࠥ྾"):
            return False
        return True
    @classmethod
    def bstack1l1lll11l1_opy_(cls):
        return bstack1ll11111l1_opy_(cls.bs_config.get(bstack11111ll_opy_ (u"࠭ࡴࡦࡵࡷࡓࡧࡹࡥࡳࡸࡤࡦ࡮ࡲࡩࡵࡻࠪ྿"), False))
    @staticmethod
    def request_url(url):
        return bstack11111ll_opy_ (u"ࠧࡼࡿ࠲ࡿࢂ࠭࿀").format(bstack1l1ll1llll_opy_, url)
    @staticmethod
    def default_headers():
        headers = {
            bstack11111ll_opy_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧ࿁"): bstack11111ll_opy_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯࡫ࡵࡲࡲࠬ࿂"),
            bstack11111ll_opy_ (u"ࠪ࡜࠲ࡈࡓࡕࡃࡆࡏ࠲࡚ࡅࡔࡖࡒࡔࡘ࠭࿃"): bstack11111ll_opy_ (u"ࠫࡹࡸࡵࡦࠩ࿄")
        }
        if os.environ.get(bstack11111ll_opy_ (u"ࠬࡈࡓࡠࡖࡈࡗ࡙ࡕࡐࡔࡡࡍ࡛࡙࠭࿅"), None):
            headers[bstack11111ll_opy_ (u"࠭ࡁࡶࡶ࡫ࡳࡷ࡯ࡺࡢࡶ࡬ࡳࡳ࿆࠭")] = bstack11111ll_opy_ (u"ࠧࡃࡧࡤࡶࡪࡸࠠࡼࡿࠪ࿇").format(os.environ[bstack11111ll_opy_ (u"ࠣࡄࡖࡣ࡙ࡋࡓࡕࡑࡓࡗࡤࡐࡗࡕࠤ࿈")])
        return headers
    @staticmethod
    def bstack1ll11111ll_opy_():
        return getattr(threading.current_thread(), bstack11111ll_opy_ (u"ࠩࡦࡹࡷࡸࡥ࡯ࡶࡢࡸࡪࡹࡴࡠࡷࡸ࡭ࡩ࠭࿉"), None)
    @staticmethod
    def bstack1l1lll1111_opy_(driver):
        return {
            bstack1l1lllll1l_opy_(): bstack1l1ll11l11_opy_(driver)
        }
    @staticmethod
    def bstack1l1lll1l1l_opy_(exception_info, report):
        return [{bstack11111ll_opy_ (u"ࠪࡦࡦࡩ࡫ࡵࡴࡤࡧࡪ࠭࿊"): [exception_info.exconly(), report.longreprtext]}]
    @staticmethod
    def bstack1l1lll1l11_opy_(typename):
        if bstack11111ll_opy_ (u"ࠦࡆࡹࡳࡦࡴࡷ࡭ࡴࡴࠢ࿋") in typename:
            return bstack11111ll_opy_ (u"ࠧࡇࡳࡴࡧࡵࡸ࡮ࡵ࡮ࡆࡴࡵࡳࡷࠨ࿌")
        return bstack11111ll_opy_ (u"ࠨࡕ࡯ࡪࡤࡲࡩࡲࡥࡥࡇࡵࡶࡴࡸࠢ࿍")
    @staticmethod
    def bstack1l1ll11111_opy_(func):
        def wrap(*args, **kwargs):
            if bstack1lll11l1l1_opy_.on():
                return func(*args, **kwargs)
            return
        return wrap
    @staticmethod
    def bstack1l1l1lll11_opy_(test):
        bstack1l1ll1111l_opy_ = test.parent
        scope = []
        while bstack1l1ll1111l_opy_ is not None:
            scope.append(bstack1l1ll1111l_opy_.name)
            bstack1l1ll1111l_opy_ = bstack1l1ll1111l_opy_.parent
        scope.reverse()
        return scope[2:]
    @staticmethod
    def bstack1ll1111111_opy_(hook_type):
        if hook_type == bstack11111ll_opy_ (u"ࠢࡃࡇࡉࡓࡗࡋ࡟ࡆࡃࡆࡌࠧ࿎"):
            return bstack11111ll_opy_ (u"ࠣࡕࡨࡸࡺࡶࠠࡩࡱࡲ࡯ࠧ࿏")
        elif hook_type == bstack11111ll_opy_ (u"ࠤࡄࡊ࡙ࡋࡒࡠࡇࡄࡇࡍࠨ࿐"):
            return bstack11111ll_opy_ (u"ࠥࡘࡪࡧࡲࡥࡱࡺࡲࠥ࡮࡯ࡰ࡭ࠥ࿑")