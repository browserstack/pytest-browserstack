# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack1l1l1l1_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11111ll_opy_ (bstack11111l1_opy_):
    global bstack1lll11_opy_
    bstack1l1ll_opy_ = ord (bstack11111l1_opy_ [-1])
    bstack1ll1l1_opy_ = bstack11111l1_opy_ [:-1]
    bstack1lll11l_opy_ = bstack1l1ll_opy_ % len (bstack1ll1l1_opy_)
    bstack1lllll1_opy_ = bstack1ll1l1_opy_ [:bstack1lll11l_opy_] + bstack1ll1l1_opy_ [bstack1lll11l_opy_:]
    if bstack1l1llll_opy_:
        bstack1l111_opy_ = unicode () .join ([unichr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1l111_opy_ = str () .join ([chr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1l111_opy_)
class bstack1ll111l1l1_opy_:
    def __init__(self, handler):
        self._1ll111l111_opy_ = None
        self.handler = handler
        self._1ll111l11l_opy_ = self.bstack1ll111l1ll_opy_()
        self.patch()
    def patch(self):
        self._1ll111l111_opy_ = self._1ll111l11l_opy_.execute
        self._1ll111l11l_opy_.execute = self.bstack1ll111ll1l_opy_()
    def bstack1ll111ll1l_opy_(self):
        def execute(this, driver_command, *args, **kwargs):
            response = self._1ll111l111_opy_(this, driver_command, *args, **kwargs)
            self.handler(driver_command, response)
            return response
        return execute
    def reset(self):
        self._1ll111l11l_opy_.execute = self._1ll111l111_opy_
    @staticmethod
    def bstack1ll111l1ll_opy_():
        from selenium.webdriver.remote.webdriver import WebDriver
        return WebDriver