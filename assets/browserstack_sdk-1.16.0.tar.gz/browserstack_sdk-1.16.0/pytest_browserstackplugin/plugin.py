# coding: UTF-8
import sys
bstack1l1llll_opy_ = sys.version_info [0] == 2
bstack1l1l1l1_opy_ = 2048
bstack11ll1l_opy_ = 7
def bstack11111ll_opy_ (bstack11111l1_opy_):
    global bstack1lll11_opy_
    bstack1l1ll_opy_ = ord (bstack11111l1_opy_ [-1])
    bstack1ll1l1_opy_ = bstack11111l1_opy_ [:-1]
    bstack1lll11l_opy_ = bstack1l1ll_opy_ % len (bstack1ll1l1_opy_)
    bstack1lllll1_opy_ = bstack1ll1l1_opy_ [:bstack1lll11l_opy_] + bstack1ll1l1_opy_ [bstack1lll11l_opy_:]
    if bstack1l1llll_opy_:
        bstack1l111_opy_ = unicode () .join ([unichr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    else:
        bstack1l111_opy_ = str () .join ([chr (ord (char) - bstack1l1l1l1_opy_ - (bstack1lllll_opy_ + bstack1l1ll_opy_) % bstack11ll1l_opy_) for bstack1lllll_opy_, char in enumerate (bstack1lllll1_opy_)])
    return eval (bstack1l111_opy_)
import datetime
import inspect
import os
import threading
from uuid import uuid4
import pytest
from bstack_utils.capture import bstack1l1l1ll11l_opy_
from bstack_utils.bstack1ll111ll11_opy_ import bstack1ll111l1l1_opy_
from bstack_utils.helper import bstack1l1l11111l_opy_, bstack1l1l1111l1_opy_, bstack11111l1l_opy_, bstack1l11llllll_opy_, \
    bstack1l1l111l11_opy_
from bstack_utils.bstack1ll1l11l1l_opy_ import bstack1lll11l1l1_opy_
try:
    from playwright.sync_api import (
        BrowserContext,
        Page
    )
except:
    pass
import json
_1l11l1l1l1_opy_ = {}
bstack1ll11111ll_opy_ = None
_1l11l1l111_opy_ = {}
def bstack1lll1lll11_opy_(page, bstack1lll111111_opy_):
    try:
        page.evaluate(bstack11111ll_opy_ (u"ࠨ࡟ࠡ࠿ࡁࠤࢀࢃࠢთ"),
                      bstack11111ll_opy_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡥࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠢࡾࠦࡦࡩࡴࡪࡱࡱࠦ࠿ࠦࠢࡴࡧࡷࡗࡪࡹࡳࡪࡱࡱࡒࡦࡳࡥࠣ࠮ࠣࠦࡦࡸࡧࡶ࡯ࡨࡲࡹࡹࠢ࠻ࠢࡾࠦࡳࡧ࡭ࡦࠤ࠽ࠫი") + json.dumps(
                          bstack1lll111111_opy_) + bstack11111ll_opy_ (u"ࠣࡿࢀࠦკ"))
    except Exception as e:
        print(bstack11111ll_opy_ (u"ࠤࡨࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲ࡯ࡥࡾࡽࡲࡪࡩ࡫ࡸࠥࡹࡥࡴࡵ࡬ࡳࡳࠦ࡮ࡢ࡯ࡨࠤࢀࢃࠢლ"), e)
def bstack11l1l11l_opy_(page, message, level):
    try:
        page.evaluate(bstack11111ll_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦმ"), bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡦࡴ࡮ࡰࡶࡤࡸࡪࠨࠬࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼࠤࡧࡥࡹࡧࠢ࠻ࠩნ") + json.dumps(
            message) + bstack11111ll_opy_ (u"ࠬ࠲ࠢ࡭ࡧࡹࡩࡱࠨ࠺ࠨო") + json.dumps(level) + bstack11111ll_opy_ (u"࠭ࡽࡾࠩპ"))
    except Exception as e:
        print(bstack11111ll_opy_ (u"ࠢࡦࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰ࡭ࡣࡼࡻࡷ࡯ࡧࡩࡶࠣࡥࡳࡴ࡯ࡵࡣࡷ࡭ࡴࡴࠠࡼࡿࠥჟ"), e)
def bstack1l1l1l111_opy_(page, status, message=bstack11111ll_opy_ (u"ࠣࠤრ")):
    try:
        if (status == bstack11111ll_opy_ (u"ࠤࡩࡥ࡮ࡲࡥࡥࠤს")):
            page.evaluate(bstack11111ll_opy_ (u"ࠥࡣࠥࡃ࠾ࠡࡽࢀࠦტ"),
                          bstack11111ll_opy_ (u"ࠫࡧࡸ࡯ࡸࡵࡨࡶࡸࡺࡡࡤ࡭ࡢࡩࡽ࡫ࡣࡶࡶࡲࡶ࠿ࠦࡻࠣࡣࡦࡸ࡮ࡵ࡮ࠣ࠼ࠣࠦࡸ࡫ࡴࡔࡧࡶࡷ࡮ࡵ࡮ࡔࡶࡤࡸࡺࡹࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡶࡪࡧࡳࡰࡰࠥ࠾ࠬუ") + json.dumps(
                              bstack11111ll_opy_ (u"࡙ࠧࡣࡦࡰࡤࡶ࡮ࡵࠠࡧࡣ࡬ࡰࡪࡪࠠࡸ࡫ࡷ࡬࠿ࠦࠢფ") + str(message)) + bstack11111ll_opy_ (u"࠭ࠬࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠪქ") + json.dumps(status) + bstack11111ll_opy_ (u"ࠢࡾࡿࠥღ"))
        else:
            page.evaluate(bstack11111ll_opy_ (u"ࠣࡡࠣࡁࡃࠦࡻࡾࠤყ"),
                          bstack11111ll_opy_ (u"ࠩࡥࡶࡴࡽࡳࡦࡴࡶࡸࡦࡩ࡫ࡠࡧࡻࡩࡨࡻࡴࡰࡴ࠽ࠤࢀࠨࡡࡤࡶ࡬ࡳࡳࠨ࠺ࠡࠤࡶࡩࡹ࡙ࡥࡴࡵ࡬ࡳࡳ࡙ࡴࡢࡶࡸࡷࠧ࠲ࠠࠣࡣࡵ࡫ࡺࡳࡥ࡯ࡶࡶࠦ࠿ࠦࡻࠣࡵࡷࡥࡹࡻࡳࠣ࠼ࠪშ") + json.dumps(
                              status) + bstack11111ll_opy_ (u"ࠥࢁࢂࠨჩ"))
    except Exception as e:
        print(bstack11111ll_opy_ (u"ࠦࡪࡾࡣࡦࡲࡷ࡭ࡴࡴࠠࡪࡰࠣࡴࡱࡧࡹࡸࡴ࡬࡫࡭ࡺࠠࡴࡧࡷࠤࡸ࡫ࡳࡴ࡫ࡲࡲࠥࡹࡴࡢࡶࡸࡷࠥࢁࡽࠣც"), e)
@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    bstack1l11ll1lll_opy_ = item.config.getoption(bstack11111ll_opy_ (u"ࠬࡹ࡫ࡪࡲࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠧძ"))
    plugins = item.config.getoption(bstack11111ll_opy_ (u"ࠨࡰ࡭ࡷࡪ࡭ࡳࡹࠢწ"))
    report = outcome.get_result()
    bstack1l11l1ll1l_opy_(item, call, report)
    if bstack11111ll_opy_ (u"ࠢࡱࡻࡷࡩࡸࡺ࡟ࡣࡴࡲࡻࡸ࡫ࡲࡴࡶࡤࡧࡰࡶ࡬ࡶࡩ࡬ࡲࠧჭ") not in plugins:
        return
    summary = []
    driver = getattr(item, bstack11111ll_opy_ (u"ࠣࡡࡧࡶ࡮ࡼࡥࡳࠤხ"), None)
    page = getattr(item, bstack11111ll_opy_ (u"ࠤࡢࡴࡦ࡭ࡥࠣჯ"), None)
    try:
        if (driver == None):
            driver = threading.current_thread().bstackSessionDriver
    except:
        pass
    item._driver = driver
    if (driver is not None):
        bstack1l11ll1111_opy_(item, report, summary, bstack1l11ll1lll_opy_)
    if (page is not None):
        bstack1l11ll111l_opy_(item, report, summary, bstack1l11ll1lll_opy_)
def bstack1l11ll1111_opy_(item, report, summary, bstack1l11ll1lll_opy_):
    if report.when in [bstack11111ll_opy_ (u"ࠥࡷࡪࡺࡵࡱࠤჰ"), bstack11111ll_opy_ (u"ࠦࡹ࡫ࡡࡳࡦࡲࡻࡳࠨჱ")]:
        return
    if not bstack1l1l1111l1_opy_():
        return
    if (str(bstack1l11ll1lll_opy_).lower() != bstack11111ll_opy_ (u"ࠬࡺࡲࡶࡧࠪჲ")):
        item._driver.execute_script(
            bstack11111ll_opy_ (u"࠭ࡢࡳࡱࡺࡷࡪࡸࡳࡵࡣࡦ࡯ࡤ࡫ࡸࡦࡥࡸࡸࡴࡸ࠺ࠡࡽࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡳࡦࡶࡖࡩࡸࡹࡩࡰࡰࡑࡥࡲ࡫ࠢ࠭ࠢࠥࡥࡷ࡭ࡵ࡮ࡧࡱࡸࡸࠨ࠺ࠡࡽࠥࡲࡦࡳࡥࠣ࠼ࠣࠫჳ") + json.dumps(
                report.nodeid) + bstack11111ll_opy_ (u"ࠧࡾࡿࠪჴ"))
    passed = report.passed or (report.failed and hasattr(report, bstack11111ll_opy_ (u"ࠣࡹࡤࡷࡽ࡬ࡡࡪ࡮ࠥჵ")))
    bstack1lll111ll_opy_ = bstack11111ll_opy_ (u"ࠤࠥჶ")
    if not passed:
        try:
            bstack1lll111ll_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack11111ll_opy_ (u"࡛ࠥࡆࡘࡎࡊࡐࡊ࠾ࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡦࡨࡸࡪࡸ࡭ࡪࡰࡨࠤ࡫ࡧࡩ࡭ࡷࡵࡩࠥࡸࡥࡢࡵࡲࡲ࠿ࠦࡻ࠱ࡿࠥჷ").format(e)
            )
    if (bstack1lll111ll_opy_ != bstack11111ll_opy_ (u"ࠦࠧჸ")):
        try:
            if (threading.current_thread().bstackTestErrorMessages == None):
                threading.current_thread().bstackTestErrorMessages = []
        except Exception as e:
            threading.current_thread().bstackTestErrorMessages = []
        threading.current_thread().bstackTestErrorMessages.append(str(bstack1lll111ll_opy_))
    try:
        if (passed):
            item._driver.execute_script(
                bstack11111ll_opy_ (u"ࠬࡨࡲࡰࡹࡶࡩࡷࡹࡴࡢࡥ࡮ࡣࡪࡾࡥࡤࡷࡷࡳࡷࡀࠠࡼ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠢࡢࡥࡷ࡭ࡴࡴࠢ࠻ࠢࠥࡥࡳࡴ࡯ࡵࡣࡷࡩࠧ࠲ࠠ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨࡡࡳࡩࡸࡱࡪࡴࡴࡴࠤ࠽ࠤࢀࡢࠊࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠣ࡮ࡨࡺࡪࡲࠢ࠻ࠢࠥ࡭ࡳ࡬࡯ࠣ࠮ࠣࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠨࡤࡢࡶࡤࠦ࠿ࠦࠧჹ")
                + json.dumps(bstack11111ll_opy_ (u"ࠨࡰࡢࡵࡶࡩࡩࠧࠢჺ"))
                + bstack11111ll_opy_ (u"ࠢ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࢃ࡜ࠋࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾࠤ჻")
            )
        else:
            item._driver.execute_script(
                bstack11111ll_opy_ (u"ࠨࡤࡵࡳࡼࡹࡥࡳࡵࡷࡥࡨࡱ࡟ࡦࡺࡨࡧࡺࡺ࡯ࡳ࠼ࠣࡿࡡࠐࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡥࡨࡺࡩࡰࡰࠥ࠾ࠥࠨࡡ࡯ࡰࡲࡸࡦࡺࡥࠣ࠮ࠣࡠࠏࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠤࡤࡶ࡬ࡻ࡭ࡦࡰࡷࡷࠧࡀࠠࡼ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠦࡱ࡫ࡶࡦ࡮ࠥ࠾ࠥࠨࡥࡳࡴࡲࡶࠧ࠲ࠠ࡝ࠌࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠥࡨࡦࡺࡡࠣ࠼ࠣࠫჼ")
                + json.dumps(str(bstack1lll111ll_opy_))
                + bstack11111ll_opy_ (u"ࠤ࡟ࠎࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࡾ࡞ࠍࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࢀࠦჽ")
            )
    except Exception as e:
        summary.append(bstack11111ll_opy_ (u"࡛ࠥࡆࡘࡎࡊࡐࡊ࠾ࠥࡌࡡࡪ࡮ࡨࡨࠥࡺ࡯ࠡࡣࡱࡲࡴࡺࡡࡵࡧ࠽ࠤࢀ࠶ࡽࠣჾ").format(e))
def bstack1l11ll111l_opy_(item, report, summary, bstack1l11ll1lll_opy_):
    if report.when in [bstack11111ll_opy_ (u"ࠦࡸ࡫ࡴࡶࡲࠥჿ"), bstack11111ll_opy_ (u"ࠧࡺࡥࡢࡴࡧࡳࡼࡴࠢᄀ")]:
        return
    if (str(bstack1l11ll1lll_opy_).lower() != bstack11111ll_opy_ (u"࠭ࡴࡳࡷࡨࠫᄁ")):
        bstack1lll1lll11_opy_(item._page, report.nodeid)
    passed = report.passed or (report.failed and hasattr(report, bstack11111ll_opy_ (u"ࠢࡸࡣࡶࡼ࡫ࡧࡩ࡭ࠤᄂ")))
    bstack1lll111ll_opy_ = bstack11111ll_opy_ (u"ࠣࠤᄃ")
    if not passed:
        try:
            bstack1lll111ll_opy_ = report.longrepr.reprcrash
        except Exception as e:
            summary.append(
                bstack11111ll_opy_ (u"ࠤ࡚ࡅࡗࡔࡉࡏࡉ࠽ࠤࡋࡧࡩ࡭ࡧࡧࠤࡹࡵࠠࡥࡧࡷࡩࡷࡳࡩ࡯ࡧࠣࡪࡦ࡯࡬ࡶࡴࡨࠤࡷ࡫ࡡࡴࡱࡱ࠾ࠥࢁ࠰ࡾࠤᄄ").format(e)
            )
    try:
        if passed:
            bstack1l1l1l111_opy_(item._page, bstack11111ll_opy_ (u"ࠥࡴࡦࡹࡳࡦࡦࠥᄅ"))
        else:
            if bstack1lll111ll_opy_:
                bstack11l1l11l_opy_(item._page, str(bstack1lll111ll_opy_), bstack11111ll_opy_ (u"ࠦࡪࡸࡲࡰࡴࠥᄆ"))
                bstack1l1l1l111_opy_(item._page, bstack11111ll_opy_ (u"ࠧ࡬ࡡࡪ࡮ࡨࡨࠧᄇ"), str(bstack1lll111ll_opy_))
            else:
                bstack1l1l1l111_opy_(item._page, bstack11111ll_opy_ (u"ࠨࡦࡢ࡫࡯ࡩࡩࠨᄈ"))
    except Exception as e:
        summary.append(bstack11111ll_opy_ (u"ࠢࡘࡃࡕࡒࡎࡔࡇ࠻ࠢࡉࡥ࡮ࡲࡥࡥࠢࡷࡳࠥࡻࡰࡥࡣࡷࡩࠥࡹࡥࡴࡵ࡬ࡳࡳࠦࡳࡵࡣࡷࡹࡸࡀࠠࡼ࠲ࢀࠦᄉ").format(e))
try:
    from typing import Generator
    import pytest_playwright.pytest_playwright as p
    @pytest.fixture
    def page(context: BrowserContext, request: pytest.FixtureRequest) -> Generator[Page, None, None]:
        page = context.new_page()
        request.node._page = page
        yield page
except:
    pass
def pytest_addoption(parser):
    parser.addoption(bstack11111ll_opy_ (u"ࠣ࠯࠰ࡷࡰ࡯ࡰࡔࡧࡶࡷ࡮ࡵ࡮ࡏࡣࡰࡩࠧᄊ"), default=bstack11111ll_opy_ (u"ࠤࡉࡥࡱࡹࡥࠣᄋ"), help=bstack11111ll_opy_ (u"ࠥࡅࡺࡺ࡯࡮ࡣࡷ࡭ࡨࠦࡳࡦࡶࠣࡷࡪࡹࡳࡪࡱࡱࠤࡳࡧ࡭ࡦࠤᄌ"))
    try:
        import pytest_selenium.pytest_selenium
    except:
        parser.addoption(bstack11111ll_opy_ (u"ࠦ࠲࠳ࡤࡳ࡫ࡹࡩࡷࠨᄍ"), action=bstack11111ll_opy_ (u"ࠧࡹࡴࡰࡴࡨࠦᄎ"), default=bstack11111ll_opy_ (u"ࠨࡣࡩࡴࡲࡱࡪࠨᄏ"),
                         help=bstack11111ll_opy_ (u"ࠢࡅࡴ࡬ࡺࡪࡸࠠࡵࡱࠣࡶࡺࡴࠠࡵࡧࡶࡸࡸࠨᄐ"))
def bstack1l11l1l1ll_opy_(log):
    if log[bstack11111ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᄑ")] == bstack11111ll_opy_ (u"ࠩ࡟ࡲࠬᄒ"):
        return
    bstack1lll11l1l1_opy_.bstack1l1llll111_opy_([{
        bstack11111ll_opy_ (u"ࠪࡰࡪࡼࡥ࡭ࠩᄓ"): log[bstack11111ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪᄔ")],
        bstack11111ll_opy_ (u"ࠬࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨᄕ"): datetime.datetime.utcnow().isoformat() + bstack11111ll_opy_ (u"࡚࠭ࠨᄖ"),
        bstack11111ll_opy_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࠨᄗ"): log[bstack11111ll_opy_ (u"ࠨ࡯ࡨࡷࡸࡧࡧࡦࠩᄘ")],
        bstack11111ll_opy_ (u"ࠩࡷࡩࡸࡺ࡟ࡳࡷࡱࡣࡺࡻࡩࡥࠩᄙ"): bstack1ll11111ll_opy_
    }])
bstack1l11l1l11l_opy_ = bstack1l1l1ll11l_opy_(bstack1l11l1l1ll_opy_)
def pytest_runtest_call(item):
    try:
        if not bstack1lll11l1l1_opy_.on():
            return
        global bstack1ll11111ll_opy_, bstack1l11l1l11l_opy_
        bstack1l11l1l11l_opy_.start()
        bstack1l11l111ll_opy_ = {
            bstack11111ll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᄚ"): uuid4().__str__(),
            bstack11111ll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᄛ"): datetime.datetime.utcnow().isoformat() + bstack11111ll_opy_ (u"ࠬࡠࠧᄜ")
        }
        bstack1ll11111ll_opy_ = bstack1l11l111ll_opy_[bstack11111ll_opy_ (u"࠭ࡵࡶ࡫ࡧࠫᄝ")]
        threading.current_thread().bstack1ll11111ll_opy_ = bstack1ll11111ll_opy_
        _1l11l1l1l1_opy_[item.nodeid] = {**_1l11l1l1l1_opy_[item.nodeid], **bstack1l11l111ll_opy_}
        bstack1l11l11ll1_opy_(item, _1l11l1l1l1_opy_[item.nodeid], bstack11111ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨᄞ"))
    except Exception as err:
        print(bstack11111ll_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡱࡻࡷࡩࡸࡺ࡟ࡳࡷࡱࡸࡪࡹࡴࡠࡥࡤࡰࡱࡀࠠࡼࡿࠪᄟ"), str(err))
def pytest_runtest_setup(item):
    try:
        if not bstack1lll11l1l1_opy_.on():
            return
        uuid = uuid4().__str__()
        bstack1l11l111ll_opy_ = {
            bstack11111ll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᄠ"): uuid,
            bstack11111ll_opy_ (u"ࠪࡷࡹࡧࡲࡵࡧࡧࡣࡦࡺࠧᄡ"): datetime.datetime.utcnow().isoformat() + bstack11111ll_opy_ (u"ࠫ࡟࠭ᄢ"),
            bstack11111ll_opy_ (u"ࠬࡺࡹࡱࡧࠪᄣ"): bstack11111ll_opy_ (u"࠭ࡨࡰࡱ࡮ࠫᄤ"),
            bstack11111ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡺࡹࡱࡧࠪᄥ"): bstack11111ll_opy_ (u"ࠨࡄࡈࡊࡔࡘࡅࡠࡇࡄࡇࡍ࠭ᄦ")
        }
        threading.current_thread().bstack1l11ll11l1_opy_ = uuid
        if not _1l11l1l1l1_opy_.get(item.nodeid, None):
            _1l11l1l1l1_opy_[item.nodeid] = {bstack11111ll_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨᄧ"): []}
        _1l11l1l1l1_opy_[item.nodeid][bstack11111ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡴࠩᄨ")].append(bstack1l11l111ll_opy_[bstack11111ll_opy_ (u"ࠫࡺࡻࡩࡥࠩᄩ")])
        _1l11l1l1l1_opy_[item.nodeid + bstack11111ll_opy_ (u"ࠬ࠳ࡳࡦࡶࡸࡴࠬᄪ")] = bstack1l11l111ll_opy_
        bstack1l11ll1l11_opy_(item, bstack1l11l111ll_opy_, bstack11111ll_opy_ (u"࠭ࡈࡰࡱ࡮ࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᄫ"))
    except Exception as err:
        print(bstack11111ll_opy_ (u"ࠧࡆࡺࡦࡩࡵࡺࡩࡰࡰࠣ࡭ࡳࠦࡰࡺࡶࡨࡷࡹࡥࡲࡶࡰࡷࡩࡸࡺ࡟ࡴࡧࡷࡹࡵࡀࠠࡼࡿࠪᄬ"), str(err))
def pytest_runtest_teardown(item):
    try:
        if not bstack1lll11l1l1_opy_.on():
            return
        bstack1l11l111ll_opy_ = {
            bstack11111ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᄭ"): uuid4().__str__(),
            bstack11111ll_opy_ (u"ࠩࡶࡸࡦࡸࡴࡦࡦࡢࡥࡹ࠭ᄮ"): datetime.datetime.utcnow().isoformat() + bstack11111ll_opy_ (u"ࠪ࡞ࠬᄯ"),
            bstack11111ll_opy_ (u"ࠫࡹࡿࡰࡦࠩᄰ"): bstack11111ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࠪᄱ"),
            bstack11111ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡹࡿࡰࡦࠩᄲ"): bstack11111ll_opy_ (u"ࠧࡂࡈࡗࡉࡗࡥࡅࡂࡅࡋࠫᄳ")
        }
        _1l11l1l1l1_opy_[item.nodeid + bstack11111ll_opy_ (u"ࠨ࠯ࡷࡩࡦࡸࡤࡰࡹࡱࠫᄴ")] = bstack1l11l111ll_opy_
        bstack1l11ll1l11_opy_(item, bstack1l11l111ll_opy_, bstack11111ll_opy_ (u"ࠩࡋࡳࡴࡱࡒࡶࡰࡖࡸࡦࡸࡴࡦࡦࠪᄵ"))
    except Exception as err:
        print(bstack11111ll_opy_ (u"ࠪࡉࡽࡩࡥࡱࡶ࡬ࡳࡳࠦࡩ࡯ࠢࡳࡽࡹ࡫ࡳࡵࡡࡵࡹࡳࡺࡥࡴࡶࡢࡸࡪࡧࡲࡥࡱࡺࡲ࠿ࠦࡻࡾࠩᄶ"), str(err))
@pytest.hookimpl(hookwrapper=True)
def pytest_fixture_setup(fixturedef):
    start_time = datetime.datetime.now()
    outcome = yield
    try:
        if not bstack1lll11l1l1_opy_.on():
            return
        bstack1l11l11l11_opy_ = threading.current_thread().bstack1l11ll11l1_opy_
        log = {
            bstack11111ll_opy_ (u"ࠫࡰ࡯࡮ࡥࠩᄷ"): bstack11111ll_opy_ (u"࡚ࠬࡅࡔࡖࡢࡗ࡙ࡋࡐࠨᄸ"),
            bstack11111ll_opy_ (u"࠭࡭ࡦࡵࡶࡥ࡬࡫ࠧᄹ"): fixturedef.argname,
            bstack11111ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡸࡵ࡯ࡡࡸࡹ࡮ࡪࠧᄺ"): threading.current_thread().bstack1l11ll11l1_opy_,
            bstack11111ll_opy_ (u"ࠨࡶ࡬ࡱࡪࡹࡴࡢ࡯ࡳࠫᄻ"): bstack11111l1l_opy_(),
            bstack11111ll_opy_ (u"ࠩ࡯ࡩࡻ࡫࡬ࠨᄼ"): bstack1l11llllll_opy_(outcome),
            bstack11111ll_opy_ (u"ࠪࡨࡺࡸࡡࡵ࡫ࡲࡲࠬᄽ"): (datetime.datetime.now() - start_time).total_seconds() * 1000,
        }
        if log[bstack11111ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪᄾ")] == bstack11111ll_opy_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬᄿ"):
            log[bstack11111ll_opy_ (u"࠭ࡦࡢ࡫࡯ࡹࡷ࡫࡟ࡵࡻࡳࡩࠬᅀ")] = bstack11111ll_opy_ (u"ࠧࡖࡰ࡫ࡥࡳࡪ࡬ࡦࡦࡈࡶࡷࡵࡲࠨᅁ")
            log[bstack11111ll_opy_ (u"ࠨࡨࡤ࡭ࡱࡻࡲࡦࠩᅂ")] = outcome.exception.__str__()
        if not _1l11l1l111_opy_.get(bstack1l11l11l11_opy_, None):
            _1l11l1l111_opy_[bstack1l11l11l11_opy_] = []
        _1l11l1l111_opy_[bstack1l11l11l11_opy_].append(log)
    except Exception as err:
        print(bstack11111ll_opy_ (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡲࡼࡸࡪࡹࡴࡠࡨ࡬ࡼࡹࡻࡲࡦࡡࡶࡩࡹࡻࡰ࠻ࠢࡾࢁࠬᅃ"), str(err))
@bstack1lll11l1l1_opy_.bstack1l1ll11111_opy_
def bstack1l11l1ll1l_opy_(item, call, report):
    try:
        if report.when == bstack11111ll_opy_ (u"ࠪࡧࡦࡲ࡬ࠨᅄ"):
            bstack1l11l1l11l_opy_.reset()
        if report.when == bstack11111ll_opy_ (u"ࠫࡨࡧ࡬࡭ࠩᅅ"):
            _1l11l1l1l1_opy_[item.nodeid][bstack11111ll_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᅆ")] = datetime.datetime.utcfromtimestamp(report.stop).isoformat() + bstack11111ll_opy_ (u"࡚࠭ࠨᅇ")
            bstack1l11l11ll1_opy_(item, _1l11l1l1l1_opy_[item.nodeid], bstack11111ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡇ࡫ࡱ࡭ࡸ࡮ࡥࡥࠩᅈ"), report, call)
        elif report.when in [bstack11111ll_opy_ (u"ࠨࡵࡨࡸࡺࡶࠧᅉ"), bstack11111ll_opy_ (u"ࠩࡷࡩࡦࡸࡤࡰࡹࡱࠫᅊ")]:
            bstack1l11l11lll_opy_ = item.nodeid + bstack11111ll_opy_ (u"ࠪ࠱ࠬᅋ") + report.when
            if report.skipped:
                hook_type = bstack11111ll_opy_ (u"ࠫࡇࡋࡆࡐࡔࡈࡣࡊࡇࡃࡉࠩᅌ") if report.when == bstack11111ll_opy_ (u"ࠬࡹࡥࡵࡷࡳࠫᅍ") else bstack11111ll_opy_ (u"࠭ࡁࡇࡖࡈࡖࡤࡋࡁࡄࡊࠪᅎ")
                _1l11l1l1l1_opy_[bstack1l11l11lll_opy_] = {
                    bstack11111ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᅏ"): uuid4().__str__(),
                    bstack11111ll_opy_ (u"ࠨࡵࡷࡥࡷࡺࡥࡥࡡࡤࡸࠬᅐ"): datetime.datetime.utcfromtimestamp(report.start).isoformat() + bstack11111ll_opy_ (u"ࠩ࡝ࠫᅑ"),
                    bstack11111ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡠࡶࡼࡴࡪ࠭ᅒ"): hook_type
                }
            _1l11l1l1l1_opy_[bstack1l11l11lll_opy_][bstack11111ll_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᅓ")] = datetime.datetime.utcfromtimestamp(report.stop).isoformat() + bstack11111ll_opy_ (u"ࠬࡠࠧᅔ")
            if report.when == bstack11111ll_opy_ (u"࠭ࡳࡦࡶࡸࡴࠬᅕ"):
                bstack1l11l11l11_opy_ = _1l11l1l1l1_opy_[bstack1l11l11lll_opy_][bstack11111ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᅖ")]
                if _1l11l1l111_opy_.get(bstack1l11l11l11_opy_, None):
                    bstack1lll11l1l1_opy_.bstack1ll1111ll1_opy_(_1l11l1l111_opy_[bstack1l11l11l11_opy_])
            bstack1l11ll1l11_opy_(item, _1l11l1l1l1_opy_[bstack1l11l11lll_opy_], bstack11111ll_opy_ (u"ࠨࡊࡲࡳࡰࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᅗ"), report, call)
            if report.when == bstack11111ll_opy_ (u"ࠩࡶࡩࡹࡻࡰࠨᅘ"):
                if report.outcome == bstack11111ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪᅙ"):
                    bstack1l11l111ll_opy_ = {
                        bstack11111ll_opy_ (u"ࠫࡺࡻࡩࡥࠩᅚ"): uuid4().__str__(),
                        bstack11111ll_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᅛ"): bstack11111l1l_opy_(),
                        bstack11111ll_opy_ (u"࠭ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡠࡣࡷࠫᅜ"): bstack11111l1l_opy_()
                    }
                    _1l11l1l1l1_opy_[item.nodeid] = {**_1l11l1l1l1_opy_[item.nodeid], **bstack1l11l111ll_opy_}
                    bstack1l11l11ll1_opy_(item, _1l11l1l1l1_opy_[item.nodeid], bstack11111ll_opy_ (u"ࠧࡕࡧࡶࡸࡗࡻ࡮ࡔࡶࡤࡶࡹ࡫ࡤࠨᅝ"))
                    bstack1l11l11ll1_opy_(item, _1l11l1l1l1_opy_[item.nodeid], bstack11111ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡈ࡬ࡲ࡮ࡹࡨࡦࡦࠪᅞ"), report, call)
    except Exception as err:
        print(bstack11111ll_opy_ (u"ࠩࡈࡼࡨ࡫ࡰࡵ࡫ࡲࡲࠥ࡯࡮ࠡࡪࡤࡲࡩࡲࡥࡠࡱ࠴࠵ࡾࡥࡴࡦࡵࡷࡣࡪࡼࡥ࡯ࡶ࠽ࠤࢀࢃࠧᅟ"), str(err))
def bstack1l11ll1ll1_opy_(test, bstack1l11l111ll_opy_, result=None, call=None, bstack11lll111_opy_=None):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    bstack1l11l11l1l_opy_ = {
        bstack11111ll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᅠ"): bstack1l11l111ll_opy_[bstack11111ll_opy_ (u"ࠫࡺࡻࡩࡥࠩᅡ")],
        bstack11111ll_opy_ (u"ࠬࡺࡹࡱࡧࠪᅢ"): bstack11111ll_opy_ (u"࠭ࡴࡦࡵࡷࠫᅣ"),
        bstack11111ll_opy_ (u"ࠧ࡯ࡣࡰࡩࠬᅤ"): test.name,
        bstack11111ll_opy_ (u"ࠨࡤࡲࡨࡾ࠭ᅥ"): {
            bstack11111ll_opy_ (u"ࠩ࡯ࡥࡳ࡭ࠧᅦ"): bstack11111ll_opy_ (u"ࠪࡴࡾࡺࡨࡰࡰࠪᅧ"),
            bstack11111ll_opy_ (u"ࠫࡨࡵࡤࡦࠩᅨ"): inspect.getsource(test.obj)
        },
        bstack11111ll_opy_ (u"ࠬ࡯ࡤࡦࡰࡷ࡭࡫࡯ࡥࡳࠩᅩ"): test.name,
        bstack11111ll_opy_ (u"࠭ࡳࡤࡱࡳࡩࠬᅪ"): test.name,
        bstack11111ll_opy_ (u"ࠧࡴࡥࡲࡴࡪࡹࠧᅫ"): bstack1lll11l1l1_opy_.bstack1l1l1lll11_opy_(test),
        bstack11111ll_opy_ (u"ࠨࡨ࡬ࡰࡪࡥ࡮ࡢ࡯ࡨࠫᅬ"): file_path,
        bstack11111ll_opy_ (u"ࠩ࡯ࡳࡨࡧࡴࡪࡱࡱࠫᅭ"): file_path,
        bstack11111ll_opy_ (u"ࠪࡶࡪࡹࡵ࡭ࡶࠪᅮ"): bstack11111ll_opy_ (u"ࠫࡵ࡫࡮ࡥ࡫ࡱ࡫ࠬᅯ"),
        bstack11111ll_opy_ (u"ࠬࡼࡣࡠࡨ࡬ࡰࡪࡶࡡࡵࡪࠪᅰ"): file_path,
        bstack11111ll_opy_ (u"࠭ࡳࡵࡣࡵࡸࡪࡪ࡟ࡢࡶࠪᅱ"): bstack1l11l111ll_opy_[bstack11111ll_opy_ (u"ࠧࡴࡶࡤࡶࡹ࡫ࡤࡠࡣࡷࠫᅲ")],
        bstack11111ll_opy_ (u"ࠨࡨࡵࡥࡲ࡫ࡷࡰࡴ࡮ࠫᅳ"): bstack11111ll_opy_ (u"ࠩࡓࡽࡹ࡫ࡳࡵࠩᅴ"),
        bstack11111ll_opy_ (u"ࠪࡧࡺࡹࡴࡰ࡯ࡕࡩࡷࡻ࡮ࡑࡣࡵࡥࡲ࠭ᅵ"): {
            bstack11111ll_opy_ (u"ࠫࡷ࡫ࡲࡶࡰࡢࡲࡦࡳࡥࠨᅶ"): test.nodeid
        },
        bstack11111ll_opy_ (u"ࠬࡺࡡࡨࡵࠪᅷ"): bstack1l1l111l11_opy_(test.own_markers)
    }
    if bstack11lll111_opy_ == bstack11111ll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓ࡬࡫ࡳࡴࡪࡪࠧᅸ"):
        bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠧࡳࡧࡶࡹࡱࡺࠧᅹ")] = bstack11111ll_opy_ (u"ࠨࡵ࡮࡭ࡵࡶࡥࡥࠩᅺ")
        bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠩ࡫ࡳࡴࡱࡳࠨᅻ")] = bstack1l11l111ll_opy_[bstack11111ll_opy_ (u"ࠪ࡬ࡴࡵ࡫ࡴࠩᅼ")]
        bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠫ࡫࡯࡮ࡪࡵ࡫ࡩࡩࡥࡡࡵࠩᅽ")] = bstack1l11l111ll_opy_[bstack11111ll_opy_ (u"ࠬ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪ࡟ࡢࡶࠪᅾ")]
    if result:
        bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᅿ")] = result.outcome
        bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࡡ࡬ࡲࡤࡳࡳࠨᆀ")] = result.duration * 1000
        bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᆁ")] = bstack1l11l111ll_opy_[bstack11111ll_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧᆂ")]
        if result.failed:
            bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࡣࡹࡿࡰࡦࠩᆃ")] = bstack1lll11l1l1_opy_.bstack1l1lll1l11_opy_(call.excinfo.typename)
            bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᆄ")] = bstack1lll11l1l1_opy_.bstack1l1lll1l1l_opy_(call.excinfo, result)
        bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠬ࡮࡯ࡰ࡭ࡶࠫᆅ")] = bstack1l11l111ll_opy_[bstack11111ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡷࠬᆆ")]
    return bstack1l11l11l1l_opy_
def bstack1l11l1llll_opy_(test, bstack1l11l1ll11_opy_, bstack11lll111_opy_, result, call):
    file_path = os.path.relpath(test.fspath.strpath, start=os.getcwd())
    hook_type = bstack1l11l1ll11_opy_[bstack11111ll_opy_ (u"ࠧࡩࡱࡲ࡯ࡤࡺࡹࡱࡧࠪᆇ")]
    hook_data = {
        bstack11111ll_opy_ (u"ࠨࡷࡸ࡭ࡩ࠭ᆈ"): bstack1l11l1ll11_opy_[bstack11111ll_opy_ (u"ࠩࡸࡹ࡮ࡪࠧᆉ")],
        bstack11111ll_opy_ (u"ࠪࡸࡾࡶࡥࠨᆊ"): bstack11111ll_opy_ (u"ࠫ࡭ࡵ࡯࡬ࠩᆋ"),
        bstack11111ll_opy_ (u"ࠬࡴࡡ࡮ࡧࠪᆌ"): bstack11111ll_opy_ (u"࠭ࡻࡾࠢࡩࡳࡷࠦࡻࡾࠩᆍ").format(bstack1lll11l1l1_opy_.bstack1ll1111111_opy_(hook_type), test.name),
        bstack11111ll_opy_ (u"ࠧࡣࡱࡧࡽࠬᆎ"): {
            bstack11111ll_opy_ (u"ࠨ࡮ࡤࡲ࡬࠭ᆏ"): bstack11111ll_opy_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࠩᆐ"),
            bstack11111ll_opy_ (u"ࠪࡧࡴࡪࡥࠨᆑ"): None
        },
        bstack11111ll_opy_ (u"ࠫࡸࡩ࡯ࡱࡧࠪᆒ"): test.name,
        bstack11111ll_opy_ (u"ࠬࡹࡣࡰࡲࡨࡷࠬᆓ"): bstack1lll11l1l1_opy_.bstack1l1l1lll11_opy_(test),
        bstack11111ll_opy_ (u"࠭ࡦࡪ࡮ࡨࡣࡳࡧ࡭ࡦࠩᆔ"): file_path,
        bstack11111ll_opy_ (u"ࠧ࡭ࡱࡦࡥࡹ࡯࡯࡯ࠩᆕ"): file_path,
        bstack11111ll_opy_ (u"ࠨࡴࡨࡷࡺࡲࡴࠨᆖ"): bstack11111ll_opy_ (u"ࠩࡳࡩࡳࡪࡩ࡯ࡩࠪᆗ"),
        bstack11111ll_opy_ (u"ࠪࡺࡨࡥࡦࡪ࡮ࡨࡴࡦࡺࡨࠨᆘ"): file_path,
        bstack11111ll_opy_ (u"ࠫࡸࡺࡡࡳࡶࡨࡨࡤࡧࡴࠨᆙ"): bstack1l11l1ll11_opy_[bstack11111ll_opy_ (u"ࠬࡹࡴࡢࡴࡷࡩࡩࡥࡡࡵࠩᆚ")],
        bstack11111ll_opy_ (u"࠭ࡦࡳࡣࡰࡩࡼࡵࡲ࡬ࠩᆛ"): bstack11111ll_opy_ (u"ࠧࡑࡻࡷࡩࡸࡺࠧᆜ"),
        bstack11111ll_opy_ (u"ࠨࡪࡲࡳࡰࡥࡴࡺࡲࡨࠫᆝ"): bstack1l11l1ll11_opy_[bstack11111ll_opy_ (u"ࠩ࡫ࡳࡴࡱ࡟ࡵࡻࡳࡩࠬᆞ")]
    }
    if _1l11l1l1l1_opy_.get(test.nodeid, None) is not None and _1l11l1l1l1_opy_[test.nodeid].get(bstack11111ll_opy_ (u"ࠪࡹࡺ࡯ࡤࠨᆟ"), None):
        hook_data[bstack11111ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳࡥࡩࡥࠩᆠ")] = _1l11l1l1l1_opy_[test.nodeid][bstack11111ll_opy_ (u"ࠬࡻࡵࡪࡦࠪᆡ")]
    if result:
        hook_data[bstack11111ll_opy_ (u"࠭ࡲࡦࡵࡸࡰࡹ࠭ᆢ")] = result.outcome
        hook_data[bstack11111ll_opy_ (u"ࠧࡥࡷࡵࡥࡹ࡯࡯࡯ࡡ࡬ࡲࡤࡳࡳࠨᆣ")] = result.duration * 1000
        hook_data[bstack11111ll_opy_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࡦࡦࡢࡥࡹ࠭ᆤ")] = bstack1l11l1ll11_opy_[bstack11111ll_opy_ (u"ࠩࡩ࡭ࡳ࡯ࡳࡩࡧࡧࡣࡦࡺࠧᆥ")]
        if result.failed:
            hook_data[bstack11111ll_opy_ (u"ࠪࡪࡦ࡯࡬ࡶࡴࡨࡣࡹࡿࡰࡦࠩᆦ")] = bstack1lll11l1l1_opy_.bstack1l1lll1l11_opy_(call.excinfo.typename)
            hook_data[bstack11111ll_opy_ (u"ࠫ࡫ࡧࡩ࡭ࡷࡵࡩࠬᆧ")] = bstack1lll11l1l1_opy_.bstack1l1lll1l1l_opy_(call.excinfo, result)
    return hook_data
def bstack1l11l11ll1_opy_(test, bstack1l11l111ll_opy_, bstack11lll111_opy_, result=None, call=None):
    bstack1l11l11l1l_opy_ = bstack1l11ll1ll1_opy_(test, bstack1l11l111ll_opy_, result, call, bstack11lll111_opy_)
    driver = getattr(test, bstack11111ll_opy_ (u"ࠬࡥࡤࡳ࡫ࡹࡩࡷ࠭ᆨ"), None)
    if bstack11lll111_opy_ == bstack11111ll_opy_ (u"࠭ࡔࡦࡵࡷࡖࡺࡴࡓࡵࡣࡵࡸࡪࡪࠧᆩ") and driver:
        bstack1l11l11l1l_opy_[bstack11111ll_opy_ (u"ࠧࡪࡰࡷࡩ࡬ࡸࡡࡵ࡫ࡲࡲࡸ࠭ᆪ")] = bstack1lll11l1l1_opy_.bstack1l1lll1111_opy_(driver)
    if bstack11lll111_opy_ == bstack11111ll_opy_ (u"ࠨࡖࡨࡷࡹࡘࡵ࡯ࡕ࡮࡭ࡵࡶࡥࡥࠩᆫ"):
        bstack11lll111_opy_ = bstack11111ll_opy_ (u"ࠩࡗࡩࡸࡺࡒࡶࡰࡉ࡭ࡳ࡯ࡳࡩࡧࡧࠫᆬ")
    bstack1l11l1lll1_opy_ = {
        bstack11111ll_opy_ (u"ࠪࡩࡻ࡫࡮ࡵࡡࡷࡽࡵ࡫ࠧᆭ"): bstack11lll111_opy_,
        bstack11111ll_opy_ (u"ࠫࡹ࡫ࡳࡵࡡࡵࡹࡳ࠭ᆮ"): bstack1l11l11l1l_opy_
    }
    bstack1lll11l1l1_opy_.bstack1ll111111l_opy_(bstack1l11l1lll1_opy_)
def bstack1l11ll1l11_opy_(test, bstack1l11l111ll_opy_, bstack11lll111_opy_, result=None, call=None):
    hook_data = bstack1l11l1llll_opy_(test, bstack1l11l111ll_opy_, bstack11lll111_opy_, result, call)
    bstack1l11l1lll1_opy_ = {
        bstack11111ll_opy_ (u"ࠬ࡫ࡶࡦࡰࡷࡣࡹࡿࡰࡦࠩᆯ"): bstack11lll111_opy_,
        bstack11111ll_opy_ (u"࠭ࡨࡰࡱ࡮ࡣࡷࡻ࡮ࠨᆰ"): hook_data
    }
    bstack1lll11l1l1_opy_.bstack1ll111111l_opy_(bstack1l11l1lll1_opy_)
@pytest.fixture(autouse=True)
def second_fixture(caplog, request):
    yield
    try:
        if not bstack1lll11l1l1_opy_.on():
            return
        records = caplog.get_records(bstack11111ll_opy_ (u"ࠧࡤࡣ࡯ࡰࠬᆱ"))
        bstack1l1ll11l1l_opy_ = []
        for record in records:
            if record.message == bstack11111ll_opy_ (u"ࠨ࡞ࡱࠫᆲ"):
                continue
            bstack1l1ll11l1l_opy_.append({
                bstack11111ll_opy_ (u"ࠩࡷ࡭ࡲ࡫ࡳࡵࡣࡰࡴࠬᆳ"): datetime.datetime.utcfromtimestamp(record.created).isoformat() + bstack11111ll_opy_ (u"ࠪ࡞ࠬᆴ"),
                bstack11111ll_opy_ (u"ࠫࡱ࡫ࡶࡦ࡮ࠪᆵ"): record.levelname,
                bstack11111ll_opy_ (u"ࠬࡳࡥࡴࡵࡤ࡫ࡪ࠭ᆶ"): record.message,
                bstack11111ll_opy_ (u"࠭ࡴࡦࡵࡷࡣࡷࡻ࡮ࡠࡷࡸ࡭ࡩ࠭ᆷ"): _1l11l1l1l1_opy_.get(request.node.nodeid).get(bstack11111ll_opy_ (u"ࠧࡶࡷ࡬ࡨࠬᆸ"))
            })
        bstack1lll11l1l1_opy_.bstack1l1llll111_opy_(bstack1l1ll11l1l_opy_)
    except Exception as err:
        print(bstack11111ll_opy_ (u"ࠨࡇࡻࡧࡪࡶࡴࡪࡱࡱࠤ࡮ࡴࠠࡴࡧࡦࡳࡳࡪ࡟ࡧ࡫ࡻࡸࡺࡸࡥ࠻ࠢࡾࢁࠬᆹ"), str(err))
def bstack1l11ll1l1l_opy_(driver_command, response):
    if driver_command == bstack11111ll_opy_ (u"ࠩࡶࡧࡷ࡫ࡥ࡯ࡵ࡫ࡳࡹ࠭ᆺ"):
        bstack1lll11l1l1_opy_.bstack1ll1111lll_opy_({
            bstack11111ll_opy_ (u"ࠪ࡭ࡲࡧࡧࡦࠩᆻ"): response[bstack11111ll_opy_ (u"ࠫࡻࡧ࡬ࡶࡧࠪᆼ")],
            bstack11111ll_opy_ (u"ࠬࡺࡥࡴࡶࡢࡶࡺࡴ࡟ࡶࡷ࡬ࡨࠬᆽ"): bstack1ll11111ll_opy_
        })
@bstack1lll11l1l1_opy_.bstack1l1ll11111_opy_
def bstack1l11ll11ll_opy_():
    if bstack1l1l11111l_opy_():
        bstack1ll111l1l1_opy_(bstack1l11ll1l1l_opy_)
bstack1l11ll11ll_opy_()